package 겨울방학과제;

public class Average {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
