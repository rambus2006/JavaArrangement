package 이것이자바다;

public class SubStringExample {
	public static void main(String args[]) {
		
	}
}
