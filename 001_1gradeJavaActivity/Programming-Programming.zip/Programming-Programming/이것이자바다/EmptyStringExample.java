package 이것이자바다;

public class EmptyStringExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String hobby="";
		if(hobby.equals("")) {
			System.out.println("hobby 변수가 참조는 String 객체는 빈 문자뎔");
		}
	}

}
