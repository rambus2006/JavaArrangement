package Babsakiproject;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JButton;		//JButton추가
import javax.swing.JFrame;		//JFrame추가
import javax.swing.JPanel;		//JPanel추가
import javax.swing.WindowConstants;
//완성
public class CornChese extends JFrame {
	CornChese(){
		super(); //타이틀
				
		
		//콘치즈 화면1
				JButton btnNextCOC1=new JButton();		//JButton btn1생성
				JButton btnNextCOC2=new JButton();		//JButton btn1생성
				JButton btnNextCOC3=new JButton();		//JButton btn2생성
				JButton btnNextCOC4=new JButton();		//JButton btn2생성
				JButton btnNextCOC5=new JButton();		//JButton btn3생성
				JButton btnNextCOC6=new JButton();		//JButton btn3생성
				JButton btnNextCOC7=new JButton();		//JButton btn3생성
				JButton btnNextCOC8=new JButton();		//JButton btn3생성
				JButton btnNextCOC9=new JButton();		//JButton btn3생성
				JButton btnNextCOC10=new JButton();		//JButton btn3생성
				
				JButton btnBackCOC1=new JButton();		//JButton btn3생성
				JButton btnBackCOC2=new JButton();		//JButton btn3생성
				JButton btnBackCOC3=new JButton();		//JButton btn3생성
				JButton btnBackCOC4=new JButton();		//JButton btn3생성
				JButton btnBackCOC5=new JButton();		//JButton btn3생성
				JButton btnBackCOC6=new JButton();		//JButton btn3생성
				JButton btnBackCOC7=new JButton();		//JButton btn3생성
				JButton btnBackCOC8=new JButton();		//JButton btn3생성
				JButton btnBackCOC9=new JButton();		//JButton btn3생성
				JButton btnBackCOC10=new JButton();		//JButton btn3생성
				JButton btnBackCOC11=new JButton();		//JButton btn3생성
				JButton btnBackCOC12=new JButton();		
				
				JButton btnEndToHome1=new JButton(); //홈으로 돌아가는 버튼
			
				ImagePanel panelCOC1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\콘치즈패널\\panelCOC1.png").getImage());//패널 생성
				ImagePanel panelCOC2=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\콘치즈패널\\panelCOC2.png").getImage());//패널 생성
				ImagePanel panelCOC3=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\콘치즈패널\\panelCOC3.png").getImage());//패널 생성
				ImagePanel panelCOC4=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\콘치즈패널\\panelCOC4.png").getImage());//패널 생성
				ImagePanel panelCOC5=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\콘치즈패널\\panelCOC5.png").getImage());//패널 생성
				ImagePanel panelCOC6=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\콘치즈패널\\panelCOC6.png").getImage());//패널 생성
				ImagePanel panelCOC7=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\콘치즈패널\\panelCOC7.png").getImage());//패널 생성
				ImagePanel panelCOC8=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\콘치즈패널\\panelCOC8.png").getImage());//패널 생성
				ImagePanel panelCOC9=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\콘치즈패널\\panelCOC9.png").getImage());//패널 생성
				ImagePanel panelCOC10=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\콘치즈패널\\panelCOC10.png").getImage());//패널 생성
				ImagePanel endpanel1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\lastpage.png").getImage());//패널 생성
				
				
				//콘치즈 frame
				setSize(1216,714);
				setLocation(10,10);
				add(panelCOC1);
				setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
				setVisible(true);
				
				add(panelCOC2);
				add(panelCOC3);
				add(panelCOC4);
				add(panelCOC5);
				add(panelCOC6);
				add(panelCOC7);
				add(panelCOC8);
				add(panelCOC9);
				add(panelCOC10);
				add(endpanel1);
			
				//자동넘김버튼============================================================================================================

				JButton autobtn=new JButton();
				autobtn.setVisible(true);
				autobtn.setBounds(800, 38, 200, 100);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				autobtn.setBorder(null);
				autobtn.setContentAreaFilled(false);				//버튼 안의 이미지 외곽의 공간을 없애줌
				autobtn.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\autobtn.png"));
				panelCOC1.add(autobtn);
				
				Timer timer = new Timer();
				
				autobtn.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						//45/5=9, 각 과정당 5분으로 가정했을 때->초 단위로 바꿈
						//1000==1초(밀리세컨 단위)
						TimerTask task= new TimerTask() {
							@Override
							public void run() {
								panelCOC1.setVisible(false);
								panelCOC2.setVisible(true);
							}
						};
						timer.schedule(task, 1000);	//정해진 시간에 실행(1초)
							
						TimerTask task2= new TimerTask() {
							public void run() {
								panelCOC2.setVisible(false);
								panelCOC3.setVisible(true);
							}
						};
						timer.schedule(task2, 6000);	//(실행한 1초+5초=6초)
						
						TimerTask task3= new TimerTask() {
							public void run() {
								panelCOC3.setVisible(false);
								panelCOC4.setVisible(true);
							}
						};
						timer.schedule(task3, 11000); //(실행한6초+5초=11초)
						
						TimerTask task4= new TimerTask() {
							public void run() {
								panelCOC4.setVisible(false);
								panelCOC5.setVisible(true);
							}
						};
						timer.schedule(task4, 16000);	//(실행한11초+5초=16초)
						
						TimerTask task5= new TimerTask() {
							public void run() {
								panelCOC5.setVisible(false);
								panelCOC6.setVisible(true);
							}
						};
						timer.schedule(task5, 21000);//(실행한16초+5초=21초)
						
						TimerTask task6= new TimerTask() {
							public void run() {
								panelCOC6.setVisible(false);
								panelCOC7.setVisible(true);
							}
						};
						timer.schedule(task6, 26000);//(실행한21초+5초=26초)
						
						TimerTask task7= new TimerTask() {
							public void run() {
								panelCOC7.setVisible(false);
								panelCOC8.setVisible(true);
							}
						};
						timer.schedule(task7, 31000);//(실행한26초+5초=31초)
						
						TimerTask task8= new TimerTask() {
							public void run() {
								panelCOC8.setVisible(false);
								panelCOC9.setVisible(true);
							}
						};
						timer.schedule(task8, 36000);//(실행한31초+5초=36초)
						
						TimerTask task9= new TimerTask() {
							public void run() {
								panelCOC9.setVisible(false);
								panelCOC10.setVisible(true);
							}
						};
						timer.schedule(task9, 41000);//(실행한36초+5초=41초)
						
						TimerTask task10= new TimerTask() {
							public void run() {
								panelCOC10.setVisible(false);
								endpanel1.setVisible(true);
							}
						};
						timer.schedule(task10, 46000);//(실행한41초+5초=46초)
					}
					
				});
				
	
				
				
		//------------------------------------콘치즈 다음 버튼-------------------------------------------------------------------------------------		
				//콘치즈 다음 넘기기 버튼1-완성
				btnNextCOC1.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextCOC1.setBorder(null);
				btnNextCOC1.setBorderPainted(false);
				btnNextCOC1.setContentAreaFilled(false);
				btnNextCOC1.setVisible(true);
				btnNextCOC1.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
				btnNextCOC1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelCOC2.setVisible(true);
						panelCOC1.setVisible(false);
						
					}
				});
				panelCOC1.add(btnNextCOC1);
				
				//콘치즈 다음 넘기기 버튼-완성
				btnNextCOC2.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextCOC2.setBorder(null);
				btnNextCOC2.setBorderPainted(false);
				btnNextCOC2.setContentAreaFilled(false);
				btnNextCOC2.setVisible(true);
				btnNextCOC2.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
				btnNextCOC2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelCOC2.setVisible(false);
						panelCOC3.setVisible(true);
						
					}
				});
				panelCOC2.add(btnNextCOC2);
				
				//콘치즈 다음 넘기기 버튼3-완성
				btnNextCOC3.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextCOC3.setBorder(null);
				btnNextCOC3.setBorderPainted(false);
				btnNextCOC3.setContentAreaFilled(false);
				btnNextCOC3.setVisible(true);
				btnNextCOC3.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
				btnNextCOC3.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelCOC3.setVisible(false);
						panelCOC4.setVisible(true);
						
					}
				});
				panelCOC3.add(btnNextCOC3);
				
				//콘치즈 다음 넘기기 버튼4-완성
				btnNextCOC4.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextCOC4.setBorder(null);
				btnNextCOC4.setBorderPainted(false);
				btnNextCOC4.setContentAreaFilled(false);
				btnNextCOC4.setVisible(true);
				btnNextCOC4.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
				btnNextCOC4.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelCOC4.setVisible(false);
						panelCOC5.setVisible(true);
						
					}
				});
				panelCOC4.add(btnNextCOC4);
				
				//콘치즈 다음 넘기기 버튼5-완성
				btnNextCOC5.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextCOC5.setBorder(null);
				btnNextCOC5.setBorderPainted(false);
				btnNextCOC5.setContentAreaFilled(false);
				btnNextCOC5.setVisible(true);
				btnNextCOC5.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
				btnNextCOC5.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelCOC5.setVisible(false);
						panelCOC6.setVisible(true);
						
					}
				});
				panelCOC5.add(btnNextCOC5);
				
				
				//콘치즈 다음 넘기기 버튼6-완성
				btnNextCOC6.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextCOC6.setBorder(null);
				btnNextCOC6.setBorderPainted(false);
				btnNextCOC6.setContentAreaFilled(false);
				btnNextCOC6.setVisible(true);
				btnNextCOC6.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
				btnNextCOC6.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelCOC6.setVisible(false);
						panelCOC7.setVisible(true);
						
					}
				});
				panelCOC6.add(btnNextCOC6);
				
				
				//콘치즈 다음 넘기기 버튼7
				btnNextCOC7.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextCOC7.setBorder(null);
				btnNextCOC7.setVisible(true);
				btnNextCOC7.setBorderPainted(false);
				btnNextCOC7.setContentAreaFilled(false);
				btnNextCOC7.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
				btnNextCOC7.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelCOC7.setVisible(false);
						panelCOC8.setVisible(true);
						
					}
				});
				panelCOC7.add(btnNextCOC7);
				
				//콘치즈 다음 넘기기 버튼8-9
				btnNextCOC8.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextCOC8.setBorder(null);
				btnNextCOC8.setVisible(true);
				btnNextCOC8.setBorderPainted(false);
				btnNextCOC8.setContentAreaFilled(false);
				btnNextCOC8.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
				btnNextCOC8.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelCOC8.setVisible(false);
						panelCOC9.setVisible(true);
						
					}
				});
				panelCOC8.add(btnNextCOC8);
				
				//콘치즈 다음 넘기기 버튼9-10
				btnNextCOC9.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextCOC9.setBorder(null);
				btnNextCOC9.setVisible(true);
				btnNextCOC9.setBorderPainted(false);
				btnNextCOC9.setContentAreaFilled(false);
				btnNextCOC9.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
				btnNextCOC9.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelCOC9.setVisible(false);
						panelCOC10.setVisible(true);
						
					}
				});
				panelCOC9.add(btnNextCOC9);
				
				//콘치즈 다음 넘기기 버튼10-끝
				btnNextCOC10.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextCOC10.setBorder(null);
				btnNextCOC10.setVisible(true);
				btnNextCOC10.setBorderPainted(false);
				btnNextCOC10.setContentAreaFilled(false);
				btnNextCOC10.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
				btnNextCOC10.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelCOC10.setVisible(false);
						endpanel1.setVisible(true);
						
					}
				});
				panelCOC10.add(btnNextCOC10);
				
				//콘치즈 다음 넘기기 버튼10-끝
				btnEndToHome1.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnEndToHome1.setBorder(null);
				btnEndToHome1.setVisible(true);
				btnEndToHome1.setBorderPainted(false);
				btnEndToHome1.setContentAreaFilled(false);
				btnEndToHome1.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\homebtn.png"));
				btnEndToHome1.addActionListener(new ActionListener() {	
					public void actionPerformed(ActionEvent e) {
							
							new MenuSelection(); 
							endpanel1.setVisible(false);
								
					}
				});
				endpanel1.add(btnEndToHome1);



				

		//----------------------------------------이전버튼------------------------------------------------------------------------------------
					//콘치즈 이전버튼
				btnBackCOC1.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnBackCOC1.setBorder(null);
				btnBackCOC1.setVisible(true);
				btnBackCOC1.setBorderPainted(false);
				btnBackCOC1.setContentAreaFilled(false);
				btnBackCOC1.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\backbtn.png"));
				btnBackCOC1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
								
								panelCOC2.setVisible(false);
								panelCOC1.setVisible(true);	
						}
					});
					panelCOC2.add(btnBackCOC1);
					//콘치즈 이전버튼
					btnBackCOC2.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
					btnBackCOC2.setBorder(null);
					btnBackCOC2.setVisible(true);
					btnBackCOC2.setBorderPainted(false);
					btnBackCOC2.setContentAreaFilled(false);
					btnBackCOC2.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\backbtn.png"));
					btnBackCOC2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
								
								panelCOC3.setVisible(false);
								panelCOC2.setVisible(true);	
						}
					});
					panelCOC3.add(btnBackCOC2);
					//콘치즈 이전버튼
					btnBackCOC3.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
					btnBackCOC3.setBorder(null);
					btnBackCOC3.setVisible(true);
					btnBackCOC3.setBorderPainted(false);
					btnBackCOC3.setContentAreaFilled(false);
					btnBackCOC3.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\backbtn.png"));
					btnBackCOC3.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
								
								panelCOC4.setVisible(false);
								panelCOC3.setVisible(true);	
						}
					});
					panelCOC4.add(btnBackCOC3);
			
					
					//콘치즈 이전버튼
					btnBackCOC4.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
					btnBackCOC4.setBorder(null);
					btnBackCOC4.setVisible(true);
					btnBackCOC4.setBorderPainted(false);
					btnBackCOC4.setContentAreaFilled(false);
					btnBackCOC4.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\backbtn.png"));
					btnBackCOC4.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
								
								panelCOC5.setVisible(false);
								panelCOC4.setVisible(true);	
						}
					});
					panelCOC5.add(btnBackCOC4);
					//콘치즈 이전버튼
					btnBackCOC5.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
					btnBackCOC5.setBorder(null);
					btnBackCOC5.setVisible(true);
					btnBackCOC5.setBorderPainted(false);
					btnBackCOC5.setContentAreaFilled(false);
					btnBackCOC5.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\backbtn.png"));
					btnBackCOC5.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
								
								panelCOC6.setVisible(false);
								panelCOC5.setVisible(true);	
						}
					});
					panelCOC6.add(btnBackCOC5);
					//콘치즈 이전버튼
					btnBackCOC6.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
					btnBackCOC6.setBorder(null);
					btnBackCOC6.setVisible(true);
					btnBackCOC6.setBorderPainted(false);
					btnBackCOC6.setContentAreaFilled(false);
					btnBackCOC6.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\backbtn.png"));
					btnBackCOC6.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
								
								panelCOC7.setVisible(false);
								panelCOC6.setVisible(true);	
						}
					});
					panelCOC7.add(btnBackCOC6);
					//콘치즈 이전버튼
					btnBackCOC7.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
					btnBackCOC7.setBorder(null);
					btnBackCOC7.setVisible(true);
					btnBackCOC7.setBorderPainted(false);
					btnBackCOC7.setContentAreaFilled(false);
					btnBackCOC7.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\backbtn.png"));
					btnBackCOC7.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
								
								panelCOC8.setVisible(false);
								panelCOC7.setVisible(true);	
						}
					});
					panelCOC8.add(btnBackCOC7);
					//콘치즈 이전버튼
					btnBackCOC8.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
					btnBackCOC8.setBorder(null);
					btnBackCOC8.setVisible(true);
					btnBackCOC8.setBorderPainted(false);
					btnBackCOC8.setContentAreaFilled(false);
					btnBackCOC8.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\backbtn.png"));
					btnBackCOC8.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
								
								panelCOC9.setVisible(false);
								panelCOC8.setVisible(true);	
						}
					});
					panelCOC9.add(btnBackCOC8);
					//콘치즈 이전버튼
					btnBackCOC9.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
					btnBackCOC9.setBorder(null);
					btnBackCOC9.setVisible(true);
					btnBackCOC9.setBorderPainted(false);
					btnBackCOC9.setContentAreaFilled(false);
					btnBackCOC9.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\backbtn.png"));
					btnBackCOC9.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
								
								panelCOC10.setVisible(false);
								panelCOC9.setVisible(true);	
						}
					});
					panelCOC9.add(btnBackCOC9);
					//콘치즈 이전버튼
					btnBackCOC10.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
					btnBackCOC10.setBorder(null);
					btnBackCOC10.setVisible(true);
					btnBackCOC10.setBorderPainted(false);
					btnBackCOC10.setContentAreaFilled(false);
					btnBackCOC10.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\backbtn.png"));
					btnBackCOC10.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
								
								endpanel1.setVisible(false);
								panelCOC9.setVisible(true);	
						}
					});
					panelCOC10.add(btnBackCOC10);
				
					
					
	}
}
class panelCOC1 extends JPanel{
	
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image imgCOC1;	
	
	public panelCOC1(Image img) {
		this.imgCOC1=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
		
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(imgCOC1, 0, 0, null);	//(0,0)은 x,y값
	}
	
}
class panelCOC2 extends JPanel{
	
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image imgCOC1;	
	
	public panelCOC2(Image img) {
		this.imgCOC1=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
		
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(imgCOC1, 0, 0, null);	//(0,0)은 x,y값
	}
	
}
class panelCOC3 extends JPanel{
	
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image imgCOC1;	
	
	public panelCOC3(Image img) {
		this.imgCOC1=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
		
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(imgCOC1, 0, 0, null);	//(0,0)은 x,y값
	}
	
}
class panelCOC4 extends JPanel{
	
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image imgCOC1;	
	
	public panelCOC4(Image img) {
		this.imgCOC1=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
		
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(imgCOC1, 0, 0, null);	//(0,0)은 x,y값
	}
	
}
class panelCOC5 extends JPanel{
	
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image imgCOC1;	
	
	public panelCOC5(Image img) {
		this.imgCOC1=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
		
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(imgCOC1, 0, 0, null);	//(0,0)은 x,y값
	}
	
}
class panelCOC6 extends JPanel{
	
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image imgCOC1;	
	
	public panelCOC6(Image img) {
		this.imgCOC1=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
		
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(imgCOC1, 0, 0, null);	//(0,0)은 x,y값
	}
	
}
class panelCOC7 extends JPanel{
	
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image imgCOC1;	
	
	public panelCOC7(Image img) {
		this.imgCOC1=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
		
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(imgCOC1, 0, 0, null);	//(0,0)은 x,y값
	}
	
}
class panelCOC8 extends JPanel{
	
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image imgCOC1;	
	
	public panelCOC8(Image img) {
		this.imgCOC1=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
		
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(imgCOC1, 0, 0, null);	//(0,0)은 x,y값
	}
	
}
class panelCOC9 extends JPanel{
	
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image imgCOC1;	
	
	public panelCOC9(Image img) {
		this.imgCOC1=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
		
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(imgCOC1, 0, 0, null);	//(0,0)은 x,y값
	}
	
}
class panelCOC10 extends JPanel{
	
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image imgCOC1;	
	
	public panelCOC10(Image img) {
		this.imgCOC1=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
		
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(imgCOC1, 0, 0, null);	//(0,0)은 x,y값
	}
	
}
/*class timer1 extends JFrame{
	timer1(){
		
		timer.schedule(task, 2000);
		
	}
	
}*/

