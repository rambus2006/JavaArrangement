package Babsakiproject;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JButton;		//JButton추가
import javax.swing.JFrame;		//JFrame추가
import javax.swing.JLabel;
import javax.swing.JPanel;		//JPanel추가
import javax.swing.WindowConstants;

//완성
public class MorningEggBread extends JFrame {
	MorningEggBread(){
		super(); //타이틀
		//panelMEB2
				JButton btnNextMEB1=new JButton();		//JButton btn1생성
				JButton btnNextMEB2=new JButton();		//JButton btn1생성
				JButton btnNextMEB3=new JButton();		//JButton btn1생성
				JButton btnNextMEB4=new JButton();		//JButton btn1생성
				JButton btnNextMEB5=new JButton();		//JButton btn1생성
				JButton btnNextMEB6=new JButton();		//JButton btn1생성
				JButton btnEndToHome2=new JButton();		//JButton btn1생성
				
				//이전버튼
				JButton btnBackMEB1=new JButton();		//JButton btn1생성
				JButton btnBackMEB2=new JButton();			//JButton btn2생성
				JButton btnBackMEB3=new JButton();		//JButton btn3생성
				JButton btnBackMEB4=new JButton();		//JButton btn4생성
				JButton btnBackMEB5=new JButton();		//JButton btn5생성
				JButton btnBackMEB6=new JButton();		//JButton btn5생성
				
				ImagePanel panelMEB1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\모닝계란빵패널\\panelMEB1.png").getImage());//패널 생성
				ImagePanel panelMEB2=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\모닝계란빵패널\\panelMEB2.png").getImage());//패널 생성
				ImagePanel panelMEB3=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\모닝계란빵패널\\panelMEB3.png").getImage());//패널 생성
				ImagePanel panelMEB4=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\모닝계란빵패널\\panelMEB5.png").getImage());//패널 생성
				ImagePanel panelMEB5=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\모닝계란빵패널\\panelMEB5.png").getImage());//패널 생성
				ImagePanel panelMEB6=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\모닝계란빵패널\\panelMEB6.png").getImage());//패널 생성
				ImagePanel endpanel2=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\lastpage.png").getImage());//패널 생성
				
				//모닝계란빵 
				setSize(1216,714);
				setLocation(10,10);
				add(panelMEB1);
				setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
				setVisible(true);
				
				add(panelMEB2);
				add(panelMEB3);
				add(panelMEB4);
				add(panelMEB5);
				add(panelMEB6);
				add(endpanel2);
				
				//자동넘김버튼============================================================================================================

				JButton autobtn=new JButton();
				autobtn.setVisible(true);
				autobtn.setBounds(800, 38, 200, 100);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				autobtn.setBorder(null);
				autobtn.setContentAreaFilled(false);				//버튼 안의 이미지 외곽의 공간을 없애줌
				autobtn.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\autobtn.png"));
				panelMEB1.add(autobtn);
				
				Timer timer = new Timer();
				
				autobtn.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						//24/6=4, 각 과정당 6분으로 가정했을 때->초 단위로 바꿈
						//1000==1초(밀리세컨 단위)
						TimerTask task= new TimerTask() {
							@Override
							public void run() {
								panelMEB1.setVisible(false);
								panelMEB2.setVisible(true);
							}
						};
						timer.schedule(task, 1000);	//정해진 시간에 실행(1초)
							
						TimerTask task2= new TimerTask() {
							public void run() {
								panelMEB2.setVisible(false);
								panelMEB3.setVisible(true);
							}
						};
						timer.schedule(task2, 5000);	//(실행한 1초+4초=5초)
						
						TimerTask task3= new TimerTask() {
							public void run() {
								panelMEB3.setVisible(false);
								panelMEB4.setVisible(true);
							}
						};
						timer.schedule(task3, 9000); //(실행한5초+4초=9초)
						
						TimerTask task4= new TimerTask() {
							public void run() {
								panelMEB4.setVisible(false);
								panelMEB5.setVisible(true);
							}
						};
						timer.schedule(task4, 14000);	//(실행한9초+5초=14초)
						
						TimerTask task5= new TimerTask() {
							public void run() {
								panelMEB5.setVisible(false);
								panelMEB6.setVisible(true);
							}
						};
						timer.schedule(task5, 18000);//(실행한14초+5초=19초)
						
						TimerTask task6= new TimerTask() {
							public void run() {
								panelMEB6.setVisible(false);
								endpanel2.setVisible(true);
							}
						};
						timer.schedule(task6, 24000);//(실행한19초+5초=24초)
					}
					
				});
		//----------------------------------------------------------------------모닝계란빵다음버튼----------------------------------------------------
				
				
				btnNextMEB1.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextMEB1.setBorder(null);
				btnNextMEB1.setVisible(true);
				btnNextMEB1.setBorderPainted(false);
				btnNextMEB1.setContentAreaFilled(false);
				btnNextMEB1.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
				btnNextMEB1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelMEB2.setVisible(true);
						panelMEB1.setVisible(false);
						
						
					}
				});
				panelMEB1.add(btnNextMEB1);
				
				btnNextMEB2.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextMEB2.setBorder(null);
				btnNextMEB2.setVisible(true);
				btnNextMEB2.setBorderPainted(false);
				btnNextMEB2.setContentAreaFilled(false);
				btnNextMEB2.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
				btnNextMEB2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelMEB3.setVisible(true);
						panelMEB2.setVisible(false);
					
					}
				});
				panelMEB2.add(btnNextMEB2);
				
				btnNextMEB3.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextMEB3.setBorder(null);
				btnNextMEB3.setVisible(true);
				btnNextMEB3.setBorderPainted(false);
				btnNextMEB3.setContentAreaFilled(false);
				btnNextMEB3.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
				btnNextMEB3.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelMEB4.setVisible(true);
						panelMEB3.setVisible(false);				
					}
				});
				panelMEB3.add(btnNextMEB3);
				
				btnNextMEB4.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextMEB4.setBorder(null);
				btnNextMEB4.setVisible(true);
				btnNextMEB4.setBorderPainted(false);
				btnNextMEB4.setContentAreaFilled(false);
				btnNextMEB4.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
				btnNextMEB4.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelMEB5.setVisible(true);
						panelMEB4.setVisible(false);
				
					}
				});
				panelMEB4.add(btnNextMEB4);
				
				//엔딩화면으로 넘어가는 버튼
				btnNextMEB5.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextMEB5.setBorder(null);
				btnNextMEB5.setVisible(true);
				btnNextMEB5.setBorderPainted(false);
				btnNextMEB5.setContentAreaFilled(false);
				btnNextMEB5.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
				btnNextMEB5.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelMEB6.setVisible(true);
						panelMEB5.setVisible(false);
					}
				});
				panelMEB5.add(btnNextMEB5);
				
				btnNextMEB6.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextMEB6.setBorder(null);
				btnNextMEB6.setVisible(true);
				btnNextMEB6.setBorderPainted(false);
				btnNextMEB6.setContentAreaFilled(false);
				btnNextMEB6.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
				btnNextMEB6.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelMEB6.setVisible(false);
						endpanel2.setVisible(true);
						
						
						
					}
				});
				panelMEB6.add(btnNextMEB6);
				
				//엔딩화면에서 홈화면으로 돌아가는 버튼 
				btnEndToHome2.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnEndToHome2.setBorder(null);
				btnEndToHome2.setVisible(true);
				btnEndToHome2.setBorderPainted(false);
				btnEndToHome2.setContentAreaFilled(false);
				btnEndToHome2.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\homebtn.png"));
				btnEndToHome2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						endpanel2.setVisible(false);
						new MenuSelection(); 
						
					}
				});
				endpanel2.add(btnEndToHome2);
				
		
		//----------------------------------------------------------------------모닝계란빵이전버튼----------------------------------------------------
						
				btnBackMEB1.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnBackMEB1.setBorder(null);
				btnBackMEB1.setVisible(true);
				btnBackMEB1.setBorderPainted(false);
				btnBackMEB1.setContentAreaFilled(false);
				btnBackMEB1.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
				btnBackMEB1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
						panelMEB2.setVisible(false);
						panelMEB1.setVisible(true);
								
					}
				});
				panelMEB2.add(btnBackMEB1);
						
				btnBackMEB2.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnBackMEB2.setBorder(null);
				btnBackMEB2.setVisible(true);
				btnBackMEB2.setBorderPainted(false);
				btnBackMEB2.setContentAreaFilled(false);
				btnBackMEB2.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
				btnBackMEB2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
						panelMEB3.setVisible(false);
						panelMEB2.setVisible(true);
								
					}
				});
				panelMEB3.add(btnBackMEB2);
						
				btnBackMEB3.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnBackMEB3.setBorder(null);
				btnBackMEB3.setVisible(true);
				btnBackMEB3.setBorderPainted(false);
				btnBackMEB3.setContentAreaFilled(false);
				btnBackMEB3.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
				btnBackMEB3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
						panelMEB4.setVisible(false);
						panelMEB3.setVisible(true);
							
								
					}
				});
				panelMEB4.add(btnBackMEB3);
						
				btnBackMEB4.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnBackMEB4.setBorder(null);
				btnBackMEB4.setVisible(true);
				btnBackMEB4.setBorderPainted(false);
				btnBackMEB4.setContentAreaFilled(false);
				btnBackMEB4.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
				btnBackMEB4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
						panelMEB5.setVisible(false);
						panelMEB4.setVisible(true);
								
					}
				});
				panelMEB5.add(btnBackMEB4);

				btnBackMEB5.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnBackMEB5.setBorder(null);
				btnBackMEB5.setVisible(true);
				btnBackMEB5.setBorderPainted(false);
				btnBackMEB5.setContentAreaFilled(false);
				btnBackMEB5.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
				btnBackMEB5.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
						panelMEB6.setVisible(false);
						panelMEB5.setVisible(true);
								
					}
				});
				panelMEB6.add(btnBackMEB5);
				
				
						
			
	}
	
}
