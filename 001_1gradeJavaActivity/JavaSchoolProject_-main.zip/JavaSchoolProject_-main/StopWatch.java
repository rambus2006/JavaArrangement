package Babsakiproject;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class StopWatch implements ActionListener{
	
	//프레임생성
	JFrame frame=new JFrame();
	JButton startButton =new JButton("START");
	JButton resetButton =new JButton("RESET");
	JLabel timeLabel =new JLabel();
	int elapsedTime=0;
	int seconds=0;
	int minutes=0;
	int hours=0;
	boolean started=false;						//문자열로 0만들기 
	String seconds_string=String.format("%02d",seconds);
	String minutes_string=String.format("%02d",minutes);
	String hours_string=String.format("%02d",hours);
	
	
	//타이머 만들기 
	Timer timer=new Timer(1000,new ActionListener() {
		//액션 수행 메서드 : 타이머가 1000밀리초마다하는 일
		public void actionPerformed(ActionEvent e) {
			elapsedTime=elapsedTime+1000;
			hours=(elapsedTime/3600000);
			minutes=(elapsedTime/60000)%60;	//1분
			seconds=(elapsedTime/1000)%60;	//60이상 표시하기 싫어서 나눔
			seconds_string=String.format("%02d",seconds);
		    minutes_string=String.format("%02d",minutes);
		    hours_string=String.format("%02d",hours);
		    
		    //시간 분 초에 대한 새로운 문자열로 시간레이블을 업데이트 하여 시간레이블이 텍스트를 설정하도록 함
		    timeLabel.setText(hours_string+":"+minutes_string+":"+seconds_string);
		}
	});	
	
	//생성자
	StopWatch(){
		//처음0 : 0 : 0 화면
		timeLabel.setText(hours_string+":"+minutes_string+":"+seconds_string);
		timeLabel.setBounds(100,100,200,100);
		timeLabel.setFont(new Font("Verdana",Font.PLAIN,35));
		timeLabel.setBorder(BorderFactory.createBevelBorder(1));
		timeLabel.setOpaque(true);
		timeLabel.setHorizontalAlignment(JTextField.CENTER);
		
		//시작버튼
		startButton.setBounds(100,200,100,50);	//setBounds( x, y, w, h);	위치(x,y),가로,세로
		startButton.setFont(new Font("Verdana",Font.BOLD,18));
		startButton.setFocusable(false);
		startButton.addActionListener(this);
		
		
		//리셋버튼
		resetButton.setBounds(200,200,100,50);
		resetButton.setFont(new Font("Verdana",Font.BOLD,18));
		resetButton.setFocusable(false);
		resetButton.addActionListener(this);
		
	
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400,718);
		frame.setLocation(1216,10);
		frame.getContentPane().setBackground(Color.white);
		frame.setLayout(null);
		frame.setVisible(true);
		frame.add(startButton);
		frame.add(resetButton);
		frame.add(timeLabel);

		
		
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		//소스가 시작버튼과 같은지 확인
		if(e.getSource()==startButton) {
			
			if(started==false) {
				started=true;
				startButton.setText("Stop");
				start();	//시작함수 호출
			}else {	//타이머가 실행중일 때 재시작
				startButton.setText("START");
				stop();
			}
		}
		//초기화 버튼
		if(e.getSource()==resetButton){
			started=false;
			startButton.setText("START");
			reset();
		}
		
	}
	//프레임워크
	void start() {
		timer.start();
	}
	void stop() {
		timer.stop();
	}
	void reset() {
		timer.stop();
		elapsedTime=0;
		seconds=0;
		minutes=0;
		hours=0;
		
		seconds_string=String.format("%02d",seconds);
	    minutes_string=String.format("%02d",minutes);
	    hours_string=String.format("%02d",hours);
	    //시간 분 초에 대한 새로운 문자열로 시간레이블을 업데이트 하여 시간레이블이 텍스트를 설정하도록 함
	    timeLabel.setText(hours_string+":"+minutes_string+":"+seconds_string);
		
	}
}

