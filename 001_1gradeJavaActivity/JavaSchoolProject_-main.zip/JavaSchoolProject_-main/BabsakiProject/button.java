package Babsakiproject;

import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class button extends JPanel {

	/**
	 * Create the panel.
	 */
	public button() {
		
		JButton btnNewButton = new JButton("모닝계란빵");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\MorningEggBread_result.PNG"));
		btnNewButton.setSize(909,566);
		add(btnNewButton);

	}

}
