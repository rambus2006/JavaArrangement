package Babsakiproject;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.TextArea;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

//모닝 계란빵 과정1 - panel : page2_2
public class MorningEggBread2 extends JFrame {
	JPanel page2_2 = new JPanel();
	Image background=new ImageIcon(MorningEggBread_P1.class.getResource("../image_MorningEggBread/MorningEggBread_processimg.png")).getImage();
	public void paint(Graphics g_1) {				//그리는 함수
		g_1.drawImage(background, 0,0, null);//background를 그려줌		
	
	//}
	//PumpkinGratin_Backimg Frame, panel
	//
	public MorningEggBread2() {
		//배경 이미지 패널 생성
		/*ImagePanel pnMiddle=new ImagePanel(new ImageIcon("./image/MorningEggBread.jpg").getImage());
		pnMiddle.setBounds(0,90,501,379);
		getContentPane().add(pnMiddle);
		pnMiddle.setLayout(null);
		*/
		
		//page2_2frame
		setTitle("MorningEggBread_P1");//창의 타이틀
		setSize(1216,714);//프레임의 크기
		setLocation(10,10);//창이 가운데 나오게
		setResizable(false);//창의 크기를 변경하지 못하게
		setLayout(null);
		setVisible(true);//창이 보이게	
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//JFrame이 정상적으로 종료되게
		
		//panel 설정
		page2_2.setLayout(null);			//panel 레이아웃
		page2_2.setBounds(0, 0,1200,680);	//panel위치 
		NextButton(page2_2);				//다음 버튼 추가
		IntroductionTextArea(page2_2);		//설명 추가 
		
		//page2_2.add(background);
		//return page2_2;
	}
/* class ImagePanel extends JPanel{
		private Image img;
		public ImagePanel(Image img) {
			this.img=img;
			img.setSize(new Dimension(img.getwidth(null),img.getHeight(null)));
			img.setPreferredSize(new Dimension(img.getWidth(null),img.get Height(null)));
			img.setLayout(null);
		}
		public void paintComponent(Graphics g) {
			g.drawImage(img,3,0,null);
		}
	}
*/
	
}
