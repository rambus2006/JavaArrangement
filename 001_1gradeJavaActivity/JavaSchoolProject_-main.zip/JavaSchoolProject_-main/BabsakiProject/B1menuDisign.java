package Babsakiproject;

import java.awt.*;
import java.awt.event.*;		//1단계
import javax.swing.*;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.*;
import java.util.Scanner;
import java.util.List;
/*
 * [컨테이너(container)={Frame,Panel,Dialog}]
 * 	-동등하기 때문에 겹칠 수 없다. 
 * [패널]
 * 	패널은 나중에 추가할 수록 뒤로 간다. 
 *  약간 이런 구조
 * 	-------------------------
 * 	|--------------------	|
 *  ||	------			|	|
 *  ||	|	 | 			|	|
 *  ||	------			|	|
 *  |-------------------	|
 *  -------------------------
 */
public class B1menuDisign {
	 public B1menuDisign() {
		 	//프레임 생성
		 	JFrame M1  = new JFrame();
			M1.setTitle("b1MenuPanel");					//프레임 제목
			M1.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//닫기 버튼 적용
			M1.setVisible(true);					//프레임 보이게 하기 
			M1.setLocation(500,200);
			M1.setSize(1200,800);
			M1.setBackground(Color.white);
		    
		    //패널 생성(패널은 나중에 추가할 수록 뒤로 간다. )
		    JPanel b1MenuPanel = new JPanel();				//패널1 (가장 위쪽,홈버튼과 요리제목)
		    JPanel b1MenuPanel2 = new JPanel();				//패널2(사진,레시피 들어가는 패널)
		    JPanel b1MenuPanel3 = new JPanel();				//패널3(타이머 들어가는 패널)
		    JPanel b1MenuPanel4 = new JPanel();				//패널4(이전, 다음 버튼 들어가는 패널)
		    
		    //패널1설정
		    b1MenuPanel.setBackground(Color.orange);		//패널 배경색 
		    b1MenuPanel.setBounds(0, 0, 1200, 200);			//패널위치,크기 .setBounds( x, y, w, h);
		    M1.add(b1MenuPanel);							//패널 M1프레임에 추가 
		    HomeButton(b1MenuPanel);						//HomeButton메서드 호출 
		    MenuTitle(b1MenuPanel);
		    
		    //패널2 설정
		    b1MenuPanel2.setBackground(Color.orange);		//패널2 배경색(노랑)
		    b1MenuPanel2.setBounds(0,120,1200,600);			//패널 위치, 크기.setBounds(x,y,w,h);
		    b1MenuPanel2.setVisible(true);					//패널 보이게 한다. 
		    b1MenuPanel.add(b1MenuPanel2);					//패널2를 패널 1에 추가
		    MenuPhoto(b1MenuPanel2);						//패널2에 메뉴 사진 추가
		    MenuRecipe(b1MenuPanel2);						//패널2에 레시피 추가 
		    
		    //패널3 설정
		    b1MenuPanel3.setBackground(Color.blue);			//패널3 배경색(파랑)
		    b1MenuPanel3.setBounds(0,800,1200,100);			//패널위치, 크기
		    M1.add(b1MenuPanel3);							//프레임에 패널3 추가 
			
		    //패널 4 설정
		    b1MenuPanel4.setBackground(Color.blue);			//패널4 배경색(핑크)
		    b1MenuPanel4.setBounds(0,400,1200,400);			//패널 위치, 크기
		    b1MenuPanel4.setVisible(true);					//패널 보이게 
		    b1MenuPanel.add(b1MenuPanel4);					//패널1에 패널 4 추가 
		    ForwardButton(b1MenuPanel4);					//패널4에 메서드 추가 
		    BackButton(b1MenuPanel4);
		    
		  
	}

	public static void main(String[] args) {
			new  B1menuDisign();
			
		/*
		 * 		 
		
		
		
		 //로고 이미지 사진 넣기 
			
			JPanel b1recipe=new JPanel();
		 */
	}

	public static void HomeButton(JPanel b1MenuPanel) {
		
			ImageIcon iconlogo = new ImageIcon("E:\\1409방민서java\\images\\logo.png");		//사진 불러오기
			//버튼크기에 맞게 사진 크기 조정하기 
			Image logoSize=iconlogo.getImage();												
			Image changeLogo=logoSize.getScaledInstance(100,100,Image.SCALE_SMOOTH);		
			ImageIcon logo=new ImageIcon(changeLogo);
		
			//로고 사진 버튼 만들기 
			JButton l1=new JButton(logo);													//버튼에 사진넣기 															//버튼 크기 
			l1.setBounds(10, 10, 100, 100);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			b1MenuPanel.add(l1);	
		    return ;
		
	}//HomeButton메서드 끝
	public static void MenuTitle(JPanel b1MenuPanel) {
		TextField menutitle=new TextField("김치볶음밥");
		menutitle.selectAll();
		menutitle.setBounds(120,10,600,100);
		b1MenuPanel.add(menutitle);
		return;
	}
	public static void MenuPhoto(JPanel b1MenuPanel2 ) {
		ImageIcon Introductionimg_b1 = new ImageIcon("E:\\1409방민서java\\images\\KimchiFriedRice.jpg");		//사진 불러오기
		//버튼크기에 맞게 사진 크기 조정하기 
		Image Introductionimg_b1Size=Introductionimg_b1.getImage();												
		Image changeIntroductionimg_b1=Introductionimg_b1Size.getScaledInstance(500,400,Image.SCALE_SMOOTH);		
		ImageIcon Introduction_b1=new ImageIcon(changeIntroductionimg_b1);
		
		//소개화면 사진 버튼 만들기 
		JButton Introduction=new JButton(Introduction_b1);													//버튼에 사진넣기 															//버튼 크기 
		Introduction.setBounds(10, 10, 500, 400);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		Introduction.setVisible(true);
		b1MenuPanel2.add(Introduction);	
				
	}
	//레시피 출력하기 
	public static void MenuRecipe(JPanel b1MenuPanel2) {
		TextField menutitle=new TextField(" "
				+ "<조리 예상 시간>"
				+ "10분<br>"
				+ "\r\n"
				+ "<재료>\r\n"
				+ "밥1공기, 참치통조림(85g) 1개, 김치 한주먹, 설탕 1스푼, 참기름 1스푼, 고추장 반스푼\r\n"
				+ "\r\n"
				+ "<요리방법>\r\n"
				+ "1. 신김치나 일반김치 한주먹을 가위로 잘게 잘라준다.\r\n"
				+ "2. 전자레인지 사용가능한 그릇에 김치와 설탕1스푼, 참기름 1스푼 넣고 섞어준다. (김치가 많이 신 경우, 설탕 조금 더 추가)\r\n"
				+ "3. 참치통조림의 기름을 제거한 후, 그릇에 함께 넣고 다시 섞어준다.\r\n"
				+ "4. 전자레인지(700w기준) 2분 30초 돌리기\r\n"
				+ "5. 밥 1공기, 고추장 반스푼~1스푼 넣고 비벼준다.\r\n"
				+ " ");
		menutitle.selectAll();
		menutitle.setBounds(520,10,650,400);
		menutitle.setVisible(true);
		b1MenuPanel2.add(menutitle);
		return;
	}
	public static void ForwardButton(JPanel b1MenuPanel4) {
		
		ImageIcon next_b1 = new ImageIcon("E:\\1409방민서java\\images\\button1.png");		//사진 불러오기
		//버튼크기에 맞게 사진 크기 조정하기 
		Image Nextimg_b1Size=next_b1.getImage();												
		Image changeNextimg_b1=Nextimg_b1Size.getScaledInstance(400,200,Image.SCALE_SMOOTH);		
		ImageIcon Next_b1=new ImageIcon(changeNextimg_b1);
		
		//소개화면 사진 버튼 만들기 
		JButton NextButton_b1=new JButton(Next_b1);													//버튼에 사진넣기 															//버튼 크기 
		NextButton_b1.setBounds(10, 150, 300, 150);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		NextButton_b1.setVisible(true);
		b1MenuPanel4.add(NextButton_b1);	
		return;
	}
	public static void BackButton(JPanel b1MenuPanel4) {
		
		ImageIcon Back_b1 = new ImageIcon("E:\\1409방민서java\\images\\button2.png");		//사진 불러오기
		//버튼크기에 맞게 사진 크기 조정하기 
		Image Backimg_b1Size=Back_b1.getImage();												
		Image changeBackimg_b1=Backimg_b1Size.getScaledInstance(400,200,Image.SCALE_SMOOTH);		
		ImageIcon Backbt_b1=new ImageIcon( changeBackimg_b1);
		
		//소개화면 사진 버튼 만들기 
		JButton BackButton_b1=new JButton(Backbt_b1);													//버튼에 사진넣기 															//버튼 크기 
		BackButton_b1.setBounds(830, 150, 30, 150);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		BackButton_b1.setVisible(true);
		b1MenuPanel4.add(BackButton_b1);	
		return;
	}
	
}
//홈버튼클래스(자식 클래스)


