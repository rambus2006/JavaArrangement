package Babsakiproject;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;		//JButton추가
import javax.swing.JFrame;		//JFrame추가
import javax.swing.JPanel;		//JPanel추가

//패널에 이미지 넣기 
class ImagePanel extends JPanel{
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image img;	
	
	public ImagePanel(Image img) {
		this.img=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(img, 0, 0, null);	//(0,0)은 x,y값
	}
}
//버튼 클래스
/*class Button extends JButton{
	public void button(ImagePanel imgpanel1) {
		
			JButton btnNewButton = new JButton("모닝계란빵");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				}
			});
			btnNewButton.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\MorningEggBread_result.PNG"));
			btnNewButton.setBounds(170, 250, 276, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNewButton.setVisible(true);
			imgpanel1.add(btnNewButton);
			
	 	ImageIcon icon = new ImageIcon(
            TestFrame.class.getResource("/test/image/icon.png")
        );
        
        // ImageIcon 객체에서 Image 추출
        Image img = icon.getImage();
        
        // 추출된 Image의 크기 조절하여 새로운 Image 객체 생성
    	Image updateImg = img.getScaledInstance(165, 100, Image.SCALE_SMOOTH);
        
        // 새로운 Image 객체로 ImageIcon 객체 생성
        ImageIcon updateIcon = new ImageIcon(updateImg);
        
        JLabel imgLabel = new JLabel(updateIcon);
        
        getContentPane().add(imgLabel);
        
	
		}
	}
*/




//Main
public class MenuSelection {
	public static void main(String args[]) {
		JFrame frame=new JFrame();		//JFrame 생성
		//JPanel panel1=new JPanel();		//JPanel 생성
		JButton btn1=new JButton();		//JButton btn1생성
		JButton btn2=new JButton();		//JButton btn2생성
		JButton btn3=new JButton();		//JButton btn3생성
		ImagePanel imgpanel1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\MenuSelection_Backimg.png").getImage());//2.배경이미지 있는 패널 생성
		
		
		
		//텍스트 에리아JTextArea txtArea=new JTextArea();

		//프레임(하나의 툴) 설정
		frame.setTitle("Babsaki");//창의 타이틀
		frame.setVisible(true);	//프레임보이게 만들기
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//JFrame이 정상적으로 종료되게
		frame.setResizable(false);//창의 크기를 변경하지 못하게
		frame.setLayout(null);	 //프레임 레이아웃
		frame.setSize(1216,714);//프레임의 크기
		frame.setLocation(10,10);//창이 가운데 나오게
		
		//프레임에 추가되는 것들
		//frame.add(panel1);		//frame에 panel추가 
		frame.add(imgpanel1);		//frame에 이미지패널 추가
		
		//이미지 패널에 버튼 추가 
		imgpanel1.add(btn1);
		imgpanel1.add(btn2);
		imgpanel1.add(btn3);
		
		
		//버튼1 설정(모닝계란빵)
		btn1.setBounds(170, 250, 276, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btn1.setVisible(true);
		btn1.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\MorningEggBread_result.PNG"));
		
		//버튼2 설정(계란찜)
		btn2.setBounds(450, 250, 276, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btn2.setVisible(true);
		btn2.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\eggscramble_result.PNG"));
		
		//버튼3 설정(마약토스트)
		btn3.setBounds(730, 250, 276, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btn3.setVisible(true);
		btn3.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\Toest.PNG"));
		
		
		
		
		        

		        
	}
}

