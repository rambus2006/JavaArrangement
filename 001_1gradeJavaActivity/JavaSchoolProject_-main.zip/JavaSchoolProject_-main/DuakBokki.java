package Babsakiproject;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JButton;		//JButton추가
import javax.swing.JFrame;		//JFrame추가
import javax.swing.JLabel;
import javax.swing.JPanel;		//JPanel추가
import javax.swing.WindowConstants;
//완성-시간 한번 더 확인하기 
public class DuakBokki extends JFrame{
	DuakBokki(){
		//---------------------------------------------------------------------------떡볶이--------------------------------------------------------
		
		//버튼은 10의 자리 단위로 메뉴가 다름
		JButton btnNextTBK1=new JButton();		//JButton btn1생성
		JButton btnNextTBK2=new JButton();			//JButton btn2생성
		JButton btnNextTBK3=new JButton();		//JButton btn3생성
		JButton btnNextTBK4=new JButton();		//JButton btn4생성
		JButton btnNextTBK5=new JButton();		//JButton btn5생성
		JButton btnNextTBK6=new JButton();		//JButton btn5생성
		JButton btnNextTBK7=new JButton();		//JButton btn5생성
		
		JButton btnBackTBK1=new JButton();		//JButton btn1생성
		JButton btnBackTBK2=new JButton();		//JButton btn1생성
		JButton btnBackTBK3=new JButton();		//JButton btn1생성
		JButton btnBackTBK4=new JButton();		//JButton btn1생성
		JButton btnBackTBK5=new JButton();		//JButton btn1생성
		JButton btnBackTBK6=new JButton();		//JButton btn1생성
		JButton btnBackTBK7=new JButton();		//JButton btn1생성
		JButton btnBackTBK8=new JButton();		//JButton btn1생성
		
		
		ImagePanel panelTBK1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\떡볶이패널\\panelDBK1.png").getImage());//패널 생성
		ImagePanel panelTBK2=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\떡볶이패널\\panelDBK2.png").getImage());//패널 생성
		ImagePanel panelTBK3=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\떡볶이패널\\panelDBK3.png").getImage());//패널 생성
		ImagePanel panelTBK4=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\떡볶이패널\\panelDBK4.png").getImage());//패널 생성
		ImagePanel panelTBK5=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\떡볶이패널\\panelDBK5.png").getImage());//패널 생성
		ImagePanel panelTBK6=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\떡볶이패널\\panelDBK6.png").getImage());//패널 생성
		ImagePanel endpanel6=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\lastpage.png").getImage());//패널 생성
		
		setSize(1216,714);
		setLocation(10,10);
		add(panelTBK1);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setVisible(true);
		
		add(panelTBK2);
		add(panelTBK3);
		add(panelTBK4);
		add(panelTBK5);
		add(panelTBK6);		
		add(endpanel6);	
		

		//자동넘김버튼============================================================================================================

		JButton autobtn=new JButton();
		autobtn.setVisible(true);
		autobtn.setBounds(800, 38, 200, 100);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		autobtn.setBorder(null);
		autobtn.setContentAreaFilled(false);				//버튼 안의 이미지 외곽의 공간을 없애줌
		autobtn.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\autobtn.png"));
		panelTBK1.add(autobtn);
		
		Timer timer = new Timer();
		
		autobtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//40/6(패널개수)=6....., 각 과정당 6분으로 가정했을 때->초 단위로 바꿈
				//1000==1초(밀리세컨 단위)
				TimerTask task= new TimerTask() {
					@Override
					public void run() {
						panelTBK1.setVisible(false);
						panelTBK2.setVisible(true);
					}
				};
				timer.schedule(task, 4000);	//정해진 시간에 실행(4초)
					
				TimerTask task2= new TimerTask() {
					public void run() {
						panelTBK2.setVisible(false);
						panelTBK3.setVisible(true);
					}
				};
				timer.schedule(task2, 10000);	//(실행한 4초+6초=10초)
				
				TimerTask task3= new TimerTask() {
					public void run() {
						panelTBK3.setVisible(false);
						panelTBK4.setVisible(true);
					}
				};
				timer.schedule(task3, 16000); //(실행한10초+6초=16초초)
				
				TimerTask task4= new TimerTask() {
					public void run() {
						panelTBK4.setVisible(false);
						panelTBK5.setVisible(true);
					}
				};
				timer.schedule(task4, 22000);	//(실행한16초+6초=22초)
				
				TimerTask task5= new TimerTask() {
					public void run() {
						panelTBK5.setVisible(false);
						panelTBK6.setVisible(true);
					}
				};
				timer.schedule(task5, 28000);//(실행한22초+6초=28초)
				
				TimerTask task6= new TimerTask() {
					public void run() {
						panelTBK6.setVisible(false);
						endpanel6.setVisible(true);
					}
				};
				timer.schedule(task6, 34000);//(실행한28초+6초=34초)
				
				
			}
			
		});
//---------------------------------------------------------------------떡볶이다음버튼----------------------------------------------------
		
		btnNextTBK1.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextTBK1.setBorder(null);
		btnNextTBK1.setVisible(true);
		btnNextTBK1.setBorderPainted(false);
		btnNextTBK1.setContentAreaFilled(false);
		btnNextTBK1.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
		btnNextTBK1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelTBK1.setVisible(false);
					panelTBK2.setVisible(true);
					
				}
		});
		panelTBK1.add(btnNextTBK1); //panelEGS1에서 panelESG2으로 넘어가는 버튼
		
		btnNextTBK2.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextTBK2.setBorder(null);
		btnNextTBK2.setVisible(true);
		btnNextTBK2.setBorderPainted(false);
		btnNextTBK2.setContentAreaFilled(false);
		btnNextTBK2.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
		btnNextTBK2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelTBK2.setVisible(false);
					panelTBK3.setVisible(true);
					
				}
		});
		panelTBK2.add(btnNextTBK2); //panelEGS2에서 panelESG3으로 넘어가는 버튼
		
		btnNextTBK3.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextTBK3.setBorder(null);
		btnNextTBK3.setVisible(true);
		btnNextTBK3.setBorderPainted(false);
		btnNextTBK3.setContentAreaFilled(false);
		btnNextTBK3.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
		btnNextTBK3.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelTBK3.setVisible(false);
					panelTBK4.setVisible(true);
					
				}
		});
		panelTBK3.add(btnNextTBK3); //panelEGS3에서 panelESG3으로 넘어가는 버튼
		
		btnNextTBK4.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextTBK4.setBorder(null);
		btnNextTBK4.setVisible(true);
		btnNextTBK4.setBorderPainted(false);
		btnNextTBK4.setContentAreaFilled(false);
		btnNextTBK4.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
		btnNextTBK4.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelTBK4.setVisible(false);
					panelTBK5.setVisible(true);
					
				}
		});
		panelTBK4.add(btnNextTBK4); //panelEGS4에서 panelESG5으로 넘어가는 버튼
		
		btnNextTBK5.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextTBK5.setBorder(null);
		btnNextTBK5.setVisible(true);
		btnNextTBK5.setBorderPainted(false);
		btnNextTBK5.setContentAreaFilled(false);
		btnNextTBK5.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
		btnNextTBK5.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelTBK5.setVisible(false);
					panelTBK6.setVisible(true);
					
				}
		});
		panelTBK5.add(btnNextTBK5); //panelEGS5에서 panelESG6으로 넘어가는 버튼
		
		btnNextTBK6.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextTBK6.setBorder(null);
		btnNextTBK6.setVisible(true);
		btnNextTBK6.setBorderPainted(false);
		btnNextTBK6.setContentAreaFilled(false);
		btnNextTBK6.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
		btnNextTBK6.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelTBK6.setVisible(false);
					endpanel6.setVisible(true);
					
				}
		});	
		panelTBK6.add(btnNextTBK6); //panelEGS6에서 엔딩패널5으로 넘어가는 버튼
		
		btnNextTBK7.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextTBK7.setBorder(null);
		btnNextTBK7.setVisible(true);
		btnNextTBK7.setBorderPainted(false);
		btnNextTBK7.setContentAreaFilled(false);
		btnNextTBK7.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\homebtn.png"));
		btnNextTBK7.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					endpanel6.setVisible(false);
					new MenuSelection();
					
				}
		});	
		endpanel6.add(btnNextTBK7); //엔딩패널에서 홈으로 넘어가는 버튼
		
		btnBackTBK1.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackTBK1.setBorder(null);
		btnBackTBK1.setVisible(true);
		btnBackTBK1.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
		btnBackTBK1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelTBK2.setVisible(false);
					panelTBK1.setVisible(true);
					
				}
		});
		panelTBK2.add(btnBackTBK1); //panelEGS1에서 panelESG2으로 넘어가는 버튼
		
		btnBackTBK2.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackTBK2.setBorder(null);
		btnBackTBK2.setVisible(true);
		btnBackTBK2.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
		btnBackTBK2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelTBK3.setVisible(false);
					panelTBK2.setVisible(true);
					
				}
		});
		panelTBK3.add(btnBackTBK2); //panelEGS2에서 panelESG3으로 넘어가는 버튼
		
		btnBackTBK3.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackTBK3.setBorder(null);
		btnBackTBK3.setVisible(true);
		btnBackTBK3.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
		btnBackTBK3.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelTBK4.setVisible(false);
					panelTBK3.setVisible(true);
					
				}
		});
		panelTBK4.add(btnBackTBK3); //panelEGS3에서 panelESG3으로 넘어가는 버튼
		
		btnBackTBK4.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackTBK4.setBorder(null);
		btnBackTBK4.setVisible(true);
		btnBackTBK4.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
		btnBackTBK4.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelTBK5.setVisible(false);
					panelTBK4.setVisible(true);
					
				}
		});
		panelTBK5.add(btnBackTBK4); //panelEGS4에서 panelESG5으로 넘어가는 버튼
		
		btnBackTBK5.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackTBK5.setBorder(null);
		btnBackTBK5.setVisible(true);
		btnBackTBK5.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
		btnBackTBK5.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelTBK6.setVisible(false);
					panelTBK5.setVisible(true);
					
				}
		});
		panelTBK6.add(btnBackTBK5); //panelEGS5에서 panelESG6으로 넘어가는 버튼
		
		
		
	
		
	}
}
