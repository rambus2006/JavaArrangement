package Babsakiproject;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JButton;		//JButton추가
import javax.swing.JFrame;		//JFrame추가
import javax.swing.JLabel;
import javax.swing.JPanel;		//JPanel추가

/*
 * [할일]
 * 로그인페이지 만들기 
 * 별점 패널,별점 주는 기능구현
 * ---------------------------
 * <빨리해야할 것>
 * 메뉴수 2개 추가
 * 메뉴별 타이머 추가해서 시간이 흐르면 자동으로 넘길 수 있는 기능
 */


//Main
public class MenuSelection {
	public MenuSelection() {
		JFrame frame=new JFrame();		//JFrame 생성
		//JPanel panel1=new JPanel();	//JPanel 생성
		//JButton btn0=new JButton();		//JButton btn0생성
		JButton btnMEBselect=new JButton();		//JButton btn1생성
		JButton btnTBKselect=new JButton();		//JButton btn2생성
		JButton btnRBGselect=new JButton();		//JButton btn3생성
		JButton btnTRBselect=new JButton();		//JButton btn4생성
		JButton btnTRKselect=new JButton();		//JButton btn5생성
		JButton btnCOCselect=new JButton();		//JButton btn6생성
		JButton btnBABselect=new JButton();		//JButton btn6생성
		JButton btnTRRselect=new JButton();		//JButton btn6생성
		
		ImagePanel imgpanel1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\Menuselectpage.png").getImage());//2.배경이미지 있는 패널 생성
		ImagePanel panelMEB1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\모닝계란빵\\001.png").getImage());//패널 생성
		ImagePanel panelEGS1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\떡볶이\\001.png").getImage());//패널 생성
		ImagePanel panelBBG1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\밥버거\\001.png").getImage());//패널 생성
		ImagePanel panelTRB1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\참치주먹밥\\001.png").getImage());//패널 생성
		ImagePanel panelTOK1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\식빵러스크\\001.png").getImage());//패널 생성
		ImagePanel panelCOC1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\콘치즈\\001.png").getImage());//패널 생성
		
		//프레임(하나의 툴) 설정
		frame.setTitle("Babsaki");//창의 타이틀
		frame.setVisible(true);	//프레임보이게 만들기
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//JFrame이 정상적으로 종료되게
		frame.setResizable(false);//창의 크기를 변경하지 못하게
		frame.setLayout(null);	 //프레임 레이아웃
		frame.setSize(1216,718);//프레임의 크기
		frame.setLocation(10,10);//창이 가운데 나오게하기 
		
		//프레임에 추가되는 것들
		frame.add(imgpanel1);						//frame에 이미지패널 추가
		frame.getContentPane().add(panelMEB1);		//frame에 panelMEB1 추가 
		panelMEB1.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
		frame.getContentPane().add(panelEGS1);		//frame에 panelMEB2 추가 
		panelEGS1.setVisible(false);				//처음화면에 panelMEB2 보이지 않게 하기 
		frame.getContentPane().add(panelBBG1);		//처음화면에 panelMEB3 보이지 않게 하기 
		panelBBG1.setVisible(false);				//처음화면에 panelMEB3 보이지 않게 하기 
		frame.getContentPane().add(panelTRB1);			//처음화면에 panelMEB4 보이지 않게 하기 
		panelTRB1.setVisible(false);				//처음화면에 panelMEB4 보이지 않게 하기 
		frame.getContentPane().add(panelTOK1);			//처음화면에 panelMEB5 보이지 않게 하기 
		panelTOK1.setVisible(false);				//처음화면에 panelMEB5 보이지 않게 하기 
		frame.getContentPane().add(panelCOC1);			//처음화면에 panelMEB6 보이지 않게 하기 
		panelCOC1.setVisible(false);				//처음화면에 panelMEB6 보이지 않게 하기 
		
		//다른 Frame 추가
		
		StopWatch stopwatch=new StopWatch();		//스톱워치 추가 
		new MyFrame();
		
		//이미지 패널에 버튼 추가 
		imgpanel1.add(btnMEBselect);	//모닝계란빵 버튼
		imgpanel1.add(btnTBKselect);	//계란찜 버튼 
		imgpanel1.add(btnRBGselect);	//마약토스트버튼
		imgpanel1.add(btnTRBselect);
		imgpanel1.add(btnTRKselect);
		imgpanel1.add(btnCOCselect);
		imgpanel1.add(btnBABselect);
		imgpanel1.add(btnTRRselect);
		
			
		//버튼1 설정(모닝계란빵)-이미지 픽셀에 맞게 바꾸기 
		btnMEBselect.setVisible(true);
		btnMEBselect.setBounds(315, 250, 280, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnMEBselect.setBorder(null);
		btnMEBselect.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\메뉴선택이미지\\002.png"));
		btnMEBselect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MorningEggBread();
				frame.setVisible(false);
				
			}
		});

		
		//버튼2 설정(떡볶이)
		btnTBKselect.setBounds(600, 250, 280, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnTBKselect.setBorder(null);
		btnTBKselect.setVisible(true);
		btnTBKselect.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\메뉴선택이미지\\003.png"));
		btnTBKselect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					new DuakBokki();
					frame.setVisible(false);
			}
		});
		
		
		//버튼3 설정(밥버거)
		btnRBGselect.setBounds(885, 250, 280, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnRBGselect.setBorder(null);
		btnRBGselect.setVisible(true);
		btnRBGselect.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\메뉴선택이미지\\006.png"));
		btnRBGselect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RiceBurger();
				frame.setVisible(false);
			}
		});
		
		//버튼4 설정(참치주먹밥)
		btnTRBselect.setBounds(315, 452, 280, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnTRBselect.setBorder(null);		
		btnTRBselect.setVisible(true);
		btnTRBselect.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\메뉴선택이미지\\004.png"));
		btnTRBselect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new TunaRiceBalls();
				frame.setVisible(false);
			}
		});
		//버튼5 설정(식빵러스크)
		btnTRKselect.setBounds(600, 452, 280, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnTRKselect.setBorder(null);
		btnTRKselect.setVisible(true);
		btnTRKselect.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\메뉴선택이미지\\005.png"));
		btnTRKselect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new  breadRusk();
				frame.setVisible(false);
				
			}
		});
		//콘치즈선택버튼 
		btnCOCselect.setBounds(885, 452, 280, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnCOCselect.setBorder(null);
		btnCOCselect.setVisible(true);
		btnCOCselect.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\메뉴선택이미지\\001.png"));
		btnCOCselect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new CornChese();
				frame.setVisible(false);
				
			}
		});
		//삼각김밥
				btnTRRselect.setBounds(28, 250, 280, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnTRRselect.setBorder(null);
				btnTRRselect.setVisible(true);
				btnTRRselect.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\메뉴선택이미지\\007.png"));
				btnTRRselect.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						new TriangularRolledRiceGimbap();
						frame.setVisible(false);
						
					}
				});
				
		//보리빵
		btnBABselect.setBounds(28,452, 280, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBABselect.setBorder(null);
		btnBABselect.setVisible(true);
		btnBABselect.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\메뉴선택이미지\\008.png"));
		btnBABselect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new barleyBread();
				frame.setVisible(false);
				
			}
		});
		
	}
		public static void main(String args[]) {
				new MenuSelection();	//처음화면 생성자 호출

		}
	}//Main class 끝
	
//메뉴 선택화면 클래스 
class ImagePanel extends JPanel{
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image img;	
	
	public ImagePanel(Image img) {
		this.img=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(img, 0, 0, null);				//(0,0)은 x,y값
	}
}


















