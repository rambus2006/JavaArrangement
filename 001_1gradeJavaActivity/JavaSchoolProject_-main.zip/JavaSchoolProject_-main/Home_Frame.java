package BabsakiProject;


import java.awt.*;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

//HomePanel에 이미지 넣기 
public class Home_Frame extends JFrame {
	static JPanel page1=new JPanel() {
		Image background=new ImageIcon(Home_Frame.class.getResource("../image/MenuSelection_Backimg.png")).getImage();
		public void paint(Graphics g) {				//그리는 함수
				g.drawImage(background, 0,0, null);//background를 그려줌		
		}
	};

	
		/*생성자입니다.*/
		public Home_Frame() {
			homeframe();
		}
		public void homeframe() {
			setTitle("Babsaki");//창의 타이틀
			setSize(1216,714);//프레임의 크기
			setLocation(10,10);//창이 가운데 나오게
			setResizable(false);//창의 크기를 변경하지 못하게
			setLayout(null);
			setVisible(true);//창이 보이게	
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//JFrame이 정상적으로 종료되게
			
			page1.setLayout(null);
			page1.setBounds(0, 0,1200,680);
			add(page1);
			
	}
	

			
	
	//main창
	public static void main(String[] args){
			new Home_Frame();

			//홈화면에서의 단호박그라탕 버튼
			ImageIcon Introductionimg_b1 = new ImageIcon("E:\\1409방민서java\\밥새끼음식사진\\모닝계란빵\\모닝계란빵\\MorningEggBread_result.png");		//사진 불러오기
			//버튼크기에 맞게 사진 크기 조정하기 
			Image Introductionimg_b1Size=Introductionimg_b1.getImage();												
			Image changeIntroductionimg_b1=Introductionimg_b1Size.getScaledInstance(276,250,Image.SCALE_SMOOTH);		
			ImageIcon Introduction_b1=new ImageIcon(changeIntroductionimg_b1);
			
			//소개화면 사진 버튼 만들기 
			JButton Introduction=new JButton(Introduction_b1);													//버튼에 사진넣기 															//버튼 크기 
			Introduction.setBounds(170, 250, 276, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			Introduction.setVisible(true);
			page1.add(Introduction);	
			//창 바꾸기 
			Introduction.addActionListener(new ActionListener(){
		
			
				@Override
				public void actionPerformed(ActionEvent arg0) {
					MorningEggBread p1=new MorningEggBread();
					
					p1.page2_1.setVisible(true);
					page1.setVisible(false);
				}
			});
			
	}	
	
}

	



