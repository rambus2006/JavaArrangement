package Babsakiproject;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JButton;		//JButton추가
import javax.swing.JFrame;		//JFrame추가
import javax.swing.JLabel;
import javax.swing.JPanel;		//JPanel추가
import javax.swing.WindowConstants;

//보리빵 완성
public class barleyBread extends JFrame {
	barleyBread(){
		JButton btnNextBAB0=new JButton();		//JButton btn1생성
		JButton btnNextBAB1=new JButton();		//JButton btn1생성
		JButton btnNextBAB2=new JButton();			//JButton btn2생성
		JButton btnNextBAB3=new JButton();		//JButton btn3생성
		JButton btnNextBAB4=new JButton();		//JButton btn4생성
		JButton btnNextBAB5=new JButton();		//JButton btn5생성
		JButton btnNextBAB6=new JButton();		//JButton btn5생성
		
		JButton btnBackBAB1=new JButton();		//JButton btn1생성
		JButton btnBackBAB2=new JButton();		//JButton btn1생성
		JButton btnBackBAB3=new JButton();		//JButton btn1생성
		JButton btnBackBAB4=new JButton();		//JButton btn1생성
		JButton btnBackBAB5=new JButton();		//JButton btn1생성
		JButton btnBackBAB6=new JButton();		//JButton btn1생성
		
		
		ImagePanel panelBAB1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\보리빵\\001.png").getImage());//패널 생성
		ImagePanel panelBAB2=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\보리빵\\02.png").getImage());//패널 생성
		ImagePanel panelBAB3=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\보리빵\\003.png").getImage());//패널 생성
		ImagePanel panelBAB4=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\보리빵\\004.png").getImage());//패널 생성
		ImagePanel panelBAB5=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\보리빵\\005.png").getImage());//패널 생성
		ImagePanel endpanel7=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\lastpage.png").getImage());//패널 생성
		
		setSize(1216,714);
		setLocation(10,10);
		add(panelBAB1);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setVisible(true);
		
		add(panelBAB2);
		add(panelBAB3);
		add(panelBAB4);
		add(panelBAB5);
		add(endpanel7);
		
		
		
		//다음버튼
				btnNextBAB0.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextBAB0.setBorder(null);
				btnNextBAB0.setVisible(true);
				btnNextBAB0.setBorderPainted(false);
				btnNextBAB0.setContentAreaFilled(false);
				btnNextBAB0.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
				btnNextBAB0.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
							panelBAB1.setVisible(false);
							panelBAB2.setVisible(true);
							
						}
				});
				panelBAB1.add(btnNextBAB0); //panelBBG1에서 2으로 넘어가는 버튼
				
				
				btnNextBAB1.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextBAB1.setBorder(null);
				btnNextBAB1.setVisible(true);
				btnNextBAB1.setBorderPainted(false);
				btnNextBAB1.setContentAreaFilled(false);
				btnNextBAB1.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
				btnNextBAB1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
							panelBAB2.setVisible(false);
							panelBAB3.setVisible(true);
							
						}
				});
				panelBAB2.add(btnNextBAB1); //panelBBG1에서 2으로 넘어가는 버튼
				
				
				btnNextBAB2.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextBAB2.setBorder(null);
				btnNextBAB2.setVisible(true);
				btnNextBAB2.setBorderPainted(false);
				btnNextBAB2.setContentAreaFilled(false);
				btnNextBAB2.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
				btnNextBAB2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
							panelBAB3.setVisible(false);
							panelBAB4.setVisible(true);
							
						}
				});
				panelBAB3.add(btnNextBAB2); //panelBBG2에서 3으로 넘어가는 버튼
				

				btnNextBAB3.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextBAB3.setBorder(null);
				btnNextBAB3.setVisible(true);
				btnNextBAB3.setBorderPainted(false);
				btnNextBAB3.setContentAreaFilled(false);
				btnNextBAB3.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
				btnNextBAB3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
							panelBAB4.setVisible(false);
							panelBAB5.setVisible(true);
							
						}
				});
				panelBAB4.add(btnNextBAB3); //panelBBG3에서 4으로 넘어가는 버튼
				
				btnNextBAB4.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextBAB4.setBorder(null);
				btnNextBAB4.setVisible(true);
				btnNextBAB4.setBorderPainted(false);
				btnNextBAB4.setContentAreaFilled(false);
				btnNextBAB4.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
				btnNextBAB4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
						panelBAB5.setVisible(false);
						endpanel7.setVisible(true);
							
						}
				});
				panelBAB5.add(btnNextBAB4); //panelBBG4에서 5으로 넘어가는 버튼
				
				btnNextBAB5.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnNextBAB5.setBorder(null);
				btnNextBAB5.setVisible(true);
				btnNextBAB5.setBorderPainted(false);
				btnNextBAB5.setContentAreaFilled(false);
				btnNextBAB5.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\homebtn.png"));
				btnNextBAB5.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
							endpanel7.setVisible(false);
							new MenuSelection();
						}
				});
				endpanel7.add(btnNextBAB5); //panelBBG5에서 6으로 넘어가는 버튼
			
				//이전버튼 =======================================================================================================================
				btnBackBAB1.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnBackBAB1.setBorder(null);
				btnBackBAB1.setVisible(true);
				btnBackBAB1.setBorderPainted(false);
				btnBackBAB1.setContentAreaFilled(false);
				btnBackBAB1.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\backbtn.png"));
				btnBackBAB1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					panelBAB2.setVisible(false);
					panelBAB1.setVisible(true);
							
						}
				});
				panelBAB2.add(btnBackBAB1); //panelBBG1에서 2으로 넘어가는 버튼
				
				
				btnBackBAB2.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnBackBAB2.setBorder(null);
				btnBackBAB2.setVisible(true);
				btnBackBAB2.setBorderPainted(false);
				btnBackBAB2.setContentAreaFilled(false);
				btnBackBAB2.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\backbtn.png"));
				btnBackBAB2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					panelBAB3.setVisible(false);
					panelBAB2.setVisible(true);
							
						}
				});
				panelBAB3.add(btnBackBAB2); //panelBBG2에서 3으로 넘어가는 버튼
				

				btnBackBAB3.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnBackBAB3.setBorder(null);
				btnBackBAB3.setVisible(true);
				btnBackBAB3.setBorderPainted(false);
				btnBackBAB3.setContentAreaFilled(false);
				btnBackBAB3.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\backbtn.png"));
				btnBackBAB3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					panelBAB4.setVisible(false);
					panelBAB3.setVisible(true);
							
						}
				});
				panelBAB4.add(btnBackBAB3); //panelBBG3에서 4으로 넘어가는 버튼
				
				btnBackBAB4.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnBackBAB4.setBorder(null);
				btnBackBAB4.setVisible(true);
				btnBackBAB4.setBorderPainted(false);
				btnBackBAB4.setContentAreaFilled(false);
				btnBackBAB4.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\backbtn.png"));
				btnBackBAB4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					panelBAB5.setVisible(false);
					panelBAB4.setVisible(true);
							
						}
				});
				panelBAB5.add(btnBackBAB4); //panelBBG4에서 5으로 넘어가는 버튼
				
			
	}
}
