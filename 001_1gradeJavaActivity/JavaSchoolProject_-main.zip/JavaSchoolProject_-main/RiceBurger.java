package Babsakiproject;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JButton;		//JButton추가
import javax.swing.JFrame;		//JFrame추가
import javax.swing.JLabel;
import javax.swing.JPanel;		//JPanel추가
import javax.swing.WindowConstants;

// 완성
public class RiceBurger extends JFrame{
	RiceBurger(){
		//버튼은 10의 자리 단위로 메뉴가 다름
		JButton btnNextRBG1=new JButton();		//JButton btn1생성
		JButton btnNextRBG2=new JButton();			//JButton btn2생성
		JButton btnNextRBG3=new JButton();		//JButton btn3생성
		JButton btnNextRBG4=new JButton();		//JButton btn4생성
		JButton btnNextRBG5=new JButton();		//JButton btn5생성
		JButton btnNextRBG6=new JButton();		//JButton btn5생성
		JButton btnNextRBG7=new JButton();		//JButton btn5생성
		
		//밥버거 이전버튼
		JButton btnBackRBG1=new JButton();		//JButton btn1생성
		JButton btnBackRBG2=new JButton();			//JButton btn2생성
		JButton btnBackRBG3=new JButton();		//JButton btn3생성
		JButton btnBackRBG4=new JButton();		//JButton btn4생성
		JButton btnBackRBG5=new JButton();		//JButton btn5생성
		JButton btnBackRBG6=new JButton();		//JButton btn5생성
		JButton btnBackRBG7=new JButton();		//JButton btn5생성
			
		ImagePanel panelRBG1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\밥버거패널\\001.png").getImage());//패널 생성
		ImagePanel panelRBG2=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\밥버거패널\\002.png").getImage());//패널 생성
		ImagePanel panelRBG3=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\밥버거패널\\003.png").getImage());//패널 생성
		ImagePanel panelRBG4=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\밥버거패널\\004.png").getImage());//패널 생성
		ImagePanel panelRBG5=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\밥버거패널\\005.png").getImage());//패널 생성
		ImagePanel panelRBG6=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\밥버거패널\\006.png").getImage());//패널 생성
		ImagePanel endpanel5=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\lastpage.png").getImage());//패널 생성
		
		setSize(1216,714);
		setLocation(10,10);
		add(panelRBG1);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setVisible(true);
		
		add(panelRBG1);
		add(panelRBG2);
		add(panelRBG3);
		add(panelRBG4);
		add(panelRBG5);
		add(endpanel5);
		
		//자동넘김버튼============================================================================================================

		JButton autobtn=new JButton();
		autobtn.setVisible(true);
		autobtn.setBounds(800, 38, 200, 100);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		autobtn.setBorder(null);
		autobtn.setContentAreaFilled(false);				//버튼 안의 이미지 외곽의 공간을 없애줌
		autobtn.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\autobtn.png"));
		panelRBG1.add(autobtn);
		
		Timer timer = new Timer();
		
		autobtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//30/5=6, 각 과정당 6분으로 가정했을 때->초 단위로 바꿈
				//1000==1초(밀리세컨 단위)
				TimerTask task= new TimerTask() {
					@Override
					public void run() {
						panelRBG1.setVisible(false);
						panelRBG2.setVisible(true);
					}
				};
				timer.schedule(task, 3000);	//정해진 시간에 실행(1초)
					
				TimerTask task2= new TimerTask() {
					public void run() {
						panelRBG2.setVisible(false);
						panelRBG3.setVisible(true);
					}
				};
				timer.schedule(task2, 9000);	//(실행한 3초+6초=9초)
				
				TimerTask task3= new TimerTask() {
					public void run() {
						panelRBG3.setVisible(false);
						panelRBG4.setVisible(true);
					}
				};
				timer.schedule(task3, 15000); //(실행한9초+6초=15초)
				
				TimerTask task4= new TimerTask() {
					public void run() {
						panelRBG4.setVisible(false);
						panelRBG5.setVisible(true);
					}
				};
				timer.schedule(task4, 21000);	//(실행한15초+6초=21초)
				
				TimerTask task5= new TimerTask() {
					public void run() {
						panelRBG5.setVisible(false);
						panelRBG6.setVisible(true);
					}
				};
				timer.schedule(task5, 27000);//(실행한21초+6초=27초)
				
				TimerTask task6= new TimerTask() {
					public void run() {
						panelRBG6.setVisible(false);
						endpanel5.setVisible(true);
					}
				};
				timer.schedule(task6, 33000);//(실행한27초+6초=33초)
			}
			
		});
		
		//다음버튼
		btnNextRBG1.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextRBG1.setBorder(null);
		btnNextRBG1.setVisible(true);
		btnNextRBG1.setBorderPainted(false);
		btnNextRBG1.setContentAreaFilled(false);
		btnNextRBG1.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
		btnNextRBG1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelRBG1.setVisible(false);
					panelRBG2.setVisible(true);
					
				}
		});
		panelRBG1.add(btnNextRBG1); //panelBBG1에서 2으로 넘어가는 버튼
		
		
		btnNextRBG2.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextRBG2.setBorder(null);
		btnNextRBG2.setVisible(true);
		btnNextRBG2.setBorderPainted(false);
		btnNextRBG2.setContentAreaFilled(false);
		btnNextRBG2.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
		btnNextRBG2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelRBG2.setVisible(false);
					panelRBG3.setVisible(true);
					
				}
		});
		panelRBG2.add(btnNextRBG2); //panelBBG2에서 3으로 넘어가는 버튼
		

		btnNextRBG3.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextRBG3.setBorder(null);
		btnNextRBG3.setVisible(true);
		btnNextRBG3.setBorderPainted(false);
		btnNextRBG3.setContentAreaFilled(false);
		btnNextRBG3.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
		btnNextRBG3.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelRBG3.setVisible(false);
					panelRBG4.setVisible(true);
					
				}
		});
		panelRBG3.add(btnNextRBG3); //panelBBG3에서 4으로 넘어가는 버튼
		
		btnNextRBG4.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextRBG4.setBorder(null);
		btnNextRBG4.setVisible(true);
		btnNextRBG4.setBorderPainted(false);
		btnNextRBG4.setContentAreaFilled(false);
		btnNextRBG4.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
		btnNextRBG4.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelRBG4.setVisible(false);
					panelRBG5.setVisible(true);
					
				}
		});
		panelRBG4.add(btnNextRBG4); //panelBBG4에서 5으로 넘어가는 버튼
		
		btnNextRBG5.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextRBG5.setBorder(null);
		btnNextRBG5.setVisible(true);
		btnNextRBG5.setBorderPainted(false);
		btnNextRBG5.setContentAreaFilled(false);
		btnNextRBG5.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
		btnNextRBG5.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelRBG5.setVisible(false);
					panelRBG6.setVisible(true);
					
				}
		});
		panelRBG5.add(btnNextRBG5); //panelBBG5에서 6으로 넘어가는 버튼
		
		btnNextRBG6.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextRBG6.setBorder(null);
		btnNextRBG6.setVisible(true);
		btnNextRBG6.setBorderPainted(false);
		btnNextRBG6.setContentAreaFilled(false);
		btnNextRBG6.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\nextbtn.png"));
		btnNextRBG6.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelRBG6.setVisible(false);
					endpanel5.setVisible(true);
					
				}
		});		
		panelRBG6.add(btnNextRBG6); //panelBBG6에서 엔딩패널으로 넘어가는 버튼
		
		btnNextRBG7.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextRBG7.setBorder(null);
		btnNextRBG7.setVisible(true);
		btnNextRBG7.setBorderPainted(false);
		btnNextRBG7.setContentAreaFilled(false);
		btnNextRBG7.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\homebtn.png"));
		btnNextRBG7.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					endpanel5.setVisible(false);
					new MenuSelection();
					
				}
		});		
		endpanel5.add(btnNextRBG7); //panelBBG6에서 엔딩패널으로 넘어가는 버튼
		
	//이전버튼 =======================================================================================================================
		btnBackRBG1.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackRBG1.setBorder(null);
		btnBackRBG1.setVisible(true);
		btnBackRBG1.setBorderPainted(false);
		btnBackRBG1.setContentAreaFilled(false);
		btnBackRBG1.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\backbtn.png"));
		btnBackRBG1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelRBG2.setVisible(false);
					panelRBG1.setVisible(true);
					
				}
		});
		panelRBG2.add(btnBackRBG1); //panelBBG1에서 2으로 넘어가는 버튼
		
		
		btnBackRBG2.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackRBG2.setBorder(null);
		btnBackRBG2.setVisible(true);
		btnBackRBG2.setBorderPainted(false);
		btnBackRBG2.setContentAreaFilled(false);
		btnBackRBG2.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\backbtn.png"));
		btnBackRBG2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelRBG3.setVisible(false);
					panelRBG2.setVisible(true);
					
				}
		});
		panelRBG3.add(btnBackRBG2); //panelBBG2에서 3으로 넘어가는 버튼
		

		btnBackRBG3.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackRBG3.setBorder(null);
		btnBackRBG3.setVisible(true);
		btnBackRBG3.setBorderPainted(false);
		btnBackRBG3.setContentAreaFilled(false);
		btnBackRBG3.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\backbtn.png"));
		btnBackRBG3.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelRBG4.setVisible(false);
					panelRBG3.setVisible(true);
					
				}
		});
		panelRBG4.add(btnBackRBG3); //panelBBG3에서 4으로 넘어가는 버튼
		
		btnBackRBG4.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackRBG4.setBorder(null);
		btnBackRBG4.setVisible(true);
		btnBackRBG4.setBorderPainted(false);
		btnBackRBG4.setContentAreaFilled(false);
		btnBackRBG4.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\backbtn.png"));
		btnBackRBG4.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelRBG5.setVisible(false);
					panelRBG4.setVisible(true);
					
				}
		});
		panelRBG5.add(btnBackRBG4); //panelBBG4에서 5으로 넘어가는 버튼
		
		btnBackRBG5.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackRBG5.setBorder(null);
		btnBackRBG5.setVisible(true);
		btnBackRBG5.setBorderPainted(false);
		btnBackRBG5.setContentAreaFilled(false);
		btnBackRBG5.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\버튼이미지\\backbtn.png"));
		btnBackRBG5.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelRBG6.setVisible(false);
					endpanel5.setVisible(true);
					
				}
		});
		panelRBG6.add(btnBackRBG5); //panelBBG5에서 6으로 넘어가는 버튼
		
	
		
		
	}
	

}
