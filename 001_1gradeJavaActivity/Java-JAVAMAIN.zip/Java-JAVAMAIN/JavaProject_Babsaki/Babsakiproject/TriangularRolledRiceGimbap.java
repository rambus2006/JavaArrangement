package Babsakiproject;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JButton;		//JButton추가
import javax.swing.JFrame;		//JFrame추가
import javax.swing.JLabel;
import javax.swing.JPanel;		//JPanel추가
import javax.swing.WindowConstants;
//삼각김밥버튼 완성
public class TriangularRolledRiceGimbap extends JFrame{
	TriangularRolledRiceGimbap(){
		JButton btnNextTRR1=new JButton();		//JButton btn1생성
		JButton btnNextTRR2=new JButton();			//JButton btn2생성
		JButton btnNextTRR3=new JButton();		//JButton btn3생성
		JButton btnNextTRR4=new JButton();		//JButton btn4생성
		JButton btnNextTRR5=new JButton();		//JButton btn5생성
		JButton btnNextTRR6=new JButton();		//JButton btn5생성
		JButton btnNextTRR7=new JButton();		//JButton btn5생성
		
		JButton btnBackTRR1=new JButton();		//JButton btn1생성
		JButton btnBackTRR2=new JButton();			//JButton btn2생성
		JButton btnBackTRR3=new JButton();		//JButton btn3생성
		JButton btnBackTRR4=new JButton();		//JButton btn4생성
		JButton btnBackTRR5=new JButton();		//JButton btn5생성
		JButton btnBackTRR6=new JButton();		//JButton btn5생성
		JButton btnBackTRR7=new JButton();		//JButton btn5생성
		
		ImagePanel panelTRR1=new ImagePanel(new ImageIcon("./삼각김밥/001.png").getImage());//패널 생성
		ImagePanel panelTRR2=new ImagePanel(new ImageIcon("./삼각김밥/002.png").getImage());//패널 생성
		ImagePanel panelTRR3=new ImagePanel(new ImageIcon("./삼각김밥/003.png").getImage());//패널 생성
		ImagePanel panelTRR4=new ImagePanel(new ImageIcon("./삼각김밥/004.png").getImage());//패널 생성
		ImagePanel panelTRR5=new ImagePanel(new ImageIcon("./삼각김밥/005.png").getImage());//패널 생성
		ImagePanel endpanel8=new ImagePanel(new ImageIcon("./기타이미지/lastpage.png").getImage());//패널 생성
		
		setSize(1216,714);
		setLocation(10,10);
		add(panelTRR1);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setVisible(true);
		
		add(panelTRR2);
		add(panelTRR3);
		add(panelTRR4);
		add(panelTRR5);
		add(endpanel8);
		
		//자동넘김버튼---------------------------------------------------------------------------------------------
		
		JButton autobtn=new JButton();
		autobtn.setVisible(true);
		autobtn.setBounds(800, 38, 200, 100);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		autobtn.setBorder(null);
		autobtn.setContentAreaFilled(false);				//버튼 안의 이미지 외곽의 공간을 없애줌
		autobtn.setIcon(new ImageIcon("./버튼이미지/autobtn.png"));
		panelTRR1.add(autobtn);
		
		Timer timer = new Timer();
		
		autobtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//30/5=6, 각 과정당 6분으로 가정했을 때->초 단위로 바꿈
				//1000==1초(밀리세컨 단위)
				TimerTask task= new TimerTask() {
					@Override
					public void run() {
						panelTRR1.setVisible(false);
						panelTRR2.setVisible(true);
					}
				};
				timer.schedule(task, 1000);	//정해진 시간에 실행(1초)
					
				TimerTask task2= new TimerTask() {
					public void run() {
						panelTRR2.setVisible(false);
						panelTRR3.setVisible(true);
					}
				};
				timer.schedule(task2, 7000);	//(실행한 1초+6초=7초)
				
				TimerTask task3= new TimerTask() {
					public void run() {
						panelTRR3.setVisible(false);
						panelTRR4.setVisible(true);
					}
				};
				timer.schedule(task3, 13000); //(실행한7초+6초=13초)
				
				TimerTask task4= new TimerTask() {
					public void run() {
						panelTRR4.setVisible(false);
						panelTRR5.setVisible(true);
					}
				};
				timer.schedule(task4, 19000);	//(실행한13초+6초=19초)
				
				TimerTask task5= new TimerTask() {
					public void run() {
						panelTRR5.setVisible(false);
						endpanel8.setVisible(true);
					}
				};
				timer.schedule(task5, 25000);//(실행한19초+6초=25초)
			}
			
		});
		
		
		
		//다음버튼
		btnNextTRR1.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextTRR1.setBorder(null);
		btnNextTRR1.setVisible(true);
		btnNextTRR1.setBorderPainted(false);
		btnNextTRR1.setContentAreaFilled(false);
		btnNextTRR1.setIcon(new ImageIcon("./버튼이미지/nextbtn.png"));
		btnNextTRR1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			panelTRR1.setVisible(false);
			panelTRR2.setVisible(true);
					
				}
		});
		panelTRR1.add(btnNextTRR1); //panelBBG1에서 2으로 넘어가는 버튼
		
		
		btnNextTRR2.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextTRR2.setBorder(null);
		btnNextTRR2.setVisible(true);
		btnNextTRR2.setBorderPainted(false);
		btnNextTRR2.setContentAreaFilled(false);
		btnNextTRR2.setIcon(new ImageIcon("./버튼이미지/nextbtn.png"));
		btnNextTRR2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			panelTRR2.setVisible(false);
			panelTRR3.setVisible(true);
					
				}
		});
		panelTRR2.add(btnNextTRR2); //panelBBG2에서 3으로 넘어가는 버튼
		

		btnNextTRR3.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextTRR3.setBorder(null);
		btnNextTRR3.setVisible(true);
		btnNextTRR3.setBorderPainted(false);
		btnNextTRR3.setContentAreaFilled(false);
		btnNextTRR3.setIcon(new ImageIcon("./버튼이미지/nextbtn.png"));
		btnNextTRR3.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			panelTRR3.setVisible(false);
			panelTRR4.setVisible(true);
					
				}
		});
		panelTRR3.add(btnNextTRR3); //panelBBG3에서 4으로 넘어가는 버튼
		
		btnNextTRR4.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextTRR4.setBorder(null);
		btnNextTRR4.setVisible(true);
		btnNextTRR4.setBorderPainted(false);
		btnNextTRR4.setContentAreaFilled(false);
		btnNextTRR4.setIcon(new ImageIcon("./버튼이미지/nextbtn.png"));
		btnNextTRR4.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			panelTRR4.setVisible(false);
			panelTRR5.setVisible(true);
					
				}
		});
		panelTRR4.add(btnNextTRR4); //panelBBG4에서 5으로 넘어가는 버튼
		
		btnNextTRR5.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextTRR5.setBorder(null);
		btnNextTRR5.setVisible(true);
		btnNextTRR5.setBorderPainted(false);
		btnNextTRR5.setContentAreaFilled(false);
		btnNextTRR5.setIcon(new ImageIcon("./버튼이미지/nextbtn.png"));
		btnNextTRR5.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			panelTRR5.setVisible(false);
			endpanel8.setVisible(true);
					
				}
		});
		panelTRR5.add(btnNextTRR5); //panelBBG5에서 6으로 넘어가는 버튼
		
		btnNextTRR6.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextTRR6.setBorder(null);
		btnNextTRR6.setVisible(true);
		btnNextTRR6.setBorderPainted(false);
		btnNextTRR6.setContentAreaFilled(false);
		btnNextTRR6.setIcon(new ImageIcon("./버튼이미지/homebtn.png"));
		btnNextTRR6.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					endpanel8.setVisible(false);
					new MenuSelection();
				}
		});		
		endpanel8.add(btnNextTRR6); //panelBBG6에서 엔딩패널으로 넘어가는 버튼
		
		btnBackTRR1.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackTRR1.setBorder(null);
		btnBackTRR1.setVisible(true);
		btnBackTRR1.setBorderPainted(false);
		btnBackTRR1.setContentAreaFilled(false);
		btnBackTRR1.setIcon(new ImageIcon("./버튼이미지/backbtn.png"));
		btnBackTRR1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelTRR2.setVisible(false);
					panelTRR1.setVisible(true);
					
				}
		});
		panelTRR2.add(btnBackTRR1); //panelBBG1에서 2으로 넘어가는 버튼
		
		
		btnBackTRR2.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackTRR2.setBorder(null);
		btnBackTRR2.setVisible(true);
		btnBackTRR2.setBorderPainted(false);
		btnBackTRR2.setContentAreaFilled(false);
		btnBackTRR2.setIcon(new ImageIcon("./버튼이미지/backbtn.png"));
		btnBackTRR2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			panelTRR3.setVisible(false);
			panelTRR2.setVisible(true);
					
				}
		});
		panelTRR3.add(btnBackTRR2); //panelBBG2에서 3으로 넘어가는 버튼
		

		btnBackTRR3.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackTRR3.setBorder(null);
		btnBackTRR3.setVisible(true);
		btnBackTRR3.setBorderPainted(false);
		btnBackTRR3.setContentAreaFilled(false);
		btnBackTRR3.setIcon(new ImageIcon("./버튼이미지/backbtn.png"));
		btnBackTRR3.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			panelTRR4.setVisible(false);
			panelTRR3.setVisible(true);
					
				}
		});
		panelTRR4.add(btnBackTRR3); //panelBBG3에서 4으로 넘어가는 버튼
		
		btnBackTRR4.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackTRR4.setBorder(null);
		btnBackTRR4.setVisible(true);
		btnBackTRR4.setBorderPainted(false);
		btnBackTRR4.setContentAreaFilled(false);
		btnBackTRR4.setIcon(new ImageIcon("./버튼이미지/backbtn.png"));
		btnBackTRR4.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			panelTRR5.setVisible(false);
			panelTRR4.setVisible(true);
					
				}
		});
		panelTRR5.add(btnBackTRR4); //panelBBG4에서 5으로 넘어가는 버튼
		
		
		
	}
}
