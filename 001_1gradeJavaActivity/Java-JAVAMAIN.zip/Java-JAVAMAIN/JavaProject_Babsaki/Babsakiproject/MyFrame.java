package Babsakiproject;

import java.awt.Color;
import java.awt.event.*;
import javax.swing.*;
//냉장고 버튼

public class MyFrame extends JFrame implements MouseListener{
	
	JButton refrigerator;
	JWindow w = new JWindow(); //타이틀 바 제거를 위해 넣음
	
	MyFrame(){
		//this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		refrigerator=new JButton();
		refrigerator.setBounds(90,50,210,200);
		refrigerator.setOpaque(true);
		refrigerator.addMouseListener(this);
		refrigerator.setBorderPainted(false);
		refrigerator.setContentAreaFilled(false);
		refrigerator.setIcon(new ImageIcon("./검색재료이미지/냉장고1_2.png"));
		refrigerator.setBorder(null);
		
		
		w.setSize(370,300);
		w.setLocation(1230,400);
		w.setLayout(null);
		w.setVisible(true);
		w.getContentPane().setBackground(Color.white);
		w.add(refrigerator);
	
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("클릭");
		Search s1= new Search();
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		//System.out.println("너는 마우스를 눌렀어");
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		//System.out.println("너는 마우스를 놨어");
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		refrigerator.setIcon(new ImageIcon("./검색재료이미지/냉장고2_2.png"));
		
	}
	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		refrigerator.setIcon(new ImageIcon("./검색재료이미지/냉장고1_2.png"));
	}
	

}
