package Babsakiproject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class itemeventsample extends JFrame implements ItemListener {
    JLabel lb;
    JPanel pn;
    JTextArea ta;
    JCheckBox cb1, cb2, cb3;
    
    public itemeventsample() {
        setTitle("체크박스 이벤트");
        lb = new JLabel("항목을 선택하시오");
        ta = new JTextArea();
        cb1 = new JCheckBox("딸기");
        cb2 = new JCheckBox("바나나");
        cb3 = new JCheckBox("사과");
        cb1.addItemListener(this);
        cb2.addItemListener(this);
        cb3.addItemListener(this);
        
        pn = new JPanel();
        pn.add(cb1);
        pn.add(cb2);
        pn.add(cb3);
        
        add("North",lb);
        add("Center",ta);
        add("South",pn);
        setSize(300,200);
        setVisible(true);
    }
    public void itemStateChanged(ItemEvent e) {
        if(cb1.isSelected())  // cb1가 선택된다면
            ta.append("\n베리베리스트로베리!");
        if(cb2.isSelected())  // cb2가 선택된다면
            ta.append("\n뻐내노!");
        if(cb3.isSelected())  // cb3가 선택된다면
            ta.append("\n모닝애플!");
    }
    
    public static void main(String [] args) {
        itemeventsample ies = new itemeventsample();
        
    }
}

