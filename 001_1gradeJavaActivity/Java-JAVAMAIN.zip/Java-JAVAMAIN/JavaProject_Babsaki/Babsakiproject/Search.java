package Babsakiproject;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.WindowConstants;

public class Search extends JFrame  {
	JPanel panel;
	JButton btnMEBselect=new JButton();		//JButton btn1생성
	JButton btnBRKselect=new JButton();		//JButton btn1생성
	JButton btnCOCselect=new JButton();		//JButton btn1생성
	JButton btnTRBselect=new JButton();		//JButton btn1생성
	JButton btnRBGselect=new JButton();		//JButton btn1생성
	JButton btnTBKselect=new JButton();		//JButton btn1생성
	JButton btnBABselect=new JButton();		//JButton btn1생성
	JButton btnTRRselect=new JButton();		//JButton btn1생성
	JButton Home=new JButton();		//JButton btn1생성
	
	
	JCheckBox cb1 = new JCheckBox("계란");
	JCheckBox cb2 = new JCheckBox("식빵");
	JCheckBox cb3 = new JCheckBox("밥");
	JCheckBox cb4 = new JCheckBox("옥수수통조림");
	JCheckBox cb5 = new JCheckBox("떡");
	JCheckBox cb6 = new JCheckBox("보리");
	JCheckBox cb7 = new JCheckBox("김");
    
	
	public Search() {
		//Frame 설정
		JFrame Frame=new JFrame();
		Frame.setTitle("검색창");
		Frame.setSize(1615,750);
		Frame.setLocation(10,10);
		Frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		Frame.setVisible(true);
		Frame.setResizable(false);
		
		
		//배경화면
		ImagePanel Searchpage=new ImagePanel(new ImageIcon("./기타이미지/Select2.png").getImage());//패널 생성
		Searchpage.setSize(1216,718);
		Searchpage.setLocation(10,10);
		Searchpage.setVisible(true);
		Frame.add(Searchpage);
		
				//홈버튼
				
				Home.setBounds(24,20, 80, 80);
				Home.setBorder(null);
				Home.setBorderPainted(false);
				Home.setContentAreaFilled(false);
				Home.setVisible(true);
				Home.setIcon(new ImageIcon("./기타이미지/logo90.png"));
				Home.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						new MenuSelection();
						Frame.dispose();
						
					}
				});
				Searchpage.add(Home);
	
		//체크박스 
				//계란===================================================================================================================
				ImagePanel egg=new ImagePanel(new ImageIcon("./검색재료이미지/egg.png").getImage());//패널 생성
				egg.setBounds(140,140,110,110);
				egg.setVisible(true);
				Searchpage.add(egg);
				
				//계란체크박스
				cb1.setBounds(160,240,50,30);
				cb1.setBorderPainted(false);
				cb1.setContentAreaFilled(false);
				cb1.setVisible(true);
				Searchpage.add(cb1);
				cb1.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						  if(cb1.isSelected()) {  // cb1가 선택된다면
					        	btnMEBselect.setVisible(true);
					        	btnTRRselect.setVisible(true);
						  }
						  else {
							  btnMEBselect.setVisible(false);
							  btnTRRselect.setVisible(false);
						  }
							  	
					}
				});
				//모닝계란빵===============================================================================================================
				
				btnMEBselect.setVisible(false);
				btnMEBselect.setBounds(960, 120, 280, 200);
				btnMEBselect.setBorder(null);
				btnMEBselect.setIcon(new ImageIcon("./메뉴선택이미지/002.png"));
				btnMEBselect.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						new MorningEggBread();
						Frame.dispose();
					}
				});
				Searchpage.add(btnMEBselect);
			
				
				//토스트=======================================================================================================================
				ImagePanel Toast=new ImagePanel(new ImageIcon("./검색재료이미지/Toast.png").getImage());//패널 생성
				Toast.setBounds(340,140,110,110);
				Toast.setVisible(true);
				Searchpage.add(Toast);
				
				//토스트러스크체크박스===============================================================================================================
				cb2.setBounds(360,240,50,30);
				cb2.setBorderPainted(false);
				cb2.setContentAreaFilled(false);
				cb2.setVisible(true);
				Searchpage.add(cb2);
				cb2.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						if(cb2.isSelected())  // cb1가 선택된다면
				        	btnBRKselect.setVisible(true);
						else
							btnBRKselect.setVisible(false);
								
					}
				});
			  	btnBRKselect.setVisible(false);
			  	btnBRKselect.setBounds(960, 120, 280, 200);
				btnBRKselect.setBorder(null);
				btnBRKselect.setIcon(new ImageIcon("./메뉴선택이미지/005.png"));
				btnBRKselect.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						new breadRusk();
						setVisible(false);
					}
				});
				Searchpage.add(btnBRKselect);
				
				//밥====================================================================================================================
				ImagePanel Rice=new ImagePanel(new ImageIcon("./검색재료이미지/Rice.png").getImage());//패널 생성
				Rice.setBounds(540,140,110,110);
				Rice.setVisible(true);
				Searchpage.add(Rice);
				//밥버거 체크박스===========================================================================================================
				cb3.setBounds(560,240,50,30);
				cb3.setBorderPainted(false);
				cb3.setContentAreaFilled(false);
				cb3.setVisible(true);
				Searchpage.add(cb3);
				cb3.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						if(cb3.isSelected()) {  // cb1가 선택된다면
							btnRBGselect.setVisible(true);
							btnTRBselect.setVisible(true);
							btnTRRselect.setVisible(true);
						}
						else {
							btnRBGselect.setVisible(false);
							btnTRBselect.setVisible(false);
							btnTRRselect.setVisible(false);
						}
							
								
					}
				});
				
				//밥버거 
				btnRBGselect.setVisible(false);
				btnRBGselect.setBounds(960, 330, 280, 200);
				btnRBGselect.setBorder(null);
				btnRBGselect.setIcon(new ImageIcon("./메뉴선택이미지/006.png"));
				btnRBGselect.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						new RiceBurger();
						Frame.dispose();
					}
				});
				Searchpage.add(btnRBGselect);
				//참치주먹밥
				btnTRBselect.setVisible(false);
				btnTRBselect.setBounds(1250, 330, 280, 200);
				btnTRBselect.setBorder(null);
				btnTRBselect.setIcon(new ImageIcon("./메뉴선택이미지/004.png"));
				btnTRBselect.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						new TunaRiceBalls();
						Frame.dispose();
					}
				});
				Searchpage.add(btnTRBselect);
				
				//옥수수==========================================================================================================
				ImagePanel Corn=new ImagePanel(new ImageIcon("./검색재료이미지/Corn.png").getImage());//패널 생성
				Corn.setBounds(340,340,110,110);
				Corn.setVisible(true);
				Searchpage.add(Corn);
				//콘치즈체크버튼==========================================================================================================
				cb4.setBounds(340,440,100,30);
				cb4.setBorderPainted(false);
				cb4.setContentAreaFilled(false);
				cb4.setVisible(true);
				Searchpage.add(cb4);
				cb4.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						if(cb4.isSelected())  // cb1가 선택된다면
							btnCOCselect.setVisible(true);
							
						else {
							btnCOCselect.setVisible(false);
							
						}
					}
				});
				//콘치즈================================================================================================================
				btnCOCselect.setVisible(false);
				btnCOCselect.setBounds(960, 120, 280, 200);
				btnCOCselect.setBorder(null);
				btnCOCselect.setIcon(new ImageIcon("./메뉴선택이미지/001.png"));
				btnCOCselect.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						new breadRusk();
						Frame.dispose();
					}
				});
				Searchpage.add(btnCOCselect);
				
				//떡==========================================================================================================
				ImagePanel RiceCake=new ImagePanel(new ImageIcon("./검색재료이미지/떡.png").getImage());//패널 생성
				RiceCake.setBounds(140,340,110,110);
				RiceCake.setVisible(true);
				Searchpage.add(RiceCake);
				//떡체크버튼=============================================================================================================
				cb5.setBounds(160,440,100,30);
				cb5.setBorderPainted(false);
				cb5.setContentAreaFilled(false);
				cb5.setVisible(true);
				Searchpage.add(cb5);
				cb5.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						if(cb5.isSelected())  // cb1가 선택된다면
							btnTBKselect.setVisible(true);
							
						else
							btnTBKselect.setVisible(false);
								
					}
				});
				//떡볶이================================================================================================================
				btnTBKselect.setVisible(false);
				btnTBKselect.setBounds(960,120,280,200);
				btnTBKselect.setBorder(null);
				btnTBKselect.setIcon(new ImageIcon("./메뉴선택이미지/003.png"));
				btnTBKselect.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						new DuakBokki();
						Frame.dispose();
					}
				});
				Searchpage.add(btnTBKselect);
				
				//보리 ==========================================================================================================
				ImagePanel barley=new ImagePanel(new ImageIcon("./검색재료이미지/008.png").getImage());//패널 생성
				barley.setBounds(540,340,110,110);
				barley.setVisible(true);
				Searchpage.add(barley);
				//보리빵체크버튼=============================================================================================================
				cb6.setBounds(540,440,100,30);
				cb6.setBorderPainted(false);
				cb6.setContentAreaFilled(false);
				cb6.setVisible(true);
				Searchpage.add(cb6);
				cb6.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						if(cb6.isSelected())  // cb1가 선택된다면
							btnBABselect.setVisible(true);
							
						else
							btnBABselect.setVisible(false);
								
					}
				});
				//보리빵================================================================================================================
				btnBABselect.setVisible(false);
				btnBABselect.setBounds(960,120,280,200);
				btnBABselect.setBorder(null);
				btnBABselect.setIcon(new ImageIcon("./메뉴선택이미지/008.png"));
				btnBABselect.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						new barleyBread();
						Frame.dispose();
					}
				});
				Searchpage.add(btnBABselect);

				//김 ==========================================================================================================
				ImagePanel kim=new ImagePanel(new ImageIcon("./검색재료이미지/007.png").getImage());//패널 생성
				kim.setBounds(140,500,110,110);
				kim.setVisible(true);
				Searchpage.add(kim);
				//김체크버튼=============================================================================================================
				cb7.setBounds(160,600,100,30);
				cb7.setBorderPainted(false);
				cb7.setContentAreaFilled(false);
				cb7.setVisible(true);
				Searchpage.add(cb7);
				cb7.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						if(cb7.isSelected()) {  // cb1가 선택된다면
							btnTRRselect.setVisible(true);
							btnRBGselect.setVisible(true);
							btnTRBselect.setVisible(true);
						}
						else {
							btnTRRselect.setVisible(false);
							btnRBGselect.setVisible(false);
							btnTRBselect.setVisible(false);
						}
								
					}
				});
				//삼각김밥================================================================================================================
				btnTRRselect.setVisible(false);
				btnTRRselect.setBounds(1250,120,280,200);
				btnTRRselect.setBorder(null);
				btnTRRselect.setIcon(new ImageIcon("./메뉴선택이미지/007.png"));
				btnTRRselect.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						new barleyBread();
						Frame.dispose();
					}
				});
				Searchpage.add(btnTRRselect);
	}
	
}


class Searchpage extends JPanel{
	
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image imgCOC1;	
	
	public Searchpage(Image img) {
		this.imgCOC1=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
		
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(imgCOC1, 0, 0, null);	//(0,0)은 x,y값
	}
	
}
