package Babsakiproject;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;		//JButton추가
import javax.swing.JFrame;		//JFrame추가
import javax.swing.JPanel;		//JPanel추가 
//Main
public class MenuSelection {
	public MenuSelection() {
		JFrame frame=new JFrame();		//JFrame 생성
		
		JButton btnMEBselect=new JButton();		//JButton btn1생성
		JButton btnTBKselect=new JButton();		//JButton btn2생성
		JButton btnRBGselect=new JButton();		//JButton btn3생성
		JButton btnTRBselect=new JButton();		//JButton btn4생성
		JButton btnTRKselect=new JButton();		//JButton btn5생성
		JButton btnCOCselect=new JButton();		//JButton btn6생성
		JButton btnBABselect=new JButton();		//JButton btn6생성
		JButton btnTRRselect=new JButton();		//JButton btn6생성
		JButton j=new JButton();
		
		JPanel imgpanel1=new ImagePanel(new ImageIcon(".//기타이미지//Menuselectpage.png").getImage());//2.배경이미지 있는 패널 생성
	
		//프레임(하나의 툴) 설정
		frame.setTitle("Babsaki");//창의 타이틀
		frame.setVisible(true);	//프레임보이게 만들기
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//JFrame이 정상적으로 종료되게
		frame.setResizable(false);//창의 크기를 변경하지 못하게
		frame.setLayout(null);	 //프레임 레이아웃
		frame.setSize(1216,718);//프레임의 크기
		frame.setLocation(10,10);//창이 가운데 나오게하기 
		frame.setResizable(false);	//창고정
		
		//프레임에 추가되는 것들
		frame.add(imgpanel1);						//frame에 이미지패널 추가

		
		
		//이미지 패널에 버튼 추가 
		//버튼1 설정(모닝계란빵)
		btnMEBselect.setVisible(true);
		btnMEBselect.setBounds(315, 250, 280, 200);
		btnMEBselect.setBorder(null);
		btnMEBselect.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images_Modify\\메뉴선택이미지\\002.png"));
		btnMEBselect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new MorningEggBread();
				frame.dispose();
			}
		});
		imgpanel1.add(btnMEBselect);
	
		//버튼2 설정(떡볶이)
		btnTBKselect.setVisible(true);
		btnTBKselect.setBounds(600, 250, 280, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnTBKselect.setBorder(null);
		btnTBKselect.setIcon(new ImageIcon("./메뉴선택이미지/003.png"));
		btnTBKselect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					new DuakBokki();
					frame.dispose();
			}
		});
		imgpanel1.add(btnTBKselect);	//계란찜 버튼 
	
		//버튼3 설정(밥버거)
		btnRBGselect.setVisible(true);
		btnRBGselect.setBounds(885, 250, 280, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnRBGselect.setBorder(null);
		btnRBGselect.setIcon(new ImageIcon("./메뉴선택이미지/006.png"));
		btnRBGselect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RiceBurger();
				frame.dispose();
			}
		});
		imgpanel1.add(btnRBGselect);	//마약토스트버튼
		
		
		//버튼4 설정(참치주먹밥)
		btnTRBselect.setVisible(true);
		btnTRBselect.setBounds(315, 452, 280, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnTRBselect.setBorder(null);		
		btnTRBselect.setIcon(new ImageIcon("./메뉴선택이미지/004.png"));
		btnTRBselect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new TunaRiceBalls();
				frame.dispose();
			}
		});
		imgpanel1.add(btnTRBselect);
	
		//버튼5 설정(식빵러스크)
		btnTRKselect.setVisible(true);
		btnTRKselect.setBounds(600, 452, 280, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnTRKselect.setBorder(null);
		btnTRKselect.setIcon(new ImageIcon("./메뉴선택이미지/005.png"));
		btnTRKselect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new  breadRusk();
				frame.dispose();
				
			}
		});
		imgpanel1.add(btnTRKselect);
		//콘치즈선택버튼 
		btnCOCselect.setVisible(true);
		btnCOCselect.setBounds(885, 452, 280, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnCOCselect.setBorder(null);
		btnCOCselect.setIcon(new ImageIcon("./메뉴선택이미지/001.png"));
		btnCOCselect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new CornChese();
				frame.dispose();
				
			}
		});
		imgpanel1.add(btnCOCselect);
		
		//삼각김밥
				btnTRRselect.setVisible(true);
				btnTRRselect.setBounds(28, 250, 280, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnTRRselect.setBorder(null);
				btnTRRselect.setIcon(new ImageIcon("./메뉴선택이미지/007.png"));
				btnTRRselect.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						new TriangularRolledRiceGimbap();
						frame.dispose();
						
					}
				});
				imgpanel1.add(btnBABselect);
				
				
		//보리빵
		btnBABselect.setVisible(true);
		btnBABselect.setBounds(28,452, 280, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBABselect.setBorder(null);
		btnBABselect.setIcon(new ImageIcon("./메뉴선택이미지/008.png"));
		btnBABselect.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new barleyBread();
				frame.dispose();
				
			}
		});
		imgpanel1.add(btnTRRselect);
		
	
	}//생성자 끝
		public static void main(String args[]) {
				new MenuSelection();	//처음화면 생성자 호출
				StopWatch stopwatch=new StopWatch();		//스톱워치 추가 
		}
	}//Main class 끝
	
//메뉴 선택화면 클래스 
class ImagePanel extends JPanel{
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image img;	
	
	public ImagePanel(Image img) {
		this.img=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(img, 0, 0, null);				//(0,0)은 x,y값
	}
}


















