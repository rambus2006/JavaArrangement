package Babsakiproject;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Image;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JButton;		//JButton추가
import javax.swing.JFrame;		//JFrame추가
import javax.swing.JLabel;
import javax.swing.JPanel;		//JPanel추가
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JFrame;		//JFrame추가
import javax.swing.JPanel;		//JPanel추가
import javax.swing.WindowConstants;

//완성- 시간 맞는지 한번 더 확인하기 
//참치 주먹밥클래스 
public class TunaRiceBalls extends JFrame {
	TunaRiceBalls(){
		super(); //타이틀
		
		ImagePanel panelTRB1=new ImagePanel(new ImageIcon("./참치주먹밥/panelTRB1.png").getImage());//패널 생성
		ImagePanel panelTRB2=new ImagePanel(new ImageIcon("./참치주먹밥/panelTRB2.png").getImage());//패널 생성
		ImagePanel panelTRB3=new ImagePanel(new ImageIcon("./참치주먹밥/panelTRB3.png").getImage());//패널 생성
		ImagePanel panelTRB4=new ImagePanel(new ImageIcon("./참치주먹밥/panelTRB4.png").getImage());//패널 생성
		ImagePanel panelTRB5=new ImagePanel(new ImageIcon("./참치주먹밥/panelTRB5.png").getImage());//패널 생성
		ImagePanel panelTRB6=new ImagePanel(new ImageIcon("./참치주먹밥/panelTRB6.png").getImage());//패널 생성
		ImagePanel panelTRB7=new ImagePanel(new ImageIcon("./참치주먹밥/panelTRB7.png").getImage());//패널 생성
		ImagePanel endpanelTRB=new ImagePanel(new ImageIcon("./기타이미지/lastpage.png").getImage());//패널 생성
		
		//frame구성
		setSize(1216,714);
		setLocation(10,10);
		add(panelTRB1);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setVisible(true);
		
		//버튼 추가 (다음버튼 )
		JButton btnNextTRB1=new JButton();		//JButton btn1생성
		JButton btnNextTRB2=new JButton();		//JButton btn1생성
		JButton btnNextTRB3=new JButton();			//JButton btn2생성
		JButton btnNextTRB4=new JButton();		//JButton btn3생성
		JButton btnNextTRB5=new JButton();		//JButton btn4생성
		JButton btnNextTRB6=new JButton();		//JButton btn5생성
		JButton btnNextTRB7=new JButton();		//JButton btn5생성
		JButton btnNextTRB8=new JButton();		//JButton btn5생성
		JButton btnEndToHomeTRB=new JButton();		//JButton btn5생성
		
		JButton btnBackTRB1=new JButton();		//JButton btn1생성
		JButton btnBackTRB2=new JButton();		//JButton btn1생성
		JButton btnBackTRB3=new JButton();		//JButton btn1생성
		JButton btnBackTRB4=new JButton();		//JButton btn1생성
		JButton btnBackTRB5=new JButton();		//JButton btn1생성
		JButton btnBackTRB6=new JButton();		//JButton btn1생성
		JButton btnBackTRB7=new JButton();		//JButton btn1생성
		JButton btnEndToTRB=new JButton();		//JButton btn1생성
		
		
		add(panelTRB2);
		add(panelTRB3);	
		add(panelTRB4);		
		add(panelTRB5);
		add(panelTRB6);
		add(panelTRB7);
		add(endpanelTRB);
		
		//자동넘김버튼============================================================================================================

		JButton autobtn=new JButton();
		autobtn.setVisible(true);
		autobtn.setBounds(800, 38, 200, 100);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		autobtn.setBorder(null);
		autobtn.setContentAreaFilled(false);				//버튼 안의 이미지 외곽의 공간을 없애줌
		autobtn.setIcon(new ImageIcon("./버튼이미지/autobtn.png"));
		panelTRB1.add(autobtn);
		
		Timer timer = new Timer();
		
		autobtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//30/7=4.1..., 각 과정당 6분으로 가정했을 때->초 단위로 바꿈
				//1000==1초(밀리세컨 단위)
				TimerTask task= new TimerTask() {
					@Override
					public void run() {
						panelTRB1.setVisible(false);
						panelTRB2.setVisible(true);
					}
				};
				timer.schedule(task, 2000);	//정해진 시간에 실행(2초)
					
				TimerTask task2= new TimerTask() {
					public void run() {
						panelTRB2.setVisible(false);
						panelTRB3.setVisible(true);
					}
				};
				timer.schedule(task2, 6000);	//(실행한 2초+4초=6초)
				
				TimerTask task3= new TimerTask() {
					public void run() {
						panelTRB3.setVisible(false);
						panelTRB4.setVisible(true);
					}
				};
				timer.schedule(task3, 10000); //(실행한6초+4초=10초초)
				
				TimerTask task4= new TimerTask() {
					public void run() {
						panelTRB4.setVisible(false);
						panelTRB5.setVisible(true);
					}
				};
				timer.schedule(task4, 14000);	//(실행한10초+4초=14초)
				
				TimerTask task5= new TimerTask() {
					public void run() {
						panelTRB5.setVisible(false);
						panelTRB6.setVisible(true);
					}
				};
				timer.schedule(task5, 18000);//(실행한14초+4초=18초)
				
				TimerTask task6= new TimerTask() {
					public void run() {
						panelTRB6.setVisible(false);
						panelTRB7.setVisible(true);
					}
				};
				timer.schedule(task6, 22000);//(실행한18초+4초=22초)
				
				TimerTask task7= new TimerTask() {
					public void run() {
						panelTRB7.setVisible(false);
						endpanelTRB.setVisible(true);
					}
				};
				timer.schedule(task7, 26000);//(실행한22초+4초=26초)
			}
			
		});
		
//-----------------------------------------------------
		//다음 버튼  
		btnNextTRB1.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextTRB1.setBorder(null);
		btnNextTRB1.setVisible(true);
		btnNextTRB1.setBorderPainted(false);
		btnNextTRB1.setContentAreaFilled(false);
		btnNextTRB1.setIcon(new ImageIcon("./버튼이미지/nextbtn.png"));
		btnNextTRB1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelTRB1.setVisible(false);
					panelTRB2.setVisible(true);
					
				}
		});
		panelTRB1.add(btnNextTRB1);//panelTRB1에서 2으로 넘어가는 버튼
		
			
	
		btnNextTRB2.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextTRB2.setBorder(null);
		btnNextTRB2.setVisible(true);
		btnNextTRB2.setBorderPainted(false);
		btnNextTRB2.setContentAreaFilled(false);
		btnNextTRB2.setIcon(new ImageIcon("./버튼이미지/nextbtn.png"));
		btnNextTRB2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelTRB2.setVisible(false);
					panelTRB3.setVisible(true);		
				}
		});
		panelTRB2.add(btnNextTRB2);	//panelTRB2에서 3으로 넘어가는 버튼
		
		btnNextTRB3.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextTRB3.setBorder(null);
		btnNextTRB3.setVisible(true);
		btnNextTRB3.setBorderPainted(false);
		btnNextTRB3.setContentAreaFilled(false);
		btnNextTRB3.setIcon(new ImageIcon("./버튼이미지/nextbtn.png"));
		btnNextTRB3.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelTRB3.setVisible(false);
					panelTRB4.setVisible(true);
								
				}
		});
		panelTRB3.add(btnNextTRB3);	//panelTRB3에서 4으로 넘어가는 버튼
		
		
		btnNextTRB4.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextTRB4.setBorder(null);
		btnNextTRB4.setVisible(true);
		btnNextTRB4.setBorderPainted(false);
		btnNextTRB4.setContentAreaFilled(false);
		btnNextTRB4.setIcon(new ImageIcon("./버튼이미지/nextbtn.png"));
		btnNextTRB4.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelTRB4.setVisible(false);
					panelTRB5.setVisible(true);
									
				}
		});
		panelTRB4.add(btnNextTRB4);	//panelTRB4에서 5으로 넘어가는 버튼
		
		
		btnNextTRB5.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextTRB5.setBorder(null);
		btnNextTRB5.setVisible(true);
		btnNextTRB5.setBorderPainted(false);
		btnNextTRB5.setContentAreaFilled(false);
		btnNextTRB5.setIcon(new ImageIcon("./버튼이미지/nextbtn.png"));
		btnNextTRB5.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelTRB5.setVisible(false);
					panelTRB6.setVisible(true);
										
				}
		});		
		panelTRB5.add(btnNextTRB5);	//panelTRB5에서 6으로 넘어가는 버튼

		btnNextTRB6.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextTRB6.setBorder(null);
		btnNextTRB6.setVisible(true);
		btnNextTRB6.setBorderPainted(false);
		btnNextTRB6.setContentAreaFilled(false);
		btnNextTRB6.setIcon(new ImageIcon("./버튼이미지/nextbtn.png"));
		btnNextTRB6.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelTRB6.setVisible(false);
					panelTRB7.setVisible(true);
					
					
				}
		});	
		panelTRB6.add(btnNextTRB6);	//panelTRB6에서 7으로 넘어가는 버튼
		
		btnNextTRB7.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextTRB7.setBorder(null);
		btnNextTRB7.setVisible(true);
		btnNextTRB7.setBorderPainted(false);
		btnNextTRB7.setContentAreaFilled(false);
		btnNextTRB7.setIcon(new ImageIcon("./버튼이미지/nextbtn.png"));
		btnNextTRB7.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelTRB7.setVisible(false);
					endpanelTRB.setVisible(true);
					
					
				}
		});	
		panelTRB7.add(btnNextTRB7);		//panelTRB7에서 엔딩패널로 넘어가는 버튼
		
		btnEndToHomeTRB.setBounds(893,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnEndToHomeTRB.setBorder(null);
		btnEndToHomeTRB.setVisible(true);
		btnEndToHomeTRB.setBorderPainted(false);
		btnEndToHomeTRB.setContentAreaFilled(false);
		btnEndToHomeTRB.setIcon(new ImageIcon("./버튼이미지/homebtn.png"));
		btnEndToHomeTRB.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					endpanelTRB.setVisible(false);
					new MenuSelection();
					
				}
		});	
		endpanelTRB.add(btnEndToHomeTRB);		//엔딩패널에서 홈으로 돌아가는 버튼*/
		
		//이전버튼 만들기 ================================================================================================================
		btnBackTRB1.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackTRB1.setBorder(null);
		btnBackTRB1.setVisible(true);
		btnBackTRB1.setBorderPainted(false);
		btnBackTRB1.setContentAreaFilled(false);
		btnBackTRB1.setIcon(new ImageIcon("./버튼이미지/backbtn.png"));
		btnBackTRB1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelTRB2.setVisible(false);
				panelTRB1.setVisible(true);
				
				
			}
		});
		panelTRB2.add(btnBackTRB1);
		
		btnBackTRB2.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackTRB2.setBorder(null);
		btnBackTRB2.setVisible(true);
		btnBackTRB2.setBorderPainted(false);
		btnBackTRB2.setContentAreaFilled(false);
		btnBackTRB2.setIcon(new ImageIcon("./버튼이미지/backbtn.png"));
		btnBackTRB2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelTRB3.setVisible(false);
				panelTRB2.setVisible(true);
				
			}
		});
		panelTRB3.add(btnBackTRB2);
		
		btnBackTRB3.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackTRB3.setBorder(null);
		btnBackTRB3.setVisible(true);
		btnBackTRB3.setBorderPainted(false);
		btnBackTRB3.setContentAreaFilled(false);
		btnBackTRB3.setIcon(new ImageIcon("./버튼이미지/backbtn.png"));
		btnBackTRB3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelTRB3.setVisible(false);
				panelTRB2.setVisible(true);
				
			}
		});
		panelTRB3.add(btnBackTRB3);
		
		btnBackTRB4.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackTRB4.setBorder(null);
		btnBackTRB4.setVisible(true);
		btnBackTRB4.setBorderPainted(false);
		btnBackTRB4.setContentAreaFilled(false);
		btnBackTRB4.setIcon(new ImageIcon("./버튼이미지/backbtn.png"));
		btnBackTRB4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelTRB4.setVisible(false);
				panelTRB3.setVisible(true);
				
			}
		});
		panelTRB4.add(btnBackTRB4);

		btnBackTRB5.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackTRB5.setBorder(null);
		btnBackTRB5.setVisible(true);
		btnBackTRB5.setBorderPainted(false);
		btnBackTRB5.setContentAreaFilled(false);
		btnBackTRB5.setIcon(new ImageIcon("./버튼이미지/backbtn.png"));
		btnBackTRB5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelTRB5.setVisible(false);
				panelTRB4.setVisible(true);
				
			}
		});
		panelTRB5.add(btnBackTRB5);
		
		btnBackTRB6.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackTRB6.setBorder(null);
		btnBackTRB6.setVisible(true);
		btnBackTRB6.setBorderPainted(false);
		btnBackTRB6.setContentAreaFilled(false);
		btnBackTRB6.setIcon(new ImageIcon("./버튼이미지/backbtn.png"));
		btnBackTRB6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelTRB6.setVisible(false);
				panelTRB5.setVisible(true);
				
			}
		});
		panelTRB6.add(btnBackTRB6);
		
		btnBackTRB7.setBounds(619,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackTRB7.setBorder(null);
		btnBackTRB7.setVisible(true);
		btnBackTRB7.setBorderPainted(false);
		btnBackTRB7.setContentAreaFilled(false);
		btnBackTRB7.setIcon(new ImageIcon("./버튼이미지/backbtn.png"));
		btnBackTRB7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelTRB7.setVisible(false);
				panelTRB6.setVisible(true);
				
			}
		});
		panelTRB7.add(btnBackTRB7);
		
		
	}
}