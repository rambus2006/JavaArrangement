package Babsakiproject;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.TextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JButton;		//JButton추가
import javax.swing.JFrame;		//JFrame추가
import javax.swing.JPanel;		//JPanel추가
import javax.swing.WindowConstants;

//완성

public class breadRusk extends JFrame {
	breadRusk(){
		//버튼은 10의 자리 단위로 메뉴가 다름
		JButton btnNextBRK1=new JButton();		//JButton btn1생성
		JButton btnNextBRK2=new JButton();		//JButton btn1생성
		JButton btnNextBRK3=new JButton();		//JButton btn1생성
		JButton btnNextBRK4=new JButton();		//JButton btn1생성
		JButton btnNextBRK5=new JButton();		//JButton btn1생성
		JButton btnNextBRK6=new JButton();		//JButton btn1생성
		JButton btnNextBRK7=new JButton();		//JButton btn1생성
		JButton btnNextBRK8=new JButton();		//JButton btn1생성
		
					
		JButton btnBackBRK1=new JButton();		//JButton btn1생성
		JButton btnBackBRK2=new JButton();		//JButton btn1생성
		JButton btnBackBRK3=new JButton();		//JButton btn1생성
		JButton btnBackBRK4=new JButton();		//JButton btn1생성
		JButton btnBackBRK5=new JButton();		//JButton btn1생성
		JButton btnBackBRK6=new JButton();		//JButton btn1생성
		JButton btnBackBRK7=new JButton();		//JButton btn1생성
		JButton btnBackBRK8=new JButton();		//JButton btn1생성
					
		ImagePanel panelBRK1=new ImagePanel(new ImageIcon("./식빵러스크/001.png").getImage());//패널 생성
		ImagePanel panelBRK2=new ImagePanel(new ImageIcon("./식빵러스크/002.png").getImage());//패널 생성
		ImagePanel panelBRK3=new ImagePanel(new ImageIcon("./식빵러스크/003.png").getImage());//패널 생성
		ImagePanel panelBRK4=new ImagePanel(new ImageIcon("./식빵러스크/004.png").getImage());//패널 생
		ImagePanel panelBRK5=new ImagePanel(new ImageIcon("./식빵러스크/005.png").getImage());//패널 생성
		ImagePanel panelBRK6=new ImagePanel(new ImageIcon("./식빵러스크/006.png").getImage());//패널 생성
		ImagePanel panelBRK7=new ImagePanel(new ImageIcon("./식빵러스크/007.png").getImage());//패널 생성
		ImagePanel endpanel4=new ImagePanel(new ImageIcon("./기타이미지/lastpage.png").getImage());//패널 생성
		
		setSize(1216,714);
		setLocation(10,10);
		add(panelBRK1);
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setVisible(true);
		
		add(panelBRK2);
		add(panelBRK3);
		add(panelBRK4);
		add(panelBRK5);
		add(panelBRK6);
		add(panelBRK7);
		add(endpanel4);
		
		//자동넘김버튼================================================================================================
		JButton autobtn=new JButton();
		autobtn.setVisible(true);
		autobtn.setBounds(800, 38, 200, 100);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		autobtn.setBorder(null);
		autobtn.setContentAreaFilled(false);				//버튼 안의 이미지 외곽의 공간을 없애줌
		autobtn.setIcon(new ImageIcon("./버튼이미지/autobtn.png"));
		panelBRK1.add(autobtn);
		
		Timer timer = new Timer();
		
		autobtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//30/5=6, 각 과정당 6분으로 가정했을 때->초 단위로 바꿈
				//1000==1초(밀리세컨 단위)
				TimerTask task= new TimerTask() {
					@Override
					public void run() {
						panelBRK1.setVisible(false);
						panelBRK2.setVisible(true);
						
					}
				};
				timer.schedule(task, 2000);	//정해진 시간에 실행(2초)
					
				TimerTask task2= new TimerTask() {
					public void run() {
						panelBRK2.setVisible(false);
						panelBRK3.setVisible(true);
					}
				};
				timer.schedule(task2, 9000);	//(실행한 3초+7초=9초)
				
				TimerTask task3= new TimerTask() {
					public void run() {
						panelBRK3.setVisible(false);
						panelBRK4.setVisible(true);
					}
				};
				timer.schedule(task3, 16000); //(실행한9초+7초=16초)
				
				TimerTask task4= new TimerTask() {
					public void run() {
						panelBRK4.setVisible(false);
						panelBRK5.setVisible(true);
					}
				};
				timer.schedule(task4, 23000);	//(실행한16초+7초=23초)
				
				TimerTask task5= new TimerTask() {
					public void run() {
						panelBRK5.setVisible(false);
						panelBRK6.setVisible(true);
					}
				};
				timer.schedule(task5, 31000);//(실행한23초+7초=31초)
				
				TimerTask task6= new TimerTask() {
					public void run() {
						panelBRK6.setVisible(false);
						panelBRK7.setVisible(true);
					}
				};
				timer.schedule(task6, 38000);//(실행한31초+7초=38초)
				
				TimerTask task7= new TimerTask() {
					public void run() {
						panelBRK7.setVisible(false);
						endpanel4.setVisible(true);
					}
				};
				timer.schedule(task7, 45000);//(실행한38초+7초=45초)
			}
			
		});
//----------------------------------------------------------------------밥버거다음버튼----------------------------------------------------
					
		btnNextBRK1.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextBRK1.setBorder(null);
		btnNextBRK1.setBorderPainted(false);
		btnNextBRK1.setContentAreaFilled(false);
		btnNextBRK1.setVisible(true);
		btnNextBRK1.setIcon(new ImageIcon("./버튼이미지/nextbtn.png"));
		btnNextBRK1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
						panelBRK1.setVisible(false);
						panelBRK2.setVisible(true);
								
					}
		});
		panelBRK1.add(btnNextBRK1);		//paneTOK1에서 2로 넘어가는 버튼
					
		
		btnNextBRK2.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextBRK2.setBorder(null);
		btnNextBRK2.setVisible(true);
		btnNextBRK2.setBorderPainted(false);
		btnNextBRK2.setContentAreaFilled(false);
		btnNextBRK2.setIcon(new ImageIcon("./버튼이미지/nextbtn.png"));
		btnNextBRK2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelBRK2.setVisible(false);
					panelBRK3.setVisible(true);
								
					}
		});
		panelBRK2.add(btnNextBRK2);      //paneTOK2에서 3로 넘어가는 버튼
					
		btnNextBRK3.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextBRK3.setBorder(null);
		btnNextBRK3.setVisible(true);
		btnNextBRK3.setBorderPainted(false);
		btnNextBRK3.setContentAreaFilled(false);
		btnNextBRK3.setIcon(new ImageIcon("./버튼이미지/nextbtn.png"));
		btnNextBRK3.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelBRK3.setVisible(false);
					panelBRK4.setVisible(true);
								
				}
		});
		panelBRK3.add(btnNextBRK3);	//paneTOK3에서4로 넘어가는 버튼
					
		btnNextBRK4.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextBRK4.setBorder(null);
		btnNextBRK4.setVisible(true);
		btnNextBRK4.setBorderPainted(false);
		btnNextBRK4.setContentAreaFilled(false);
		btnNextBRK4.setIcon(new ImageIcon("./버튼이미지/nextbtn.png"));
		btnNextBRK4.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelBRK4.setVisible(false);
					panelBRK5.setVisible(true);
								
				}
		});
		panelBRK4.add(btnNextBRK4);	//paneTOK4에서5로 넘어가는 버튼

		btnNextBRK5.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextBRK5.setBorder(null);
		btnNextBRK5.setVisible(true);
		btnNextBRK5.setBorderPainted(false);
		btnNextBRK5.setContentAreaFilled(false);
		btnNextBRK5.setIcon(new ImageIcon("./버튼이미지/nextbtn.png"));
		btnNextBRK5.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelBRK5.setVisible(false);
					panelBRK6.setVisible(true);
								
				}
		});
		panelBRK5.add(btnNextBRK5);	//paneTOK5에서6로 넘어가는 버튼
					
		btnNextBRK6.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextBRK6.setBorder(null);
		btnNextBRK6.setVisible(true);
		btnNextBRK6.setBorderPainted(false);
		btnNextBRK6.setContentAreaFilled(false);
		btnNextBRK6.setIcon(new ImageIcon("./버튼이미지/nextbtn.png"));
		btnNextBRK6.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelBRK6.setVisible(false);
					panelBRK7.setVisible(true);
								
				}
		});			
		panelBRK6.add(btnNextBRK6);	//paneTOK5에서6로 넘어가는 버튼
											
		btnNextBRK7.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextBRK7.setBorder(null);
		btnNextBRK7.setVisible(true);
		btnNextBRK7.setBorderPainted(false);
		btnNextBRK7.setContentAreaFilled(false);
		btnNextBRK7.setIcon(new ImageIcon("./버튼이미지/nextbtn.png"));
		btnNextBRK7.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelBRK7.setVisible(false);
					endpanel4.setVisible(true);
				
								
				}
		});	
		panelBRK7.add(btnNextBRK7);	//paneTOK7에서 엔딩패널로 넘어가는 버튼
		
		btnNextBRK8.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNextBRK8.setBorder(null);
		btnNextBRK8.setBorderPainted(false);
		btnNextBRK8.setContentAreaFilled(false);
		btnNextBRK8.setVisible(true);
		btnNextBRK8.setIcon(new ImageIcon("./버튼이미지/homebtn.png"));
		btnNextBRK8.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					endpanel4.setVisible(false);
					new MenuSelection();
								
				}
		});	
		endpanel4.add(btnNextBRK8);	//paneTOK7에서 엔딩패널로 넘어가는 버튼
					
//---------------------------------------------이전버튼(토스트)----------------------------------------------------
					
		btnBackBRK1.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackBRK1.setBorder(null);
		btnBackBRK1.setVisible(true);
		btnBackBRK1.setBorderPainted(false);
		btnBackBRK1.setContentAreaFilled(false);
		btnBackBRK1.setIcon(new ImageIcon("./버튼이미지/backbtn.png"));
		btnBackBRK1.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelBRK2.setVisible(false);
					panelBRK1.setVisible(true);
					
					
								
				}
		});
		panelBRK2.add(btnBackBRK1);		//paneTOK1에서 2로 넘어가는 버튼
				
		
		btnBackBRK2.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackBRK2.setBorder(null);
		btnBackBRK2.setVisible(true);
		btnBackBRK2.setBorderPainted(false);
		btnBackBRK2.setContentAreaFilled(false);
		btnBackBRK2.setIcon(new ImageIcon("./버튼이미지/backbtn.png"));
		btnBackBRK2.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelBRK3.setVisible(false);
					panelBRK2.setVisible(true);
								
				}
		});
		panelBRK3.add(btnBackBRK2);      //paneTOK2에서 3로 넘어가는 버튼
					
		btnBackBRK3.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackBRK3.setBorder(null);
		btnBackBRK3.setVisible(true);
		btnBackBRK3.setBorderPainted(false);
		btnBackBRK3.setContentAreaFilled(false);
		btnBackBRK3.setIcon(new ImageIcon("./버튼이미지/backbtn.png"));
		btnBackBRK3.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelBRK4.setVisible(false);
					panelBRK3.setVisible(true);
								
				}
		});
		panelBRK4.add(btnBackBRK3);	//paneTOK3에서4로 넘어가는 버튼
					
		btnBackBRK4.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackBRK4.setBorder(null);
		btnBackBRK4.setVisible(true);
		btnBackBRK4.setBorderPainted(false);
		btnBackBRK4.setContentAreaFilled(false);
		btnBackBRK4.setIcon(new ImageIcon("./버튼이미지/backbtn.png"));
		btnBackBRK4.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelBRK5.setVisible(false);
					panelBRK4.setVisible(true);
								
				}
		});
		panelBRK5.add(btnBackBRK4);	//paneTOK4에서5로 넘어가는 버튼

		btnBackBRK5.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackBRK5.setBorder(null);
		btnBackBRK5.setVisible(true);
		btnBackBRK5.setBorderPainted(false);
		btnBackBRK5.setContentAreaFilled(false);
		btnBackBRK5.setIcon(new ImageIcon("./버튼이미지/backbtn.png"));
		btnBackBRK5.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelBRK6.setVisible(false);
					panelBRK5.setVisible(true);
								
				}
		});
		panelBRK6.add(btnBackBRK5);	//paneTOK5에서6로 넘어가는 버튼
					
		btnBackBRK6.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnBackBRK6.setBorder(null);
		btnBackBRK6.setVisible(true);
		btnBackBRK6.setBorderPainted(false);
		btnBackBRK6.setContentAreaFilled(false);
		btnBackBRK6.setIcon(new ImageIcon("./버튼이미지/backbtn.png"));
		btnBackBRK6.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
					panelBRK7.setVisible(false);
					panelBRK6.setVisible(true);
								
				}
		});			
		panelBRK7.add(btnBackBRK6);	//paneTOK5에서6로 넘어가는 버튼
											
		
	}
}
class panelBRK1 extends JPanel{
	
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image imgTot1;	
	
	public panelBRK1(Image img) {
		this.imgTot1=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
		
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(imgTot1, 0, 0, null);	//(0,0)은 x,y값
	}
	
}
class panelBRK2 extends JPanel{
	
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image imgTot1;	
	
	public panelBRK2(Image img) {
		this.imgTot1=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
		
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(imgTot1, 0, 0, null);	//(0,0)은 x,y값
	}
	
}
class panelBRK3 extends JPanel{
	
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image imgTot1;	
	
	public panelBRK3(Image img) {
		this.imgTot1=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
		
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(imgTot1, 0, 0, null);	//(0,0)은 x,y값
	}
	
}
class panelBRK4 extends JPanel{
	
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image imgTot1;	
	
	public panelBRK4(Image img) {
		this.imgTot1=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
		
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(imgTot1, 0, 0, null);	//(0,0)은 x,y값
	}
	
}
class panelBRK5 extends JPanel{
	
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image imgTot1;	
	
	public panelBRK5(Image img) {
		this.imgTot1=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
		
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(imgTot1, 0, 0, null);	//(0,0)은 x,y값
	}
	
}
class panelBRK6 extends JPanel{
	
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image imgTot1;	
	
	public panelBRK6(Image img) {
		this.imgTot1=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
		
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(imgTot1, 0, 0, null);	//(0,0)은 x,y값
	}
	
}
class panelBRK7 extends JPanel{
	
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image imgTot1;	
	
	public panelBRK7(Image img) {
		this.imgTot1=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
		
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(imgTot1, 0, 0, null);	//(0,0)은 x,y값
	}
	
}
class endpanel4 extends JPanel{
	
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image imgTot1;	
	
	public endpanel4(Image img) {
		this.imgTot1=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
		
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(imgTot1, 0, 0, null);	//(0,0)은 x,y값
	}
	
}