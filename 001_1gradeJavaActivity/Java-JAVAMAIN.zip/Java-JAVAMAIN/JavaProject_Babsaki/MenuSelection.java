package Babsakiproject;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;		//JButton추가
import javax.swing.JFrame;		//JFrame추가
import javax.swing.JPanel;		//JPanel추가

//메뉴 선택화면 클래스 
class ImagePanel extends JPanel{
	//1.이미지를 패널에 넣을 수 있게 설정
	private Image img;	
	
	public ImagePanel(Image img) {
		this.img=img;	//나중에 JPanel을 바꿀 수 있게 밖에서 쓸 수 있도록 함
		setSize(new Dimension(img.getWidth(null),img.getHeight(null)));		//사진이 panel에 맞게 조절됨
		setPreferredSize(new Dimension(img.getWidth(null),img.getHeight(null)));
		setLayout(null);	//이미지에 다른 것 추가 가능하게 함
	}
	public void paintComponent(Graphics g) {		//paintComponent : 패널을 열었을 때 자동으로 이미지를 비춰주는 기능 
		g.drawImage(img, 0, 0, null);				//(0,0)은 x,y값
	}
}

//Main
public class MenuSelection {
	public static void main(String args[]) {
		JFrame frame=new JFrame();		//JFrame 생성
		//JPanel panel1=new JPanel();	//JPanel 생성
		//JButton btn0=new JButton();		//JButton btn0생성
		JButton btn1=new JButton();		//JButton btn1생성
		JButton btn2=new JButton();		//JButton btn2생성
		JButton btn3=new JButton();		//JButton btn3생성
		JButton btn4=new JButton();		//JButton btn4생성
		JButton btn5=new JButton();		//JButton btn5생성
		JButton btn6=new JButton();		//JButton btn6생성
		
		ImagePanel imgpanel1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\MenuSelection_Backimg.png").getImage());//2.배경이미지 있는 패널 생성
		ImagePanel panelMEB1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\모닝계란빵\\001.png").getImage());//패널 생성
		ImagePanel panelEGS1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\떡볶이\\001.png").getImage());//패널 생성
		ImagePanel panelBBG1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\밥버거\\001.png").getImage());//패널 생성
		ImagePanel panelTRB1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\참치주먹밥\\001.png").getImage());//패널 생성
		ImagePanel panelTOK1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\식빵러스크\\001.png").getImage());//패널 생성
		ImagePanel panelCOC1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\콘치즈\\001.png").getImage());//패널 생성
		
		
	

		
		//프레임(하나의 툴) 설정
		frame.setTitle("Babsaki");//창의 타이틀
		frame.setVisible(true);	//프레임보이게 만들기
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//JFrame이 정상적으로 종료되게
		frame.setResizable(false);//창의 크기를 변경하지 못하게
		frame.setLayout(null);	 //프레임 레이아웃
		frame.setSize(1216,714);//프레임의 크기
		frame.setLocation(10,10);//창이 가운데 나오게하기 
		
		//프레임에 추가되는 것들
		frame.add(imgpanel1);						//frame에 이미지패널 추가
		frame.getContentPane().add(panelMEB1);		//frame에 panelMEB1 추가 
		panelMEB1.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
		frame.getContentPane().add(panelEGS1);		//frame에 panelMEB2 추가 
		panelEGS1.setVisible(false);				//처음화면에 panelMEB2 보이지 않게 하기 
		frame.getContentPane().add(panelBBG1);		//처음화면에 panelMEB3 보이지 않게 하기 
		panelBBG1.setVisible(false);				//처음화면에 panelMEB3 보이지 않게 하기 
		frame.getContentPane().add(panelTRB1);			//처음화면에 panelMEB4 보이지 않게 하기 
		panelTRB1.setVisible(false);				//처음화면에 panelMEB4 보이지 않게 하기 
		frame.getContentPane().add(panelTOK1);			//처음화면에 panelMEB5 보이지 않게 하기 
		panelTOK1.setVisible(false);				//처음화면에 panelMEB5 보이지 않게 하기 
		frame.getContentPane().add(panelCOC1);			//처음화면에 panelMEB6 보이지 않게 하기 
		panelCOC1.setVisible(false);				//처음화면에 panelMEB6 보이지 않게 하기 
		
		
		//이미지 패널에 버튼 추가 
		//imgpanel1.add(btn0);	//홈버튼
		imgpanel1.add(btn1);	//모닝계란빵 버튼
		imgpanel1.add(btn2);	//계란찜 버튼 
		imgpanel1.add(btn3);	//마약토스트버튼
		imgpanel1.add(btn4);
		imgpanel1.add(btn5);
		imgpanel1.add(btn6);

		
		//버튼1 설정(모닝계란빵)
		btn1.setVisible(true);
		btn1.setBounds(170, 250, 276, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btn1.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\MorningEggBread_result.PNG"));
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				imgpanel1.setVisible(false);
				panelMEB1.setVisible(true);
				
			}
		});
		
		
		//버튼2 설정(떡볶이)
		btn2.setBounds(450, 250, 276, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btn2.setVisible(true);
		btn2.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\떡볶이\\결과.PNG"));
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				imgpanel1.setVisible(false);
				panelEGS1.setVisible(true);
				
			}
		});
		
		
		//버튼3 설정(밥버거)
		btn3.setBounds(730, 250, 276, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btn3.setVisible(true);
		btn3.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\밥버거\\밥버거_result.png"));
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				imgpanel1.setVisible(false);
				panelBBG1.setVisible(true);
				
			}
		});
		
		//버튼4 설정(참치주먹밥)
		btn4.setBounds(730, 452, 276, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btn4.setVisible(true);
		btn4.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\참치주먹밥\\참치주먹밥result.png"));
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				imgpanel1.setVisible(false);
				panelTRB1.setVisible(true);
				
			}
		});
		//버튼5 설정(식빵러스크)
		btn5.setBounds(170, 452, 276, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btn5.setVisible(true);
		btn5.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\식빵러스크\\결과.png"));
		btn5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				imgpanel1.setVisible(false);
				panelTOK1.setVisible(true);
				
			}
		});
		//버튼6 설정(콘치즈)
		btn6.setBounds(450, 452, 276, 200);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btn6.setVisible(true);
		btn6.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\콘치즈\\과정12.png"));
		btn6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				imgpanel1.setVisible(false);
				panelCOC1.setVisible(true);
				
			}
		});
//-------------------엔딩화면-----------------------------------------------------------------------------------------------------------
		ImagePanel endpanel1=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\밥새끼uiend.png").getImage());//패널 생성
		JButton btnEndToHome1=new JButton();
		
		frame.getContentPane().add(endpanel1);			//처음화면에 panelMEB1 보이지 않게 하기 
		endpanel1.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
		
		//콘치즈 다음 넘기기 버튼10-끝
		btnEndToHome1.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnEndToHome1.setVisible(true);
		btnEndToHome1.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
		btnEndToHome1.addActionListener(new ActionListener() {	
			public void actionPerformed(ActionEvent e) {
					endpanel1.setVisible(false);
					imgpanel1.setVisible(true);
						
			}
		});
		endpanel1.add(btnEndToHome1);



//-------------------콘치즈 --------------------------------------------------------------------------------------------------------------------------------------------------------------
		//콘치즈 화면1
		JButton btnNext1=new JButton();		//JButton btn1생성
		JButton btnBack1=new JButton();		//JButton btn1생성
		JButton btnNext2=new JButton();		//JButton btn2생성
		JButton btnBack2=new JButton();		//JButton btn2생성
		JButton btnNext3=new JButton();		//JButton btn3생성
		JButton btnBack3=new JButton();		//JButton btn3생성
		JButton btnNext4=new JButton();		//JButton btn4생성
		JButton btnBack4=new JButton();		//JButton btn4생성
		JButton btnNext5=new JButton();		//JButton btn5생성
		JButton btnBack5=new JButton();		//JButton btn5생성
		JButton btnNext6=new JButton();		//JButton btn6생성
		JButton btnBack6=new JButton();		//JButton btn6생성
		JButton btnNext7=new JButton();		//JButton btn7생성
		JButton btnBack7=new JButton();		//JButton btn7생성
		JButton btnNext8=new JButton();		//JButton btn7생성
		JButton btnBack8=new JButton();		//JButton btn7생성
		JButton btnNext9=new JButton();		//JButton btn7생성
		JButton btnBack9=new JButton();		//JButton btn7생성
		JButton btnNext10=new JButton();		//JButton btn7생성
		JButton btnBack10=new JButton();		//JButton btn7생성
		JButton btnBack11=new JButton();		//JButton btn7생성
		JButton Homebtn1=new JButton();		//홈으로 돌아가는 버튼
		
		
	
		ImagePanel panelCOC2=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\콘치즈\\002.png").getImage());//패널 생성
		ImagePanel panelCOC3=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\콘치즈\\003.png").getImage());//패널 생성
		ImagePanel panelCOC4=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\콘치즈\\004.png").getImage());//패널 생성
		ImagePanel panelCOC5=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\콘치즈\\005.png").getImage());//패널 생성
		ImagePanel panelCOC6=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\콘치즈\\006.png").getImage());//패널 생성
		ImagePanel panelCOC7=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\콘치즈\\007.png").getImage());//패널 생성
		ImagePanel panelCOC8=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\콘치즈\\008.png").getImage());//패널 생성
		ImagePanel panelCOC9=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\콘치즈\\009.png").getImage());//패널 생성
		ImagePanel panelCOC10=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\콘치즈\\010.png").getImage());//패널 생성
		
	
		
		frame.getContentPane().add(panelCOC2);			//처음화면에 panelMEB1 보이지 않게 하기 
		panelCOC2.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
		frame.getContentPane().add(panelCOC3);			//처음화면에 panelMEB1 보이지 않게 하기 
		panelCOC3.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
		frame.getContentPane().add(panelCOC4);			//처음화면에 panelMEB1 보이지 않게 하기 
		panelCOC4.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
		frame.getContentPane().add(panelCOC5);			//처음화면에 panelMEB1 보이지 않게 하기 
		panelCOC5.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
		frame.getContentPane().add(panelCOC6);			//처음화면에 panelMEB1 보이지 않게 하기 
		panelCOC6.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
		frame.getContentPane().add(panelCOC7);			//처음화면에 panelMEB1 보이지 않게 하기 
		panelCOC7.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
		frame.getContentPane().add(panelCOC8);			//처음화면에 panelMEB1 보이지 않게 하기 
		panelCOC8.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
		frame.getContentPane().add(panelCOC9);			//처음화면에 panelMEB1 보이지 않게 하기 
		panelCOC9.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
		frame.getContentPane().add(panelCOC10);			//처음화면에 panelMEB1 보이지 않게 하기 
		panelCOC10.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
		
	
//---------------------------------------콘치즈 버튼-----------------------------------------------------------------------------------------------------------------------------------
		//콘치즈 다음 넘기기 버튼1
		btnNext1.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNext1.setVisible(true);
		btnNext1.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
		btnNext1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelCOC1.setVisible(false);
				panelCOC2.setVisible(true);
				
			}
		});
		panelCOC1.add(btnNext1);
		
		//콘치즈 다음 넘기기 버튼2
		btnNext2.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNext2.setVisible(true);
		btnNext2.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
		btnNext2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelCOC2.setVisible(false);
				panelCOC3.setVisible(true);
				
			}
		});
		panelCOC2.add(btnNext2);
		
		//콘치즈 다음 넘기기 버튼3
		btnNext3.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNext3.setVisible(true);
		btnNext3.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
		btnNext3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelCOC3.setVisible(false);
				panelCOC4.setVisible(true);
				
			}
		});
		panelCOC3.add(btnNext3);
		
		//콘치즈 다음 넘기기 버튼4
		btnNext4.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNext4.setVisible(true);
		btnNext4.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
		btnNext4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelCOC4.setVisible(false);
				panelCOC5.setVisible(true);
				
			}
		});
		panelCOC4.add(btnNext4);
		
		//콘치즈 다음 넘기기 버튼5
		btnNext5.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNext5.setVisible(true);
		btnNext5.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
		btnNext5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelCOC5.setVisible(false);
				panelCOC6.setVisible(true);
				
			}
		});
		panelCOC5.add(btnNext5);
		
		//콘치즈 다음 넘기기 버튼6
		btnNext6.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNext6.setVisible(true);
		btnNext6.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
		btnNext6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelCOC6.setVisible(false);
				panelCOC7.setVisible(true);
				
			}
		});
		panelCOC6.add(btnNext6);
		
		//콘치즈 다음 넘기기 버튼7
		btnNext7.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNext7.setVisible(true);
		btnNext7.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
		btnNext7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelCOC7.setVisible(false);
				panelCOC8.setVisible(true);
				
			}
		});
		panelCOC7.add(btnNext7);
		
		//콘치즈 다음 넘기기 버튼8-9
		btnNext8.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNext8.setVisible(true);
		btnNext8.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
		btnNext8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelCOC8.setVisible(false);
				panelCOC9.setVisible(true);
				
			}
		});
		panelCOC8.add(btnNext8);
		
		//콘치즈 다음 넘기기 버튼9-10
		btnNext9.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNext9.setVisible(true);
		btnNext9.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
		btnNext9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelCOC9.setVisible(false);
				panelCOC10.setVisible(true);
				
			}
		});
		panelCOC9.add(btnNext9);
		
		//콘치즈 다음 넘기기 버튼10-끝
		btnNext10.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNext10.setVisible(true);
		btnNext10.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
		btnNext10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelCOC10.setVisible(false);
				endpanel1.setVisible(true);
				
			}
		});
		panelCOC10.add(btnNext10);
		


//----------------------------------------이전버튼------------------------------------------------------------------------------------
			//콘치즈 이전버튼
			btnBack1.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack1.setVisible(true);
			btnBack1.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						
						panelCOC1.setVisible(false);
						imgpanel1.setVisible(true);	
				}
			});
			panelCOC1.add(btnBack1);
			//콘치즈 이전버튼
			btnBack2.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack2.setVisible(true);
			btnBack2.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						
						panelCOC2.setVisible(false);
						panelCOC1.setVisible(true);	
				}
			});
			panelCOC2.add(btnBack2);
			//콘치즈 이전버튼
			btnBack3.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack3.setVisible(true);
			btnBack3.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						
						panelCOC3.setVisible(false);
						panelCOC2.setVisible(true);	
				}
			});
			panelCOC3.add(btnBack3);
	
			panelCOC4.add(btnBack4);
			//콘치즈 이전버튼
			btnBack4.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack4.setVisible(true);
			btnBack4.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						
						panelCOC4.setVisible(false);
						panelCOC3.setVisible(true);	
				}
			});
			panelCOC4.add(btnBack4);
			//콘치즈 이전버튼
			btnBack5.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack5.setVisible(true);
			btnBack5.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						
						panelCOC5.setVisible(false);
						panelCOC4.setVisible(true);	
				}
			});
			panelCOC5.add(btnBack5);
			//콘치즈 이전버튼
			btnBack6.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack6.setVisible(true);
			btnBack6.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						
						panelCOC6.setVisible(false);
						panelCOC5.setVisible(true);	
				}
			});
			panelCOC6.add(btnBack6);
			//콘치즈 이전버튼
			btnBack7.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack7.setVisible(true);
			btnBack7.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						
						panelCOC7.setVisible(false);
						panelCOC6.setVisible(true);	
				}
			});
			panelCOC7.add(btnBack7);
			//콘치즈 이전버튼
			btnBack8.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack8.setVisible(true);
			btnBack8.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						
						panelCOC8.setVisible(false);
						panelCOC7.setVisible(true);	
				}
			});
			panelCOC8.add(btnBack8);
			//콘치즈 이전버튼
			btnBack9.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack9.setVisible(true);
			btnBack9.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						
						panelCOC9.setVisible(false);
						panelCOC8.setVisible(true);	
				}
			});
			panelCOC9.add(btnBack9);
			//콘치즈 이전버튼
			btnBack10.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack10.setVisible(true);
			btnBack10.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						
						panelCOC10.setVisible(false);
						panelCOC9.setVisible(true);	
				}
			});
			panelCOC10.add(btnBack10);
			btnBack11.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack11.setVisible(true);
			btnBack11.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						
						endpanel1.setVisible(false);
						panelCOC10.setVisible(true);	
				}
			});
			endpanel1.add(btnBack11);
			
		

//---------------------------------------------------------------------------모닝계란빵--------------------------------------------------------
		
		//panelMEB2
		JButton btnNext11=new JButton();		//JButton btn1생성
		JButton btnNext12=new JButton();			//JButton btn2생성
		JButton btnNext13=new JButton();		//JButton btn3생성
		JButton btnNext14=new JButton();		//JButton btn4생성
		JButton btnNext15=new JButton();		//JButton btn5생성
		JButton btnNext16=new JButton();		//JButton btn5생성
		JButton btnNext17=new JButton();		//JButton btn5생성
		
		
		//이전버튼
		JButton btnBack12=new JButton();		//JButton btn1생성
		JButton btnBack13=new JButton();			//JButton btn2생성
		JButton btnBack14=new JButton();		//JButton btn3생성
		JButton btnBack15=new JButton();		//JButton btn4생성
		JButton btnBack16=new JButton();		//JButton btn5생성
		JButton btnBack17=new JButton();		//JButton btn5생성
		
		
		ImagePanel panelMEB2=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\모닝계란빵\\002.png").getImage());//패널 생성
		ImagePanel panelMEB3=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\모닝계란빵\\003.png").getImage());//패널 생성
		ImagePanel panelMEB4=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\모닝계란빵\\004.png").getImage());//패널 생성
		ImagePanel panelMEB5=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\모닝계란빵\\\\005.png").getImage());//패널 생성
		ImagePanel endpanel2=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\밥새끼uiend.png").getImage());//패널 생성
		
		frame.getContentPane().add(panelMEB2);			//처음화면에 panelMEB1 보이지 않게 하기 
		panelMEB2.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
		frame.getContentPane().add(panelMEB3);			//처음화면에 panelMEB1 보이지 않게 하기 
		panelMEB3.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
		frame.getContentPane().add(panelMEB4);			//처음화면에 panelMEB1 보이지 않게 하기 
		panelMEB4.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
		frame.getContentPane().add(panelMEB5);			//처음화면에 panelMEB1 보이지 않게 하기 
		panelMEB5.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
		frame.getContentPane().add(endpanel2);			//처음화면에 panelMEB1 보이지 않게 하기 
		endpanel2.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
		
		
//----------------------------------------------------------------------모닝계란빵다음버튼----------------------------------------------------
		
		btnNext12.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNext12.setVisible(true);
		btnNext12.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
		btnNext12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelMEB1.setVisible(false);
				panelMEB2.setVisible(true);
				
			}
		});
		panelMEB1.add(btnNext12);
		
		btnNext13.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNext13.setVisible(true);
		btnNext13.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
		btnNext13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelMEB2.setVisible(false);
				panelMEB3.setVisible(true);
				
			}
		});
		panelMEB2.add(btnNext13);
		
		btnNext14.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNext14.setVisible(true);
		btnNext14.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
		btnNext14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelMEB3.setVisible(false);
				panelMEB4.setVisible(true);
				
			}
		});
		panelMEB3.add(btnNext14);
		
		btnNext15.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNext15.setVisible(true);
		btnNext15.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
		btnNext15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelMEB4.setVisible(false);
				panelMEB5.setVisible(true);
				
			}
		});
		panelMEB4.add(btnNext15);
		
		//엔딩화면으로 넘어가는 버튼
		btnNext16.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNext16.setVisible(true);
		btnNext16.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
		btnNext16.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				panelMEB5.setVisible(false);
				endpanel2.setVisible(true);
				
			}
		});
		panelMEB5.add(btnNext16);
		
		//엔딩화면에서 홈화면으로 돌아가는 버튼 
		btnNext17.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
		btnNext17.setVisible(true);
		btnNext17.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
		btnNext17.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				endpanel2.setVisible(false);
				imgpanel1.setVisible(true);
				
			}
		});
		endpanel2.add(btnNext17);
		
	
//----------------------------------------------------------------------모닝계란빵이전버튼----------------------------------------------------
				
				btnBack12.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnBack12.setVisible(true);
				btnBack12.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
				btnBack12.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelMEB1.setVisible(false);
						imgpanel1.setVisible(true);
						
					}
				});
				panelMEB1.add(btnBack12);
				
				btnBack13.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnBack13.setVisible(true);
				btnBack13.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
				btnBack13.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelMEB2.setVisible(false);
						panelMEB1.setVisible(true);
						
					}
				});
				panelMEB2.add(btnBack13);
				
				btnBack14.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnBack14.setVisible(true);
				btnBack14.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
				btnBack14.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelMEB3.setVisible(false);
						panelMEB2.setVisible(true);
						
					}
				});
				panelMEB3.add(btnBack14);
				
				btnBack15.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnBack15.setVisible(true);
				btnBack15.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
				btnBack15.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelMEB4.setVisible(false);
						panelMEB3.setVisible(true);
						
					}
				});
				panelMEB4.add(btnBack15);

				btnBack16.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnBack16.setVisible(true);
				btnBack16.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
				btnBack16.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						panelMEB5.setVisible(false);
						panelMEB4.setVisible(true);
						
					}
				});
				panelMEB5.add(btnBack16);
				
				btnBack17.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
				btnBack17.setVisible(true);
				btnBack17.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
				btnBack17.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						endpanel2.setVisible(false);
						panelMEB5.setVisible(true);
						
					}
				});
				endpanel2.add(btnBack17);
				
//---------------------------------------------------------------------------참치주먹밥--------------------------------------------------------
		
			//다음버튼(참치주먹밥
			//버튼은 10의 자리 단위로 메뉴가 다름
			JButton btnNext20=new JButton();		//JButton btn1생성
			JButton btnNext21=new JButton();		//JButton btn1생성
			JButton btnNext22=new JButton();			//JButton btn2생성
			JButton btnNext23=new JButton();		//JButton btn3생성
			JButton btnNext24=new JButton();		//JButton btn4생성
			JButton btnNext25=new JButton();		//JButton btn5생성
			JButton btnNext26=new JButton();		//JButton btn5생성
			JButton btnNext27=new JButton();		//JButton btn5생성
			JButton btnNext28=new JButton();		//JButton btn5생성
			
			//이전버튼(참치주먹밥)
			JButton btnBack21=new JButton();		//JButton btn1생성
			JButton btnBack22=new JButton();			//JButton btn2생성
			JButton btnBack23=new JButton();		//JButton btn3생성
			JButton btnBack24=new JButton();		//JButton btn4생성
			JButton btnBack25=new JButton();		//JButton btn5생성
			JButton btnBack26=new JButton();		//JButton btn5생성
			JButton btnBack27=new JButton();		//JButton btn5생성
			JButton btnBack28=new JButton();		//JButton btn5생성
				
			ImagePanel panelTRB2=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\참치주먹밥\\002.png").getImage());//패널 생성
			ImagePanel panelTRB3=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\참치주먹밥\\003.png").getImage());//패널 생성
			ImagePanel panelTRB4=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\참치주먹밥\\004.png").getImage());//패널 생성
			ImagePanel panelTRB5=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\참치주먹밥\\\\005.png").getImage());//패널 생성
			ImagePanel panelTRB6=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\참치주먹밥\\\\006.png").getImage());//패널 생성
			ImagePanel panelTRB7=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\참치주먹밥\\\\007.png").getImage());//패널 생성
			ImagePanel endpanel3=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\밥새끼uiend.png").getImage());//패널 생성
				
			frame.getContentPane().add(panelTRB2);			//처음화면에 panelMEB1 보이지 않게 하기 
			panelTRB2.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
			frame.getContentPane().add(panelTRB3);			//처음화면에 panelMEB1 보이지 않게 하기 
			panelTRB3.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
			frame.getContentPane().add(panelTRB4);			//처음화면에 panelMEB1 보이지 않게 하기 
			panelTRB4.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
			frame.getContentPane().add(panelTRB5);			//처음화면에 panelMEB1 보이지 않게 하기 
			panelTRB5.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
			frame.getContentPane().add(panelTRB6);			//처음화면에 panelMEB1 보이지 않게 하기 
			panelTRB6.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
			frame.getContentPane().add(panelTRB7);			//처음화면에 panelMEB1 보이지 않게 하기 
			panelTRB7.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
			frame.getContentPane().add(endpanel3);			//처음화면에 panelMEB1 보이지 않게 하기 
			endpanel3.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
				
//----------------------------------------------------------------------참치주먹밥다음버튼----------------------------------------------------
			
			
			btnNext21.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext21.setVisible(true);
			btnNext21.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext21.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelTRB1.setVisible(false);
						panelTRB2.setVisible(true);
						
					}
			});
			panelTRB1.add(btnNext21);//panelTRB1에서 2으로 넘어가는 버튼
			
				
		
			btnNext22.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext22.setVisible(true);
			btnNext22.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext22.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelTRB2.setVisible(false);
						panelTRB3.setVisible(true);
						
					}
			});
			panelTRB2.add(btnNext22);	//panelTRB2에서 3으로 넘어가는 버튼
			
		
			btnNext23.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext23.setVisible(true);
			btnNext23.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext23.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelTRB3.setVisible(false);
						panelTRB4.setVisible(true);
						
					}
			});
			panelTRB3.add(btnNext23);	//panelTRB3에서 4으로 넘어가는 버튼
			
			
			btnNext24.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext24.setVisible(true);
			btnNext24.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext24.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelTRB4.setVisible(false);
						panelTRB5.setVisible(true);
						
					}
			});
			panelTRB4.add(btnNext24);	//panelTRB4에서 5으로 넘어가는 버튼
			
			
			btnNext25.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext25.setVisible(true);
			btnNext25.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext25.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelTRB5.setVisible(false);
						panelTRB6.setVisible(true);
						
					}
			});		
			panelTRB5.add(btnNext25);	//panelTRB5에서 6으로 넘어가는 버튼

			
			
			btnNext26.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext26.setVisible(true);
			btnNext26.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext26.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelTRB6.setVisible(false);
						panelTRB7.setVisible(true);
						
					}
			});	
			panelTRB6.add(btnNext26);	//panelTRB6에서 7으로 넘어가는 버튼
			
			btnNext27.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext27.setVisible(true);
			btnNext27.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext27.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelTRB7.setVisible(false);
						endpanel3.setVisible(true);
						
					}
			});	
			panelTRB7.add(btnNext27);		//panelTRB7에서 엔딩패널로 넘어가는 버튼
			
			btnNext28.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext28.setVisible(true);
			btnNext28.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext28.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						endpanel3.setVisible(false);
						imgpanel1.setVisible(true);
						
					}
			});	
			endpanel3.add(btnNext28);		//엔딩패널에서 홈으로 돌아가는 버튼
			
//----------------------------------------------------------------------참치주먹밥이전버튼----------------------------------------------------
			//21부터 
			btnBack21.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack21.setVisible(true);
			btnBack21.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack21.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					panelTRB1.setVisible(false);
					imgpanel1.setVisible(true);
					
				}
			});
			panelTRB1.add(btnBack21);
			
			btnBack22.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack22.setVisible(true);
			btnBack22.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack22.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					panelTRB2.setVisible(false);
					panelTRB1.setVisible(true);
					
				}
			});
			panelTRB2.add(btnBack22);
			
			btnBack23.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack23.setVisible(true);
			btnBack23.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack23.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					panelTRB3.setVisible(false);
					panelTRB2.setVisible(true);
					
				}
			});
			panelTRB3.add(btnBack23);
			
			btnBack24.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack24.setVisible(true);
			btnBack24.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack24.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					panelTRB4.setVisible(false);
					panelTRB3.setVisible(true);
					
				}
			});
			panelTRB4.add(btnBack24);

			btnBack25.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack25.setVisible(true);
			btnBack25.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack25.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					panelTRB5.setVisible(false);
					panelTRB4.setVisible(true);
					
				}
			});
			panelTRB5.add(btnBack25);
			
			btnBack26.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack26.setVisible(true);
			btnBack26.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack26.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					panelTRB6.setVisible(false);
					panelTRB5.setVisible(true);
					
				}
			});
			panelTRB6.add(btnBack26);
			
			btnBack27.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack27.setVisible(true);
			btnBack27.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack27.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					panelTRB7.setVisible(false);
					panelTRB6.setVisible(true);
					
				}
			});
			panelTRB7.add(btnBack27);
			
			btnBack28.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack28.setVisible(true);
			btnBack28.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack28.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					endpanel3.setVisible(false);
					panelTRB7.setVisible(true);
					
				}
			});
			endpanel3.add(btnBack28);
			
//---------------------------------------------------------------------------밥버거3--------------------------------------------------------
			
			//버튼은 10의 자리 단위로 메뉴가 다름
			JButton btnNext31=new JButton();		//JButton btn1생성
			JButton btnNext32=new JButton();			//JButton btn2생성
			JButton btnNext33=new JButton();		//JButton btn3생성
			JButton btnNext34=new JButton();		//JButton btn4생성
			JButton btnNext35=new JButton();		//JButton btn5생성
			JButton btnNext36=new JButton();		//JButton btn5생성
			JButton btnNext37=new JButton();		//JButton btn5생성
			
			//밥버거 이전버튼
			JButton btnBack31=new JButton();		//JButton btn1생성
			JButton btnBack32=new JButton();			//JButton btn2생성
			JButton btnBack33=new JButton();		//JButton btn3생성
			JButton btnBack34=new JButton();		//JButton btn4생성
			JButton btnBack35=new JButton();		//JButton btn5생성
			JButton btnBack36=new JButton();		//JButton btn5생성
			JButton btnBack37=new JButton();		//JButton btn5생성
				
			ImagePanel panelBBG2=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\밥버거\\002.png").getImage());//패널 생성
			ImagePanel panelBBG3=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\밥버거\\003.png").getImage());//패널 생성
			ImagePanel panelBBG4=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\밥버거\\004.png").getImage());//패널 생성
			ImagePanel panelBBG5=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\밥버거\\005.png").getImage());//패널 생성
			ImagePanel panelBBG6=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\밥버거\\006.png").getImage());//패널 생성
			ImagePanel endpanel4=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\밥새끼uiend.png").getImage());//패널 생성
			
			frame.getContentPane().add(panelBBG2);			//처음화면에 panelMEB1 보이지 않게 하기 
			panelBBG2.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
			frame.getContentPane().add(panelBBG3);			//처음화면에 panelMEB1 보이지 않게 하기 
			panelBBG3.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
			frame.getContentPane().add(panelBBG4);			//처음화면에 panelMEB1 보이지 않게 하기 
			panelBBG4.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
			frame.getContentPane().add(panelBBG5);			//처음화면에 panelMEB1 보이지 않게 하기 
			panelBBG5.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
			frame.getContentPane().add(panelBBG6);			//처음화면에 panelMEB1 보이지 않게 하기 
			panelBBG6.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기
			frame.getContentPane().add(endpanel4);			//처음화면에 panelMEB1 보이지 않게 하기 
			endpanel4.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기
			
//----------------------------------------------------------------------밥버거다음버튼----------------------------------------------------
			
			btnNext31.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext31.setVisible(true);
			btnNext31.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext31.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelBBG1.setVisible(false);
						panelBBG2.setVisible(true);
						
					}
			});
			panelBBG1.add(btnNext31); //panelBBG1에서 2으로 넘어가는 버튼
			
			
			btnNext32.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext32.setVisible(true);
			btnNext32.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext32.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelBBG2.setVisible(false);
						panelBBG3.setVisible(true);
						
					}
			});
			panelBBG2.add(btnNext32); //panelBBG2에서 3으로 넘어가는 버튼
			
	
			btnNext33.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext33.setVisible(true);
			btnNext33.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext33.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelBBG3.setVisible(false);
						panelBBG4.setVisible(true);
						
					}
			});
			panelBBG3.add(btnNext33); //panelBBG3에서 4으로 넘어가는 버튼
			
			btnNext34.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext34.setVisible(true);
			btnNext34.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext34.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelBBG4.setVisible(false);
						panelBBG5.setVisible(true);
						
					}
			});
			panelBBG4.add(btnNext34); //panelBBG4에서 5으로 넘어가는 버튼
			
			btnNext35.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext35.setVisible(true);
			btnNext35.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext35.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelBBG5.setVisible(false);
						panelBBG6.setVisible(true);
						
					}
			});
			panelBBG5.add(btnNext35); //panelBBG5에서 6으로 넘어가는 버튼
			
			btnNext36.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext36.setVisible(true);
			btnNext36.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext36.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelBBG6.setVisible(false);
						endpanel4.setVisible(true);
						
					}
			});		
			panelBBG6.add(btnNext36); //panelBBG6에서 엔딩패널으로 넘어가는 버튼
			
			btnNext37.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext37.setVisible(true);
			btnNext37.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext37.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						endpanel4.setVisible(false);
						imgpanel1.setVisible(true);
						
					}
			});		
			endpanel4.add(btnNext37); //엔딩패널이 홈화면으로 넘어가게 하는 버튼
			
			
//------------------------------------------------------밥버거 이전버튼-------------------------------------------------------------------
			
			btnBack31.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack31.setVisible(true);
			btnBack31.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack31.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelBBG1.setVisible(false);
						imgpanel1.setVisible(true);
						
					}
			});
			panelBBG1.add(btnBack31); //panelBBG1에서 2으로 넘어가는 버튼
			
			
			btnBack32.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack32.setVisible(true);
			btnBack32.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack32.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelBBG2.setVisible(false);
						panelBBG1.setVisible(true);
						
					}
			});
			panelBBG2.add(btnBack32); //panelBBG2에서 3으로 넘어가는 버튼
			
	
			btnBack33.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack33.setVisible(true);
			btnBack33.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack33.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelBBG3.setVisible(false);
						panelBBG2.setVisible(true);
						
					}
			});
			panelBBG3.add(btnBack33); //panelBBG3에서 4으로 넘어가는 버튼
			
			btnBack34.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack34.setVisible(true);
			btnBack34.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack34.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelBBG4.setVisible(false);
						panelBBG3.setVisible(true);
						
					}
			});
			panelBBG4.add(btnBack34); //panelBBG4에서 5으로 넘어가는 버튼
			
			btnBack35.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack35.setVisible(true);
			btnBack35.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack35.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelBBG5.setVisible(false);
						panelBBG4.setVisible(true);
						
					}
			});
			panelBBG5.add(btnBack35); //panelBBG5에서 6으로 넘어가는 버튼
			
			btnBack36.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack36.setVisible(true);
			btnBack36.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack36.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelBBG6.setVisible(false);
						panelBBG5.setVisible(true);
						
					}
			});		
			panelBBG6.add(btnBack36); //panelBBG6에서 엔딩패널으로 넘어가는 버튼
			
			btnBack37.setBounds(620,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnBack37.setVisible(true);
			btnBack37.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\이전버튼001 .png"));
			btnBack37.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						endpanel4.setVisible(false);
						panelBBG6.setVisible(true);
						
					}
			});		
			endpanel4.add(btnBack37); //panelBBG6에서 엔딩패널으로 넘어가는 버튼
			
			
//panelTOK1
//---------------------------------------------------------------------------떡볶이--------------------------------------------------------
			
			//버튼은 10의 자리 단위로 메뉴가 다름
			JButton btnNext41=new JButton();		//JButton btn1생성
			JButton btnNext42=new JButton();			//JButton btn2생성
			JButton btnNext43=new JButton();		//JButton btn3생성
			JButton btnNext44=new JButton();		//JButton btn4생성
			JButton btnNext45=new JButton();		//JButton btn5생성
			JButton btnNext46=new JButton();		//JButton btn5생성
			
			
			ImagePanel panelEGS2=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\떡볶이\\002.png").getImage());//패널 생성
			ImagePanel panelEGS3=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\떡볶이\\003.png").getImage());//패널 생성
			ImagePanel panelEGS4=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\떡볶이\\004.png").getImage());//패널 생성
			ImagePanel panelEGS5=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\떡볶이\\005.png").getImage());//패널 생성
			ImagePanel panelEGS6=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\떡볶이\\006.png").getImage());//패널 생성
			
			frame.getContentPane().add(panelEGS2);			//처음화면에 panelMEB1 보이지 않게 하기 
			panelEGS2.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
			frame.getContentPane().add(panelEGS3);			//처음화면에 panelMEB1 보이지 않게 하기 
			panelEGS3.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
			frame.getContentPane().add(panelEGS4);			//처음화면에 panelMEB1 보이지 않게 하기 
			panelEGS4.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
			frame.getContentPane().add(panelEGS5);			//처음화면에 panelMEB1 보이지 않게 하기 
			panelEGS5.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
			frame.getContentPane().add(panelEGS6);			//처음화면에 panelMEB1 보이지 않게 하기 
			panelEGS6.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
			
//---------------------------------------------------------------------떡볶이다음버튼----------------------------------------------------
			
			btnNext41.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext41.setVisible(true);
			btnNext41.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext41.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelEGS1.setVisible(false);
						panelEGS2.setVisible(true);
						
					}
			});
			panelEGS1.add(btnNext41); //panelEGS1에서 panelESG2으로 넘어가는 버튼
			
			btnNext42.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext42.setVisible(true);
			btnNext42.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext42.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelEGS2.setVisible(false);
						panelEGS3.setVisible(true);
						
					}
			});
			panelEGS2.add(btnNext42); //panelEGS2에서 panelESG3으로 넘어가는 버튼
			
			btnNext43.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext43.setVisible(true);
			btnNext43.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext43.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelEGS3.setVisible(false);
						panelEGS4.setVisible(true);
						
					}
			});
			panelEGS3.add(btnNext43); //panelEGS3에서 panelESG3으로 넘어가는 버튼
			
			btnNext44.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext44.setVisible(true);
			btnNext44.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext44.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelEGS4.setVisible(false);
						panelEGS5.setVisible(true);
						
					}
			});
			panelEGS4.add(btnNext44); //panelEGS4에서 panelESG5으로 넘어가는 버튼
			
			btnNext45.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext45.setVisible(true);
			btnNext45.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext45.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelEGS5.setVisible(false);
						panelEGS6.setVisible(true);
						
					}
			});
			panelEGS5.add(btnNext45); //panelEGS5에서 panelESG6으로 넘어가는 버튼
			
			panelEGS6.add(btnNext46);
			btnNext46.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
			btnNext46.setVisible(true);
			btnNext46.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
			btnNext46.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						panelEGS6.setVisible(false);
						endpanel1.setVisible(true);
						
					}
			});	

//---------------------------------------------------------------------------식빵러스크--------------------------------------------------------
						
						//버튼은 10의 자리 단위로 메뉴가 다름
						JButton btnNext51=new JButton();		//JButton btn1생성
						JButton btnNext52=new JButton();			//JButton btn2생성
						JButton btnNext53=new JButton();		//JButton btn3생성
						JButton btnNext54=new JButton();		//JButton btn4생성
						JButton btnNext55=new JButton();		//JButton btn5생성
						JButton btnNext56=new JButton();		//JButton btn5생성
						JButton btnNext57=new JButton();		//JButton btn5생성
						
						
						ImagePanel panelTOK2=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\식빵러스크\\002.png").getImage());//패널 생성
						ImagePanel panelTOK3=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\식빵러스크\\003.png").getImage());//패널 생성
						ImagePanel panelTOK4=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\식빵러스크\\004.png").getImage());//패널 생성
						ImagePanel panelTOK5=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\식빵러스크\\005.png").getImage());//패널 생성
						ImagePanel panelTOK6=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\식빵러스크\\006.png").getImage());//패널 생성
						ImagePanel panelTOK7=new ImagePanel(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\식빵러스크\\007.png").getImage());//패널 생성
						
						frame.getContentPane().add(panelTOK2);			//처음화면에 panelMEB1 보이지 않게 하기 
						panelTOK2.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
						frame.getContentPane().add(panelTOK3);			//처음화면에 panelMEB1 보이지 않게 하기 
						panelTOK3.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
						frame.getContentPane().add(panelTOK4);			//처음화면에 panelMEB1 보이지 않게 하기 
						panelTOK4.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
						frame.getContentPane().add(panelTOK5);			//처음화면에 panelMEB1 보이지 않게 하기 
						panelTOK5.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
						frame.getContentPane().add(panelTOK6);			//처음화면에 panelMEB1 보이지 않게 하기 
						panelTOK6.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
						frame.getContentPane().add(panelTOK7);			//처음화면에 panelMEB1 보이지 않게 하기 
						panelTOK7.setVisible(false);				//처음화면에 panelMEB1 보이지 않게 하기 
						
			//----------------------------------------------------------------------밥버거다음버튼----------------------------------------------------
						panelTOK1.add(btnNext51);
						btnNext51.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
						btnNext51.setVisible(true);
						btnNext51.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
						btnNext51.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
									panelTOK1.setVisible(false);
									panelTOK2.setVisible(true);
									
								}
						});
						
						panelTOK2.add(btnNext52);
						btnNext52.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
						btnNext52.setVisible(true);
						btnNext52.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
						btnNext52.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
									panelTOK2.setVisible(false);
									panelTOK3.setVisible(true);
									
								}
						});
						
						panelTOK3.add(btnNext53);
						btnNext53.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
						btnNext53.setVisible(true);
						btnNext53.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
						btnNext53.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
									panelTOK3.setVisible(false);
									panelTOK4.setVisible(true);
									
								}
						});
						
						panelTOK4.add(btnNext54);
						btnNext54.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
						btnNext54.setVisible(true);
						btnNext54.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
						btnNext54.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
									panelTOK4.setVisible(false);
									panelTOK5.setVisible(true);
									
								}
						});
						
						panelTOK5.add(btnNext55);
						btnNext55.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
						btnNext55.setVisible(true);
						btnNext55.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
						btnNext55.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
									panelTOK5.setVisible(false);
									panelTOK6.setVisible(true);
									
								}
						});
						
						panelTOK6.add(btnNext56);
						btnNext56.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
						btnNext56.setVisible(true);
						btnNext56.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
						btnNext56.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
									panelTOK6.setVisible(false);
									panelTOK7.setVisible(true);
									
								}
						});			
						panelTOK7.add(btnNext57);
						btnNext57.setBounds(892,574,250,94);				//b.setBounds( x, y, w, h);	위치(x,y),가로,세로
						btnNext57.setVisible(true);
						btnNext57.setIcon(new ImageIcon("F:\\003_Java\\002_밥새끼프로젝트\\images\\NextButton002.png"));
						btnNext57.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent e) {
									panelTOK7.setVisible(false);
									endpanel1.setVisible(true);
									
								}
						});		
	
	}//Main끝
	

}//Class끝



















