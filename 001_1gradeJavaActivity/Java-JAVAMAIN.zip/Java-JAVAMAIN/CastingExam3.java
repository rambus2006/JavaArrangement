public class CastingExam3{
	public static void main(String args[]){
		/*int a =130;		
		byte b= (byte)a;
		System.out.println( b);*/

		final int c =100;		//변하지 않는 상수의 형태
		c=200;
		
	}
}