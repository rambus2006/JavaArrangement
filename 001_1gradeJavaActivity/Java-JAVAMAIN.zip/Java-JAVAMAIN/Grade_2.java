public class Grade_2 {
     public static void main(String args[]) {


	System.out.println("========�ڹٽ���========");
	System.out.println("�̸�	����	���ʽ�	�հ�");

	String name="����";
	int project=82;
	int bonus=7;
	int tot=project+bonus;

	System.out.println(name+"	"+project+"	"+bonus+"	"+tot);

	name="����";
	project=90;
	bonus=10;
	tot=project+bonus;

	System.out.println(name+"	"+project+"	"+bonus+"	"+tot);

	name="����";
	project=80;
	bonus=6;
	tot=project+bonus;

	System.out.println(name+"	"+project+"	"+bonus+"	"+tot);
   }
}