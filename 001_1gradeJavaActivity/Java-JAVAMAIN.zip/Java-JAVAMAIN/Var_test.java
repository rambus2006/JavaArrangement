public class Var_test {
	public static void main( String args[]) {
	int a =10 ;
	int b=20;
	int c= a+b;
	String str = "�ڹٸ� ���ô�!~";
	System.out.println(a);
 	System.out.println(b);
	System.out.println(c);
	System.out.println(str);
}
}