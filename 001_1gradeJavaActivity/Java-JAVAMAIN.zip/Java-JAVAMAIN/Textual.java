public class Textual {
	public static void main( String args[]) {
		char a,b,c;
		 a= 'A';
		 b='��';
		c='\u0061';	//�����ڵ� a
	System.out.println( a );
	System.out.println( b );
	System.out.println(  );
 	/* int a =3;
	int b =5;
	System.out.println(a+b);*/

	}
}