package _001_03_배열응용;

public class snail {
	public static void main(String args[]) {
			int [][]snail=new int[3][3];
			int a=1;
			
			
			for(int i=0;i<snail.length;i++) {	//3
				for(int j=0;j<4;j++) {			//3
					snail[i][j]=a++;
					System.out.print(snail[i][j]+" ");
					if(i==3) {
						for(int k=3;k<snail.length;k--) {
							snail[k][j]=a++;
							System.out.println(snail[k][j]+" ");
						}
					}
				}
				System.out.println("\n");
				
			}
		
		
			
				
			
	}
		
}
