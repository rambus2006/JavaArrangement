package _001_04_자료구조정렬;
/*
 * 자료구조 : 정렬
 * 문제 : 8,3,4,9,7 을 오름차순으로 정렬하시오
 * 해설 : temp = a
 * 		  a=b
 *  	  b=temp
 *  	의 과정을 통해 숫자들의 순서를 바꿔 정렬할 수 있다. 
 */
public class SelectionTest {
	public static void main(String args[]) {
		int []a= {8,3,4,9,7};
		int temp;
	}
}
