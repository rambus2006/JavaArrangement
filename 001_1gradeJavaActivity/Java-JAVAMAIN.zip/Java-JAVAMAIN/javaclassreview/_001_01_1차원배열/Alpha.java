package _001_01_1차원배열;
//A~Z까지 배열에 넣어 출력하는 코드 
public class Alpha {
	public static void main(String[] args) {
			
			/*
			 * <배열선언~배열생성>
			 * 방법1)데이터형 배열변수명[]=new 데이터형[배열의 길이];
			 * 방법2)데이터형 []배열변수명=new 데이터형[배열의 길이];
			 * 
			 * <배열선언,배열생성,배열초기화>
			 * 방법1)데이터형[]배열변수명={초기값 나여7ㄹ};
			 * 방법2)데이터형[]배열변수명=new 데이터형[]{초기값 나열}
			 */
			char ch[]=new char[26];		//char(char형배열) ch(배열이름)[]=new char(데이터형) [26](배열의 길이)
			for(int i=0;i<ch.length;i++) {		//int i=0; i가 ch.length(배열의 길이(=26)까지 반복);한바퀴 돌 때마다 i를 1씩 더하기 
				ch[i]=(char)(65+i);				//배열ch[i]에 (캐릭터형)65(유니코드65가 'A'),+i할수록 66,67,68...(=char형이므로 A,B,C,D,E,F...)
				System.out.println(ch[i]);		//ch배열방 안에 넣은 char형 을 출력
			}
		}
}
