package _001_01_1차원배열;
/*
 * 1-2+3-4+5...100
 */

public class Array_sum {
		public static void main(String[] args) {
			
				
					int sum=0;						//합을 구할 변수 
					int[] n=new int[100];			//데이터형[] 배열변수명 = new 데이터형[배열의 길이];
				
					for(int i=0;i<n.length;i++) {	//int i=0(배열이 0부터 시작하기 때문); 99까지 반복 ; i를 1씩 더하기 
						n[i]=i+1;					 	//1~100까지 수를 0~99까지의 배열 n에 넣기
						if(n[i]%2==0)n[i]=n[i]*(-1);	//만약 배열 n을 2로 나눴을 때 0과 같은 경우 n에 -1을 곱해 음수로 만듬
						else n[i]=n[i];					//0이 아닐 경우(홀수인 경우) n을 그대로 양수로 둠
						sum+=n[i];						//n을 더해서 축적하면 1-2+3-4....100으로 해서 -50이 나온다. 나온값을 sum에 대입
					}
					System.out.println(sum);			//sum출력
		}
}
