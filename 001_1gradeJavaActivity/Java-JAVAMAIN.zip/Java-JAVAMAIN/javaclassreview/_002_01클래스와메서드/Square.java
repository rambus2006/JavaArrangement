package _002_01클래스와메서드;
/*
 * 직사각형의 넓이와 둘레를 구하기
 */
public class Square {
	int width;
	int height;
	public int getArea() {
		return (this.width*this.height);
	}
	public int getRound() {
		return 2*(this.width+this.height);
	}
}
