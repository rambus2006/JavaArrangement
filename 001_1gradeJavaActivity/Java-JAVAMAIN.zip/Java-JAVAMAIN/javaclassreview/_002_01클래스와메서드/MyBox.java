package _002_01클래스와메서드;
/*
 * 교과서 60p 멤버변수만 갖는 클래스
 * 
 */
public class MyBox {
	int width;
	int height;
	int depth;
}
