package _002_01클래스와메서드;

public class TwoBoxTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
