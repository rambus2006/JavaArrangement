package _002_01클래스와메서드;

public class Student{
	public String name;
	public int grade;
	int number;
	String telephone;
}
