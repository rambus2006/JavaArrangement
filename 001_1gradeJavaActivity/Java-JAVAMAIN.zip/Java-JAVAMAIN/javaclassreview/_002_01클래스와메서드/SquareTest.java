package _002_01클래스와메서드;

public class SquareTest {
	public static void main(String args[]) {
		Square s1=new Square();
		s1.width=4;
		s1.height=5;
		System.out.println("사각형의 넓이 : "+s1.getArea());
		System.out.println("사각형의 둘레 : "+s1.getRound());
	}
}
