package _002_01클래스와메서드;
/*
 * 교과서  
 */
public class CircleTest {
	public static void main(String args[]) {
		Circle c1=new Circle(10);		//매개변수가 있는 Circle(10)이라는 객체 선언,생성 : new 연산자를 활용하여 객체를 저장할 기억공간 확보
		Circle c2=new Circle(5);
		
		System.out.println("부피 : "+c1.getArea());		//생성된 객체의 속성이나 메서드에 접근하기 위해 .연산자를 이용한다. getArea()메서드 를 불러 사용한다. 
		System.out.println("둘레 : "+c1.getRound());
	}
}
