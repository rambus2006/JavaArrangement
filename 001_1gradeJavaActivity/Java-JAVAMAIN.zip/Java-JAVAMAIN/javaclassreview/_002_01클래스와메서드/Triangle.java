package _002_01클래스와메서드;

public class Triangle {
	//멤버변수 : 클래스를 정의할 때 메서드 밖에 선언하는 변수로서 객체가 가지는 정적인 특성인 속성을 나타내는 데 사용한다.
	//private : 접근권한, 자신클래스 안에서만 사용할 수 있는 멤버 변수 
	
	//멤버변수 선언.
	private int width; //캡슐화 , 접근제어자 데이터형 변수명;
	private int height;
	
	//생성자메서드 
	public Triangle() {}		//매개변수가 없는 생성자메서드 
	public Triangle(int width, int height) {		//매개변수가 있는 생성자 메서드 
		this.width=width;
		this.height=height;
	}
	//삼각형 넓이를 구하는 일반 메서드 
	public double getArea() {
		return this.height*this.width*0.5;
	}
}
