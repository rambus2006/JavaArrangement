package _002_01클래스와메서드;

public class TriangleTest {
	public static void main(String args[]) {
		Triangle t1=new Triangle(5,7);
		System.out.println(t1.getArea());
		
	}
}
