package _002_01클래스와메서드;

public class StudentTest {
	public static void main(String args[]) {
		Student s1=new Student();
		s1.name="미림";
		s1.number=1409;
		System.out.println("인적사항 : "+s1.name+s1.number);
	}
}
