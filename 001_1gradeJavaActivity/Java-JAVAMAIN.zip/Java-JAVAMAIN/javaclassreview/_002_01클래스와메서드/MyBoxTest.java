package _002_01클래스와메서드;
/*
 * 교과서 59p 멤버변수만 갖는 메서드 
 */
public class MyBoxTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyBox b1=new MyBox();
		b1.depth=5;
		b1.height=3;
		b1.width=7;
		System.out.println("부피 : "+(b1.depth*b1.height*b1.width));
	}

}
