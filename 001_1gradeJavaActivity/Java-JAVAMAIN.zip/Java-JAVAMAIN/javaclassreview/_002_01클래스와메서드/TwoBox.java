package _002_01클래스와메서드;

class Boxes {
	//멤버변수
	int width;
	int height;
	int depth;
	//생성자 메서드 
	 public Boxes() {}
	 public Boxes(int widthconstructor,int heightconstructor,int depthconstructruor){
	  			this.width=widthconstructor;
	  			this.height=heightconstructor;	
	  			this.depth=depthconstructruor;
	 }
	 //부피 구하는 메서드 
	 public int getArea() {
		 return (this.width*this.height*depth);
	 }	
}
public class TwoBox{
	public static void main(String args[]) {
		Boxes b1=new Boxes();
		b1.width=2;
		b1.height=4;
		b1.depth=3;
		
		System.out.println("부피 : "+b1.getArea());
		
		Boxes b2=new Boxes(2,4,3);
		System.out.println("부피 : "+b2.getArea());
	}
}
