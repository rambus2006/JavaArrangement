package _002_01클래스와메서드;
/*
 *교과서  
 */
public class Circle {
	int r;
	final double PIE=3.14;
	
	//생성자 매서드 
	/*<특징>
	 * 클래스명과 같고, return 값이 없다. 
	 * 외부로부터 오는 값이 있으면 꼭 써야 하는 메서드 이다. 
	 * 구해오는 문제 : get쓰기 
	 * 변경하는 문제 : set쓰기 
	 * 변수명은 소문자로 쓰기 
	 */
	public Circle() {}	//매개변수가 없는 생성자 메서드,지금까지는 JVM이 생성해줬지만 상속 관련 오류 방지를 위해 써줌
	public Circle(int r) {	//매개변수가 있는 생성자 매서드 
		this.r=r;		//외부로부터 들어온 int r을 내가 가진 인스턴스 객체r에 넣어준다.
	}
	//원의 넓이를 구하는 매서드 
	public double getArea(){				//get(무언가의 값을 구할 때 사용)->return 타입 사용
		return (this.r*this.r*this.PIE) ;	//this(나의)
	}
	//원의 둘레를 구하는 메서드 
	public double getRound(){		
		return (this.r*2*this.r*PIE);
	}
}
