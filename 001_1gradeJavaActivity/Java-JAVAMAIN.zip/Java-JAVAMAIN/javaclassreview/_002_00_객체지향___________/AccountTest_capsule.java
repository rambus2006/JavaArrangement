package _002_00_객체지향___________;
/*
 * 교과서 54p
 * 캡슐화하기 
 * 은행계좌 생성해서 입금, 출금하기 
 */
class Account{
	int number;//계좌번호
	private int balance; //잔액
	
	//입금하는 메서드 
	public void deposit(int money) {
		balance+=money;
	}
	//출금하는 메서드
	public void withdraw(int money) {
		balance-=money;
	}
	//잔액 구하는 메서드 
	public void printBalance() {
		System.out.println("잔액 : "+balance);
	}
}
public class AccountTest_capsule {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Account a1=new Account();
		a1.printBalance();
		a1.deposit(1000000);
		a1.printBalance();
		
	}

}
