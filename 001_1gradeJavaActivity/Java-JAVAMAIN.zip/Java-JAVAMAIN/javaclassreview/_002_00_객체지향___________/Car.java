package _002_00_객체지향___________;
/* 교과서 52~56p
 * 
 */
public class Car {
	String name;
	int speed;
	
	public void stop() {
		speed=0;
	}
	public void speedup() {
		speed+=10;
	}
	public void speedDown() {
		if(speed>=10) {
			speed-=10;
		}else if(speed>=0&&speed<10) {
			speed=0;
		}
	}
}
