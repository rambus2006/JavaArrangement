package _002_00_객체지향___________;
/*교과서 57p~59p(59p예제)
 * 클래스의 정의 와 객체생성 - 원래 에러가 뜨지만 잘 돌아감
 */

public class ClassExam {
		public static void main(String args[]) {
			Student kim=new Student();	//객체 선언, 생성(Student 클래스 형의 객체 참조형 변수 kim을 선언 및 생성한다. )
			//멤버변수 선언,kim의 멤버변수값을 초기화 한다. 
			kim.name="김현우";	
			kim.grade=2;
			System.out.println("학생의 이름은"+kim.name+"이고"+kim.grade+"학년입니다. ");
		}
}
class Student{		//Student 클래스 정의하기 
	String name;		//이름
	int grade;			//학년
	int ban;			//반
	int number;			//번호
	String telephone;	//전화번호
}