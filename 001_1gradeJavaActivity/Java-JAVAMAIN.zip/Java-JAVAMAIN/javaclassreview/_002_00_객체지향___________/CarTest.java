package _002_00_객체지향___________;

public class CarTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car c1=new Car();
		c1.name="캐스퍼";
		c1.speed=0;
		c1.speedup();c1.speedup();c1.speedup();
		System.out.println(c1.name+"의 속도 : "+c1.speed);
		
		Car c2=new Car();
		c1.name="그랜저";
		
	}

}
