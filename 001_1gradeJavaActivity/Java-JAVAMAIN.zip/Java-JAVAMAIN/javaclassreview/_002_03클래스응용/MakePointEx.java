package _002_03클래스응용;
/*2022-10-25(화)
 * 과제 : MakePoint.java,MakePointEx.java
 * 문제 : 좌표상의 점을 모델링 하여 점을 생성하고 이동하는 
 * 		프로그램을 작성해보자
 * 1.x,y좌표를 입력받아 점을 생성한다. ->멤버변수 : x,y(정수, 실수 포괄할 수 있게 실수타입으로 설정)
 * 2.생성자메서드를 통해 점을 생성한다. ->new MakePoint(x,y). x,y는 scanner로 입력받음
 * 3.점의 현재 위치를 출력한다. ->현재 위치를 출력하는 일반 메서드가 필요함.
 * 4.점을 입력받은 값만큼 이동한다. ->점의 위치를 옮기는 일반 메서드가 필요함.
 */
import java.util.Scanner;
class MakePoint{
	//1.멤버변수(한줄로 쓰지 말것)
	private double x;
	private double y;
	/*<접근제어자(접근권한자)>
	 * private : 동일한 클래스 내부에서만 볼 수 있다. 
	 * public : 접근하고자 하는 누구나 볼 수 있다. 
	 * 앞에(private 이나 public이 없는 변수): 자기가 속해있는 패키지와 동일한 패키지 내부에서만 참조할 수 있다. 
	 */
	
	//2.생성자메서드 =>항상 오버로딩한다. 
	//둘 다 생성자 메서드 
	public MakePoint() {} //매개 변수가 있는 생성자 메서드를 쓸 때 상속 관계 에러 방지를 위해 넣는다. 
	public MakePoint(double x,double y) {
		this.x=x;
		this.y=y;
	}
	//3.점의 현재 위치를 출력하는 메서드
	public void printPoint() {
		System.out.println("점의 위치 : ("+this.x+","+this.y+")");
	}
	//4.점의 위치를 이동하는 메서드(x,y같이, set사용)
	public void movePoint(double dx,double dy) {
		this.x+=dx;
		this.y+=dy;
	}
}
public class MakePointEx {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		System.out.println("점의 좌표 입력(스페이스로 구분) : ");
		double x=scan.nextDouble();
		double y=scan.nextDouble();
		MakePoint p1=new MakePoint(x,y);
		p1.printPoint();
		p1.movePoint(-2.5, 9.2);
		p1.printPoint();
	}
}
