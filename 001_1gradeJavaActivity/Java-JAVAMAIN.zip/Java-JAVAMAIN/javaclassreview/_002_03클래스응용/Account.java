package _002_03클래스응용;
/*
 * 은행계좌를 정의하고 테스트하는 프로그램
 * 메서드, 클래스, 인스턴스캑체 
 */
import java.util.Scanner;
class AccountMethod{
	//1.멤버변수 
	private String BankAccountNumber;	//계좌번호 멤버변수 
	private int BankBalance;			//잔액 멤버변수 
	
	//2.생성자 메서드 
	public AccountMethod() {}
	public AccountMethod(String account,int balance) {
		this.BankAccountNumber=account;
		this.BankBalance=balance;
	}
	//3.getter, setter
	//쓰는 이유 : private한 멤버변수에 접근하기 위해서 쓴다.
	public String getBankAccountNumber() {
		return BankAccountNumber;
	}
	public void setBankAccountNumber(String bankAccountNumber) {
		BankAccountNumber = bankAccountNumber;
	}
	public int getBankBalance() {
		return BankBalance;
	}
	public void setBankBalance(int bankBalance) {
		BankBalance = bankBalance;
	}
	//4.입금하는 메서드 
	public void deposit(int depositmoney) {
		BankBalance+=depositmoney;
	}
	//5.출금하는 메서드 
	public void withdraw(int withdrawmoney) {
		if(withdrawmoney>BankBalance) {
			System.out.println("잔액이 부족합니다. ");
		}else {
			BankBalance-=withdrawmoney;
		}
	}
	//계좌의 현재 상태를 출력하는 메서드 
	public void printAccount() {
		System.out.println("잔액 : "+BankBalance+"원");
	}
	
}

public class Account {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		System.out.println("계좌번호를 입력하세요 : ");
		String BankAccountNumber=scan.next();
		System.out.print("초기잔액을 입력하세요");
		int BankBalance=scan.nextInt();
		AccountMethod a1=new AccountMethod(BankAccountNumber,BankBalance);
		while(true) {
			System.out.println("번호를 입력하세요(1-입금,2-출금,3-계좌상태확인");
			int num=scan.nextInt();
			System.out.println("번호가 입력되었습니다.");
			
			switch(num) {
					case 1:
						System.out.println("입금할 금액을 입력하세요 : ");
						int depositmoney=scan.nextInt();
						a1.deposit(depositmoney);
						System.out.println("입금되었습니다. ");
						a1.printAccount();
						break;
					case 2:
						System.out.println("출금할 금액을 입력하세요 : ");
						int withdrawmoney=scan.nextInt();
						a1.withdraw(withdrawmoney);
						a1.printAccount();
						break;
					case 3 : 
						a1.printAccount();
						break;
					default : 
						System.out.println("잘못된 숫자를 입력하셨습니다. ");
			}
		}
		
	}
}
