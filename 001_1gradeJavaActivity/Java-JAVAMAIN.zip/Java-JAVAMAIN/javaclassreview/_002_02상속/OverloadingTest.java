package _002_02상속;
/*
 * 교과서 55p_다형성-오버로딩
 */
class O{
	//메서드만 있는 클래스 
	public void study() {
		System.out.println("시험공부를 합니다.");
	}
	//매개변수가 있는 메서드(매개 변수가 있어서 메서드 명이 같아도 맞게 실행된다.)
	public void study(String name) {
		System.out.println(name+"과목의 시험공부를 합니다. ");
	}
	//매개변수가 있는 메서드(매개변수의 개수가 다르면 매서드명이 같아도 맞게 실행된다.)
	public void study(String name,int time) {
		System.out.println(name+"과목의 시험공부를 합니다."+time+"시간입니다. ");
	}
}
public class OverloadingTest {
	public static void main(String args[]) {
		O o1=new O();		//new연산자를 통해 o1이라는 인스턴스객체 생성
		o1.study();			//o1 객체를 study() 메서드를 통해 사용 
		o1.study("자바");	//o1 객체를 study(String name)메서드를 통해 사용
		o1.study("자바",4);	//o1 객체를 study(String name,int time)메서드를 통해 사용
	}
}
