package _002_02상속;

public class ClassExam {
	public static void main(String args[]) {
		Student_ kim=new Student_();		//인스턴스 객체 생성
		kim.name="김현우";
		kim.grade=3;
		kim.Class=4;
		kim.number=1;
		System.out.println("학생의 이름은 "+kim.name+"이고,"+kim.grade+"학년입니다. "+kim.Class+"반입니다. ");
	}
}
class Student_{
	String name;
	int grade;
	int Class;
	int number;
	String telephone;
}