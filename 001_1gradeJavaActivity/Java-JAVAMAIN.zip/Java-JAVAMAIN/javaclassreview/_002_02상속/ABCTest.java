package _002_02상속;
/*
 * 교과서 55p
 * 다형성-오버라이딩
 * 다형성은 객체의 메서드 형태가 다양한 것을 의미합니다. 대표적인 예로 메서드 오버로딩과 
 * 오버라이딩이 있다.
 * 오버로딩 : 하나의 클래스에서 동일한 이름의 메서드가 매개변수의 개수나 타입을 달리해서 여러가지 형태로 
 * 			존재하는 것으로 하나의 클래스에서 동일한 이름의 메서드가 다형성을 가질 수 있게 된다. 
 * 오버라이딩 : 상속관게에 있는 하위 클래스가 상위 클래스의 메서드를 재정의 하는 것으로 상속관계에서 동일한 이름의 
 * 			메서드가 다형성을 가질 수 있게 된다. 
 */
//부모클래스(상위클래스)
class A{
	String name;
	int number;
	//부모 메서드 
	public void show() {
		System.out.println("나는 부모야");
	}
}
//자식 클래스 생성,extends 는 하위 클래스 선언
class B extends A{
	public void show() {
		System.out.println("나는 부모님의 show가 싫어!나는 자식 B");
	}
}
//자식클래스 C생성
class C extends A{
	public void show() {
		System.out.println("나는 부모님의 show가 싫어!나는 자식 C");
	}
}
//main클래스 
public class ABCTest {
		public static void main(String args[]) {
			A a1=new A();
			a1.show();
			
			B b1=new B();
			b1.name="자식B";
			b1.show();
			
			C c1=new C();
			c1.name="자식";
			c1.show();
		}
		
}
