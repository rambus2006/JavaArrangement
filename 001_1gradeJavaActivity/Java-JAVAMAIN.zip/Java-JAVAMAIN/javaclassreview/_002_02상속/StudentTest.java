package _002_02상속;


class Student{
	int number;
	String name;
	public void study() {
	
	}
	public void sleep() {
		
	}
}
class Grade_1 extends Student{
	public void play() {
		
	}
}
public class StudentTest {
	public static void main(String args[]) {
		Grade_1 g1=new Grade_1();
			g1.study();
			
		
	}
}