public class Welcome{
            public static void main(String args[ ]){
                        System.out.print("Welcome Java!!!");
            }
}