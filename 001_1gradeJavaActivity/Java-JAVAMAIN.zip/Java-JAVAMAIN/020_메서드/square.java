import java.util.Scanner;
public class square{ 
	public static void main(String args[]){
		Scanner scan=new Scanner(System.in);

		int width;
		int length;

		System.out.print("���θ� �Է��ϼ��� : ");
		width= scan.nextInt();
		System.out.print("���θ� �Է��ϼ��� : ");
		length=scan.nextInt();

			
		System.out.println("���� : "+getArea(width,length));

	}
	public static int getArea(int width,int length){
		int result;
		result=width*length;
		return result;
	}
}