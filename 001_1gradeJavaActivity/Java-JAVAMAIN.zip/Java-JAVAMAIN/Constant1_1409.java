import java.util.Scanner;
public class Constant1_1409{
	public static void main(String args[]){

		Scanner scan = new Scanner(System.in);
		final int a =85;

		System.out.print("�������� : ");
		int b = scan.nextInt();
		int c = b-a;                                                                                                                                                                                                                                      
		 
		System.out.println(b+"-"+a+"="+c);
		
	}
}