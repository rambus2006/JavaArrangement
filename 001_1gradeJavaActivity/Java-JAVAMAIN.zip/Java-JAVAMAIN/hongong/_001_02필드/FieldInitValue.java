package _001_02필드;

//필드 자동 초기화 
public class FieldInitValue {
	//필드
	byte byteField;
	short shortField;
	int intField;
	long longField;
	
	boolean booleanField;
	char charField;
	
	float floatField;
	double doubleField;
	
	int[]arrField;
	short referenceField;
}

