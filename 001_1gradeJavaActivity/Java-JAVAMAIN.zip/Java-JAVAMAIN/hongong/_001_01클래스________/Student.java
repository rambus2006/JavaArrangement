package _001_01클래스________;
/*
 * 219p 클래스 선언부터 객체 생성
 */

//라이브러리용 클래스(다른 클래스에서 이용할 목적으로 설계됩니다.)
public class Student {		//Student 객체 생성
//라이브러리로서의 코드(필드, 생성자, 메서드)
	//(....필드, 생성자, 메서드 등이 오겠지)
	
	//main메서드(라이브러리 클래스인데 동시에 실행클래스로 만들기)
	public static void main(String args[]) {
	Student s1=new Student();
		System.out.println("s1 변수가 Student 객체를 참조합니다.");
	
	Student s2=new Student();
		System.out.println("s2 변수가 Student 객체를 참조합니다.");
	}
	
}
