package _001_04메서드;
//메서드 오버로딩
class Calcuator_265p{
	//정사각형의 넓이
	double areaRectangle(double width) {
		return width*width;
	}
	//직사각형의 넓이
	double areaRectangle(double width,double height) {
		return width*height;
	}
}
public class Calculator265p {

	public static void main(String[] args) {
		Calcuator_265p c1=new Calcuator_265p();
		
		//정사각형의넓이 구하기 
		double result1=c1.areaRectangle(10);
		//직사각형의 넓이 구하기 
		double result2=c1.areaRectangle(10, 20);
		
		//결과 출력하기
		System.out.println("정사각형의 넓이"+result1);
		System.out.println("직사각형의 넓이 : "+result2);
	}

}
