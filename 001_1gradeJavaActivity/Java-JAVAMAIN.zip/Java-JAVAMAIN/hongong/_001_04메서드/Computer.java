package _001_04메서드;
//매개변수의 개수를 모를 경우 매개변수를 배열타입으로 선언하면 된다. 
public class Computer {
	int sum1(int[]values) {
		int sum=0;
		for(int i=0;i<values.length;i++) {
			sum+=values[i];			
		}
		return sum;
	}
}
