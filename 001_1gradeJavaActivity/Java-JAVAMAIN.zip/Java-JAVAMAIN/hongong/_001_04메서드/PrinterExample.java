package _001_04메서드;
 
class Printer{
	static void println(int value) {
		System.out.println(value);
	}
	static void println(boolean value) {
		System.out.println(value);
	}
	static void println(double value) {
		System.out.println(value);
	}
	static void println(String value) {
		System.out.println(value);
	}
}
public class PrinterExample {
	public static void main(String args[]) {
		Printer p1=new Printer();
		p1.println(10);
		p1.println(true);
		p1.println(5.7);
		p1.println("홍길동");
	}
	
}
