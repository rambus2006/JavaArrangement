package _001_04메서드;

class Car262p{
	//필드
	int speed;
	
	//생성자
	
	//메서드 
	int getSpeed() {
		return speed;
	}
	void keyTurnOn() {
		System.out.println("키를 돌립니다.");
	}
	void run() {
		for(int i=10;i<=50;i+=10) {
			speed=i;
			System.out.println("달립니다.(시속 : )"+speed+"km/h");
		}
	}
}
public class CarExample262p {

	public static void main(String[] args) {
		Car262p c1=new Car262p();
			c1.keyTurnOn();
			c1.run();
			int speed=c1.getSpeed();
			System.out.println("현재속도 : "+speed+"km/h");
	}

}
