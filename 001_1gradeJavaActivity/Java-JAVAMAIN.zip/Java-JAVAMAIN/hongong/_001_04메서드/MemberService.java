package _001_04메서드;

public class MemberService {
	boolean login(String id,String password) {
		if(id=="hong"&&password=="12345") {
			return true;
		}else {
			return false;
		}
	}
	void logout(String id) {
		System.out.println("로그아웃되었습니다.");
	}	
}

