package _001_03생성자;
//객체생성 시 생성자 선택
public class Car239pExample {

	public static void main(String[] args) {
		//생성자1 선택
		Car239p car1=new Car239p();
		System.out.println("car1.company : "+car1.company);
		System.out.println();
		
		//생성자2선택
		Car239p car2=new Car239p("자가용");
		System.out.println("car2.company : "+car2.company);
		System.out.println("car2.model : "+car2.model);
		System.out.println();
		
		//생성자3 선택
		Car239p car3=new Car239p("자가용","빨강");
		System.out.println("car3.company : "+car3.company);
		System.out.println("car3.model : "+car3.model);
		System.out.println("car3.color : "+car3.color);
		System.out.println();
		
		Car239p car4=new Car239p("택시","검정");
		System.out.println("car4.company :"+car4.company);
		System.out.println("car4.model : "+car4.model);
		System.out.println("car4.color : "+car4.color);
		System.out.println("car4.maxspeed : "+car4.maxSpeed);
	}

}
