package _001_03생성자;

public class Car242pExample {

	public static void main(String[] args) {
				//생성자1 선택
				Car239p car1=new Car239p();
				System.out.println("car1.company : "+car1.company);
				System.out.println();
				
				//생성자2선택
				Car239p car2=new Car239p("자가용");
				System.out.println("car2.company : "+car2.company);
				System.out.println("car2.model : "+car2.model);
				System.out.println();
				
				//생성자3 선택
				Car239p car3=new Car239p("자가용","빨강");
				System.out.println("car3.company : "+car3.company);
				System.out.println("car3.model : "+car3.model);
				System.out.println("car3.color : "+car3.color);
				System.out.println();
				
				Car239p car4=new Car239p("택시","검정",200);
				System.out.println("car4.company :"+car4.company);
				System.out.println("car4.model : "+car4.model);
				System.out.println("car4.color : "+car4.color);
				System.out.println("car4.maxspeed : "+car4.maxSpeed);
	
	}

}
/*
 * 개념 
 * 기본 생성자 : 클래스 선언 시 컴파일러에 의해 자동으로 추가되는 생성자입니다.
 * 생성자 선언 : 클래스로부터 객체를 생성할 때 호출되는 생성자를 명시적으로 선언할 수 있습니다. 생성자를 선언하면 기본 생성자는 생성되지 않습니다. 
 * 매개변수 : 생성자 호출 시 값을 전달받기 위해 선언되는 변수를 말합니다. 
 * 객체 초기화  : 객체를 사용하기 전에 준비하는 과정으로 필드를 선언할 때 초기화하거나 생성자 내부에서 필드값을 초기화 할 수 있으며, 메서드를 호출하는 내용으로 구성됩니다. 
 * 오버로딩 : 매개변수를 달리하는 생성자를 여러개 선언하는 것을 말합니다. 
 * this() : 객체 자신의 또 다른 생성자를 호출할 때 사용합니다. 
 *  */
