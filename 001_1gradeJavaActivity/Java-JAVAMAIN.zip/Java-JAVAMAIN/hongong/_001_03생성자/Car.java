package _001_03생성자;

public class Car {
	//생성자
	Car(String color,int cc){
		
	}
}
