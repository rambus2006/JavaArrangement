package _001_03생성자;

public class KoreanExample {
	public static void main(String args[]) {
		Korean k1=new Korean("박자바","01023456789");
		System.out.println("k1.name : "+k1.name);
		System.out.println("k1.ssn : "+k1.ssn);
		
		Korean k2=new Korean("김자반","13456856435");
		System.out.println("k2.name : "+k2.name);
		System.out.println("k2.ssn : "+k2.ssn);
		
	}
}
