package _001_03생성자;
//생성자에서 필드 초기화
public class Korean {
	//필드
	//선언한 String 변수들은 멤버변수 
	String nation="대한민국";
	String name;
	String ssn;
	
	//생성자(변수가 있으므로 변수 없는 걸 써준다. )
	public Korean() {}
	public Korean(String n,String s) {
		this.name=n;
		this.ssn=s;
	}
	
}
