package _001_03생성자;

public class CarExample {

	public static void main(String[] args) {
		Car myCar=new Car("검정",3000);
		//Car myCar=new Car();	(x)기본 생성자를 호출할 수 없다. 
	}

}
