public class Switch_Score2{
	public static void main (String args[]){

		int score=85;
		if(score==100){	
				System.out.println("�����Դϴ�.");	
		}
		else if(score>=90){		
				System.out.println("A�Դϴ�.");
		}
		else if(score>=80){
				System.out.println("B�Դϴ�.");
		}
		else if(score>=70){
				System.out.println("C�Դϴ�.");
		}
		else{
				System.out.println("D�Դϴ�.");
		}
	}
}