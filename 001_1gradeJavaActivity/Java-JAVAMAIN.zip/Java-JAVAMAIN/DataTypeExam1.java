public class DataTypeExam1{
	public static void main ( String args[ ]) {
		long a = 2147483647java ;
		
		System.out.println( a );
	}
}