public class JavaAppExam {
	public static void main( String arg[ ] ) {
	   System.out.println("Welcome to JavaWorld") ;
	}
}