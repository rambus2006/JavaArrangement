public class main2{
	public static void main(Strong args[]){
		int a= 19;
		int b=2147483647;
		double c=3.14;
		double d =7.783;
	
		int e= a+b;
		double f=a+c;		
		double g= c+d;
		double h=c+d;
		
	}
}