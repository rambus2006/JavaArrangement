public class StringTest{
	public static void main(String args[]){

		//220408_���ڿ�(String)
		/* 1.string str
		String str ="Java";	
		System.out.println(str);    // "Java"
		*/
		
		  int a=10;
		  String str ="�ȳ��ϼ���";
		  String refObj = new String("refObj");
		  System.out.println(a);
		  System.out.println(str);
		  System.out.println(refObj);


	}
}