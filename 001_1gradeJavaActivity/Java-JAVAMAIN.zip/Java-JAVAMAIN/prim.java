public class prim {
  public static void main( String args[]) {
	
	char a='A' ;
	char b='\u0041';
	System.out.println( a );
	System.out.println( b );
  }
}