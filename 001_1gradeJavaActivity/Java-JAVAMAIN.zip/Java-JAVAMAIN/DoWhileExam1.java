public class DoWhileExam1{
	public static void main(String args[]){
		int i=5;
		do{
			System.out.print( i );
			i++;
		}while( i >10);
		//숙제있음
	}
}