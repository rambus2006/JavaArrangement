package _05_7_열거타입;

/*Calendar를 이용해서 오늘의 요일을 얻고 나서 열거 타입 변수 today에 해당 열거 상수를 
 * 대입하는 예제를 살펴보자. Calendar를 사용하기 위해서는 import 문이 필요하다.
 * 
 */
import java.util.Calendar;		//Calendar클래스는 java.util패키지에 있다. 
public class EnumWeekExample {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Week today=null;//열거타입 변수 선언
		
		//일(1)~토(7)까지의 숫자를 리턴한다. 
		Calendar cal=Calendar.getInstance();		//캘린더 객체 생성
		int week=cal.get(Calendar.DAY_OF_WEEK);		//뭔지 잘 모르겠다. 
		
		//열거 상수 대입
		switch(week) {
			case 1:
				today=Week.SUNDAY; 
				break;
			case 2:
				today=Week.MONDAY;
				break;
			case 3:
				today=Week.TUESDAY;
				break;
			case 4:
				today=Week.WENESDAY;
				break;
			case 5:
				today=Week.THURSDAY;
				break;
			case 6:
				today=Week.FRIDAY;
				break;
			case 7:
				today=Week.SATURDAY;
				break;
		}
		System.out.println("오늘 요일 : "+today);
		
		if(today==Week.SUNDAY) {
			System.out.println("일요일에는 축구를 합니다.");
		}else {
			System.out.println("열심히 자바 공부합니다.");
		}
	}

}
