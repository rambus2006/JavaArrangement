package _05_6_10_향상된For문;
/*169~170p 향상된 for문
 * 배열 안의 값이 차례대로 들어가며 실행된다.가져올 다음 항목이 없으면 for문이 
 * 종료된다.
 */
public class AdvancedForExample {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[]scores = {95,71,84,93,87};
		
		int sum=0;
		for(int score:scores) {	//scores안에 있는 값들이 차례대로 score에 들어감
			sum=sum+score;	//score와 sum을 더해 sum에 넣기 
		}
		System.out.println("점수총합="+sum);
		
		//점수 평균 구하기 
		double avg=(double)sum/scores.length;
		System.out.println("점수평균="+avg);
	}

}
