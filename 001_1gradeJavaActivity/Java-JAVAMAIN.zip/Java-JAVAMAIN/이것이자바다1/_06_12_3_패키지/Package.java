package _06_12_3_패키지;

public class Package {
/*
 * [패키지]
 * 1.[Name]입력란에 상위패키지와 하위 패키지를 도트(.)로 구분해 입력
 * 		(상위패키지).(하위패키지)
 * 2.(상위패키지,하위패키지 구조적으로 보기)
 * 	 Package Explorer ->점3개->PackagePresentation->Hierarchical
 * 3.클래스 생성
 * 4.Window->ShowView->Navigator
 */
}
