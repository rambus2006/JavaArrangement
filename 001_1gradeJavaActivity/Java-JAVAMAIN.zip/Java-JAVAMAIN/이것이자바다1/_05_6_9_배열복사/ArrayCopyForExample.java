package _05_6_9_배열복사;

/*167p 배열을 복사해 늘리기
 * 배열은 한 번 생성하면 크기를 변경할 수 없기 때문에 더 많은 저장 공간이 필요하다면 
 * 보다 큰 배열을 새로 만들고 이전 배열로부터 항목값들을 복사해야 한다.배열 간의 항목값들을 
 * 복사하려면 for문을 사용하거나 System.arraycopy()메소드를 사용하면 된다. for문
 * 으로 배열을 복사하는 코드는 다음과 같다. 
 */
public class ArrayCopyForExample {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//For문으로 배열 복사하기
		int[] oldIntArray= {1,2,3};
		int[] newIntArray=new int[5];
		
		for(int i=0;i<oldIntArray.length;i++) {
			newIntArray[i]=oldIntArray[i];
		}
		for(int i=0;i<newIntArray.length;i++) {
			System.out.print(newIntArray[i]+",");
		}
	 
	}

}
