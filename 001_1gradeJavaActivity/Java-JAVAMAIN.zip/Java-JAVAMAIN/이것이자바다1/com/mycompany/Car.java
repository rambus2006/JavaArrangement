package com.mycompany;
//다른 패키지에 속하는 클래스를 사용하는 방법
/*
 * 1.패키지와 클래스를 모두 기술하는 방법
 * 2.import문 사용하기 
 */
//import com.hankook.Tire;(또는 import com.hankook.*;)
//하위패키지에 있는 클래스까지 사용하고 싶다면 
//import com.mycompany.project.*;
//(import) (상위패키지).(하위패키지).(하위패키지의 하위패키지)
public class Car {
	com.hankook.Tire tire=new com.hankook.Tire();
	
	/*
	 * Tire tire=new Tire();
	 */
}
