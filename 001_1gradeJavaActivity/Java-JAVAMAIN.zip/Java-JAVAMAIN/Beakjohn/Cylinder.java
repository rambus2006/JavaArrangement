package _001_클래스연습문제;
/*
 * 풀긴했는데 잘 모르겠음
 * 다음에 구현된 Circle 클래스를 참고로 다음을 만족하는 Cylinder 클래스를 작성하시오.
 * 원통을 나타내는 Cylinder 클래스는 Circle형의 원과 실수형의 높이를 필드로 선언
 * 메소드 getVolume()은 원통의 부피를 반환
 * Cylinder 클래스의 main() 메소드에서 반지름이 2.8, 높이가 5.6의 원통의 부피를 출력
 * 다음은 원을 나타내는 클래스 Circle
 * 
 * public class Circle {
 * public double radius;
 * public static double PI = 3.141592;
 * //생성자 구현
 * public Circle(double radius) {
 * this.radius = radius;
 * }
 * //현재 반지름을 사용하여 원의 면적을 구하는 메소드
 * public double getArea() {
 * return radius * radius * PI;
 * }
 * 위에서 구현한 Cylinder를 다음 조건에 맞도록 기능을 추가하여 작성하시오.
 * 다음과 같은 객체 생성이 가능하도록 생성자를 구현
 * Cylinder cd = new Cylinder(new Circle(2.8), 5.6);
 */
class Circle{
	private double radius;
	private double height;
	private final double PIE=3.14;
	//static 은 고정시키는 역할이라 final 대신 써도 된다. 
	
	//생성자
	public Circle() {}
	public Circle(double radius) {
		this.radius=radius;
	}
	//원을 구하는 메서드
	public double getArea() {
		return radius*radius*PIE;
	}

}
public class Cylinder {


		//학교에서 안배운거라 따라치기만 함
		Circle cir;	//뭔지 모르겠음
		double heightmain;
		public Cylinder(Circle cir,double heightmain) {
			this.cir=cir;
			this.heightmain=heightmain;
		}
		public double Volume() {
			return cir.getArea()*heightmain; //반지름과 높이를 곱함
		}
		public static void main(String args[]) {
			Circle c1=new Circle();
			System.out.print("반지름을 입력하세요 :");
			double radiusmain=2.8;
			System.out.print("높이를 입력하세요 : ");
			double heightmain=5.6;
			
			System.out.println("부피 : "+c1.getArea()*heightmain);
			//.out.println(Volume());
	}
}
