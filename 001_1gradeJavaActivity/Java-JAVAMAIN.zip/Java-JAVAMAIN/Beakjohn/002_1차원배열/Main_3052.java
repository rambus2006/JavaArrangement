package _002_1차원배열;

public class Main_3052 {

}
