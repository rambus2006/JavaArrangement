package _002_1차원배열;

//인터넷 참고하지 않고 혼자 풀기 
import java.util.Scanner;
public class Main_10807_2 {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		int N=scan.nextInt();		//첫째줄 정수 입력받기 
		int num=0;					//정수V의 개수를 세는 변수 
		//둘째줄에 배열을 선언하여 값을 저장한다. 
		int []essence=new int[N];	
		for(int i=0;i<N;i++) {
			essence[i]=scan.nextInt();
		}
		//정수 V를 입력받아 배열의 값과 같은지 비교한다. 
		int V=scan.nextInt();
		for(int i=0;i<N;i++) {
			if(essence[i]==V) {
				num++;
			}
		}
		//결과출력
		System.out.println(num);
	}
}
