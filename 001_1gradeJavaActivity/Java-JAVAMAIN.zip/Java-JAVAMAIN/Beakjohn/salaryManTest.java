package _001_클래스연습문제;

public class SalaryManTest {
	public static void main(String args[]) {
		SalaryMan s1=new SalaryMan();
		System.out.println(new SalaryMan().getAnnualGross());
	}
}
