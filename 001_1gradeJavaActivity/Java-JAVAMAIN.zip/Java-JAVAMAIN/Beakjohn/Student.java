package _001_클래스연습문제;

import java.util.Scanner;
class Studentcl {
	//문제 1, 2번
	private String department;	//학과
	private int studentID;	//학번
	
	//문제2 : getter,setter구현
	//
	public String getDepartment() {
		return department;
	}
	public int getStudentID() {
		return studentID;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}

}

public class Student {
	//객체 생성
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		
		Studentcl s1=new Studentcl();
		System.out.print("학과를 입력하세요 : ");
		String departmentmain=scan.next();
		s1.setDepartment(departmentmain);		//setter를 거쳐 private 된 멤버변수의 값을 수정
		System.out.print("학번을 입력하세요 : ");
		int studentIDmain=scan.nextInt();
		s1.setStudentID(studentIDmain);				

		System.out.println(s1.getDepartment()+s1.getStudentID());	//getter를 통해 31,32에서 변경된 값을 리턴받아 출력
	}
}



