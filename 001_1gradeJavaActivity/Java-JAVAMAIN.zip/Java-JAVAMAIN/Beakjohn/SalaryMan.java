package _001_클래스연습문제;

public class SalaryMan {
	//필드선언(멤버변수선언)
	private int salary=1000000;
	
	//연봉을 반환하는 메서드 
	public int getAnnualGross() {
		return salary*5;
	}
	
}
