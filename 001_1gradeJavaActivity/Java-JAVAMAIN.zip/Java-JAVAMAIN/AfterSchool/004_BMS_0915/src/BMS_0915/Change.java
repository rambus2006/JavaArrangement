package BMS_0915;

import java.util.Scanner;
public class Change {
/*예시출력화면
 * 돈을 입력하세요 : 12345
 * 50000원 : 0
 * 10000원 : 1
 * 5000원 : 0
 * 1000원 : 2
 * 500원 : 0
 * 100원 : 3
 * 50원 : 0
 * 10원 : 5
 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		
		System.out.print("돈을 입력하세요 : ");
		int receivemoney=scan.nextInt();
		int change=0;
		
		int money[]=new int[]{50000,10000,5000,1000,500,100,50,10,1};	//배열 초기화할 때는 길이지정하면 안됨
		
		for(int i=0;i<money.length;i++){
			
			change=receivemoney/money[i];
			receivemoney=receivemoney%money[i];
			System.out.println(money[i]+"원:"+change);
			
		}
	
	}

}
