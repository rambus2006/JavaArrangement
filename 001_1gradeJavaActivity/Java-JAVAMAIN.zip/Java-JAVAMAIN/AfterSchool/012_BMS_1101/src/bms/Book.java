package bms;

//this로 다른 생성자 호출
public class Book {
	
	//필드
	String title;
	String author;
	
	//생성자
	public Book() {}
	public Book(String title) {
		this(title,"작자미상");		//다른 생성자를 호출
	}
	public Book(String title, String author) {
		this.title=title;
		this.author=author;
	}
	//메서드 
	public void show() {
		System.out.println("제목 : "+title+" ,저자 : "+author);
	}
	public static void main(String args[]) {
		Book littlepr=new Book("어린왕자","생떽쥐베리");
		Book loveStory=new Book("춘향전");
		loveStory.show();
		littlepr.show();
	}


}
