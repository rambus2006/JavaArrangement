package bms;

public class Ractangle {
	int x;
	int y;
	int width;
	int height;
	
	public Ractangle() {}
	public Ractangle(int x,int y,int width,int height) {
		this.x=x;
		this.y=y;
		this.width=width;
		this.height=height;
	}
	public int square() {
		return width*height;
	}
	public void show() {
		System.out.println("사각형의 좌표 : "+"("+x+","+y+")");
		
	}
	
}
