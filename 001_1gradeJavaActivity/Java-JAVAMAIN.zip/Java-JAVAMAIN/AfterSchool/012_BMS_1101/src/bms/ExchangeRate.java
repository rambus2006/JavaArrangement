package bms;


import java.util.Scanner;
public class ExchangeRate {
	double usd;
	
	public ExchangeRate() {}
	public ExchangeRate(double usd) {
		this.usd=usd;
	}
	public void exchange() {
		
		double krw=1416.45;
		double money=usd*krw;
		System.out.println(money);
	}
	public static void main(String args[]) {
		ExchangeRate e1=new ExchangeRate(100);
		
		e1.exchange();
	}
}
