package bms;

public class RactangleEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ractangle r1=new Ractangle(2,2,8,7);
		Ractangle s1=new Ractangle(5,5,6,6);
		Ractangle t1=new Ractangle(1,1,10,10);
		
		r1.show();
		System.out.println("r1의 면적="+r1.square());
		s1.show();
		System.out.println("s1의 면적="+s1.square());
	}

}
