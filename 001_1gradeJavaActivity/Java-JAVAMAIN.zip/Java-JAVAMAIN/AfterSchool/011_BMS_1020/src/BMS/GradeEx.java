package BMS;

public class GradeEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Grade g1=new Grade();
		System.out.print("국어점수를 입력하세요 : ");
		System.out.println("국어 : "+ g1.kor);
		System.out.print("영어점수를 입력하세요 : ");
		System.out.println("영어 : "+ g1.eng);
		System.out.print("수학점수를 입력하세요 : ");
		System.out.println("수학 : "+ g1.mat);
		System.out.println("평균"+g1.getAve());
	}

}
