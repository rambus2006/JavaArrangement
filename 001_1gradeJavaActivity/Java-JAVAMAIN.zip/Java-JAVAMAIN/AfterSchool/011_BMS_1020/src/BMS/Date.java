package BMS;

public class Date {
	String year;
	String month;
	String day;
	
	public String show() {
		return (this.year + "년" + this.month + "월" + this.day + "일");
	}
	
}
