package BMS;

import java.util.Scanner;
public class Grade {
	
		Scanner scan=new Scanner(System.in);
		int kor=scan.nextInt();
		int eng=scan.nextInt();
		int mat=scan.nextInt();
	
	
	public int getAve() {
		return ((this.kor+this.eng+this.mat)/3);
	}
}
