package BMS;

public class TvEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Tv t1=new Tv();
		System.out.println("LG OLED TV(이)가"+t1.channelDown()+t1.turnOn()+t1.volumeUp());
		
		Tv t2=new Tv();
		System.out.println("삼성 OLED TV(이)가"+t2.channelUp()+t2.turnOff()+t2.volumeDown());
	}

}
