package BMS;

public class Song {
	String title;
	String artist;
	String year;
	String country;
	
	public String print() {		//매개변수 안넣어도 됨
		return (title+"," + artist + "," + year +","+ country );
	}
}

