package BMS;

public class DateEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date d1=new Date();
		d1.year="2022";
		d1.month="10";
		d1.day="21";
		System.out.println(d1.show());
		
		Date d2=new Date();
		d2.year="2023";
		d2.month="7";
		d2.day="31";
		System.out.println(d2.show());
	}

}
