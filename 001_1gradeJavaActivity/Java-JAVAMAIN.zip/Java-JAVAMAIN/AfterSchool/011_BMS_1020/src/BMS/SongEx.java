package BMS;

public class SongEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Song s1=new Song();
		s1.artist="bts";
		s1.country="서울";
		s1.title="butter";
		s1.year="2021";
		System.out.println(s1.print());
	}

}
