package BMS;

public class Tv {
	public String turnOn() {
		return("전원을 켠다.");
	}
	public String turnOff() {
		return("전원을 끈다.");
	}
	public String volumeUp() {
		return("볼륨음량을 키운다. ");
	}
	public String volumeDown() {
		return("볼륨을 내린다. ");
	}
	public String channelUp() {
		return("채널을 올린다. ");
	}
	public String channelDown() {
		return("채널을 내린다. ");
	}
}
