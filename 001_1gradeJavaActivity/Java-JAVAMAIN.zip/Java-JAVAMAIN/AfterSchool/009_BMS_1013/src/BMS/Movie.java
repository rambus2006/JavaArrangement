package BMS;

public class Movie {
	String Title;
	String grade;
	String director;
	String pryear;
	
	public void print() {
		Title="해리포터";
		grade="0점";
		director="간디";
		pryear="1967";
		System.out.print("제목 :"+Title);
		System.out.print("평점 :"+grade);
		System.out.print("감독 : "+director);
		System.out.print("제작연도 : "+pryear);
	}
}
