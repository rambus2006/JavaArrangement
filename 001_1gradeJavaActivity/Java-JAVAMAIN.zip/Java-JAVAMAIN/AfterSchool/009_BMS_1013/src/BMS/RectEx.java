package BMS;

public class RectEx {
	public static void main(String args[]) {
		Ractangle notebook=new Ractangle();
		notebook.width=5;
		notebook.height=4;
		int area=notebook.getArea();
		System.out.println("면적은"+area);
		
		Ractangle locker=new Ractangle();
		locker.width=3;
		locker.height=2;
		area=locker.getArea();
		System.out.println("면적은"+area);
	}
}
