package BMS;

public class Ractangle {
	int width;
	int height;
	
	public Ractangle() {
	}
	public int getArea() {
		return width*height;
	}
}
