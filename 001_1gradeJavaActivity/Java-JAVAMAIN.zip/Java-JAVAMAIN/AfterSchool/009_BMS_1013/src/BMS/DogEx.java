package BMS;

public class DogEx {
	public static void main(String args[]) {
		Dog move=new Dog();
		move.barking();
		move.hungry();
		move.sleeping();
	}
}
