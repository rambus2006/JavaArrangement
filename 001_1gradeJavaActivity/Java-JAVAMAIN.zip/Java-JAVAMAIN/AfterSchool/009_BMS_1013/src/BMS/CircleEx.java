package BMS;

public class CircleEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle pizza;
		pizza=new Circle();
		pizza.name="불고기피자";
		pizza.radius=10;
		System.out.println(pizza.name+"의 면적은"+pizza.getArea());
		
		Circle donut=new Circle();
		donut.name="글레이즈드도넛";
		donut.radius=5;
		System.out.println(donut.name+"의 면적은"+donut.getArea());
		
	}

}
