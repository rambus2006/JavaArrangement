package BMS;

public class Student {
		String name;
		int stud;
		int age;
		String phone;
		

	
	
}
