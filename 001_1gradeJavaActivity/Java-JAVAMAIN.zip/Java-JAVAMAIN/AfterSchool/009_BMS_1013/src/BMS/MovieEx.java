package BMS;
/*
 * <객체생성>
 * 1.패드(변수)
 * 2.생성자
 * 3.메소드
 */
public class MovieEx {
	public static void main(String args[]) {
		Movie m=new Movie();
		m.print();
		
	}
}
