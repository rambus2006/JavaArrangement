package BMS;

public class Circle {
	int radius;
	String name;
	
	public double getArea() {
			return 3.14*radius*radius;
	}
}

