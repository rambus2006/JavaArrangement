package BMS;

public class Dog {
	String name;
	String breed;
	String age;
	String color;
	
	public void barking() {
		System.out.println("멍멍짖는다.");
	}
	public void hungry() {
		System.out.println("배고파요");
	}
	public void sleeping() {
		System.out.println("ZZzz....");
	}
	
}
