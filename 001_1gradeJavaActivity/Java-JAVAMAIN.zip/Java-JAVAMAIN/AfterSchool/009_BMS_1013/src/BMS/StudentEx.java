package BMS;

import java.util.Scanner;
public class StudentEx {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		// TODO Auto-generated method stub
			Student st=new Student();
			st.name="학생1";
			st.stud=1409;
			st.age=17;
			st.phone="0103456754356";
			
			System.out.print(st.name+st.stud+st.age+st.phone);
	}

}
