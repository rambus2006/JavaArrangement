package mirim0913;
/*국어, 영어, 수학, 점수를 공백을 이용하여 쓰시오
 * 국거, 영어, 수학, 합계 , 평균을 구하시오
 * 80 75 98
 */
import java.util.Scanner;
public class Ex_03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan= new Scanner(System.in);
		//국어 영어 수학 점수 입력
		System.out.print("국어,영어,수학 점수를 입력하세요 : ");
		int kor=scan.nextInt();
		int eng=scan.nextInt();
		int mat=scan.nextInt();
		
		//국어 영어 수학 점수 출력
		System.out.println("국어점수:"+kor);
		System.out.println("영어점수:"+eng);
		System.out.println("수학점수:"+mat);
		
		//합계 평균출력
		int sum=(kor+eng+mat)/3;
		int avg=kor+eng+mat;
		System.out.println("합계:"+sum);
		System.out.println("평균:"+avg);
		
	}

}
