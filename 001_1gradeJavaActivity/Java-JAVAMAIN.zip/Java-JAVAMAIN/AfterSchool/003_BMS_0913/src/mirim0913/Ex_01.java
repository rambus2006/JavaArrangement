package mirim0913;
import java.util.Scanner;
public class Ex_01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ctrl+shift+o
		Scanner scanner= new Scanner(System.in);
		//이름과 나이를 공백으로 분리하여 쓰시오
		//홍길동
		System.out.println("이름과 나이를 공백으로 분리하여 쓰시오");
		String name=scanner.next();	//홍길동
		int age = scanner.nextInt();
		System.out.println("이름은"+name);
		System.out.println("나이는"+age);
	}

}
