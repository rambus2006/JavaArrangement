package mirim0913;

import java.util.Scanner;
public class Ex_06 {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		System.out.println("신장:");
		double height=scan.nextDouble();
		System.out.println("체중:");
		double weight=scan.nextDouble();
		
		double bmi=weight/(1.6*1.6);
		double StandardWeight=(height-100)*0.9;
		System.out.println(bmi);
		System.out.println(StandardWeight);
	}
}
