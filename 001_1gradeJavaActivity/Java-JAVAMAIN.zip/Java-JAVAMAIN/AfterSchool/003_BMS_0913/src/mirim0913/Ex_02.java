package mirim0913;
import java.util.Scanner;
public class Ex_02 {
//원의 면적 입력받아 구하기 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		double area;
		double PI=3.14;
		
		System.out.print("원의 반지름을 입력하세요: ");
		float radius = scan.nextFloat();
		area=PI*radius*radius;
		System.out.println("반지름 : "+radius);
		System.out.println("원의 면적"+area);
	
		//10.0의 원의 면적을 구하고 출력하시오
		
		
		
	}

}
