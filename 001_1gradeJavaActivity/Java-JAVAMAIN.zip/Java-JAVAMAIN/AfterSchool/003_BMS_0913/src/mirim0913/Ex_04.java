package mirim0913;
/*
 * 미국여행을 가려고 합니다. 
 * 한국돈 100만원으로 얼마의 달러를 살 수 있을까요
 * 오늘 환율 1374.5
 * 한국돈을 입력하시오:1000000
 * 출력 예)1000000원=>727.5달러
 */
import java.util.Scanner;
public class Ex_04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		float usamoney;
		
		System.out.print("한국돈을 입력하시오: ");
		int koreanmoney=scan.nextInt();
		
		usamoney=(float)(koreanmoney/1374.5);
		
		System.out.println(koreanmoney + "=>" + usamoney);
	}

}
