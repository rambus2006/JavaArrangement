package 방과후수업0906;

public class Ex05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int index=100;
		int ii=10;
		index = index+ii;
		System.out.println("index="+index);
	}

}
