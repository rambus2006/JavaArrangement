package 방과후수업0906;

public class Ex03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double area;
		float radius = 5.0f;
		double PI=3.141592;
		area=PI*radius*radius;
		System.out.println("원의 면적"+area);
	
		//10.0의 원의 면적을 구하고 출력하시오
		radius=10.f;
		area=PI*radius*radius;
		System.out.println(area);
		
		
	}

}
