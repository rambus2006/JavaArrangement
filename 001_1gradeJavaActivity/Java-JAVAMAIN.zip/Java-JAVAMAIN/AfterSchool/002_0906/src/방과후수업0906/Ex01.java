package 방과후수업0906;

public class Ex01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=100;
		String name="미림여자정보과학고";
		String toolName="JDK";
		toolName+=1.8;
		System.out.println("(" + 3 + "," + 5 + ")");
		System.out.println(toolName+"이 출시됨");
		System.out.println(name);
		
	}

}
