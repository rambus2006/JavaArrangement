package 방과후수업0906;

public class Ex04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean b=true;
		
		System.out.println("b="+b);
		b=(1>2);
		System.out.println("b="+b);
		b=(1==2);
		System.out.println("b="+b);
	}

}
