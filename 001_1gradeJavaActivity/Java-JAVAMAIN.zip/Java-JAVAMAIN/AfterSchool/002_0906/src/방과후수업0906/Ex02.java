package 방과후수업0906;

public class Ex02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int lightspeed;
		long distance;
		lightspeed=300000;
		distance=lightspeed*365*24*60*60;
		System.out.println("빛이 1년 동안 가는 거리"+distance+"km");
	}

}
