package 방과후수업0906;

import java.util.Scanner;
public class Array_max {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		
		int[]score=new int[10];
		int max=0;
		
		for(int i=0;i<score.length;i++) {
			System.out.print("점수를 입력하세요:");
			score[i]=scan.nextInt();
			if(score[i]>max) max=score[i];
		}
		System.out.println("최댓값:"+max);
		
	
	}

}
