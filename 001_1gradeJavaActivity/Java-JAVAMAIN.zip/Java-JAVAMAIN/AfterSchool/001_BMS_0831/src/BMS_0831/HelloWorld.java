package BMS_0831;

public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello~~");
		System.out.println("반갑습니다. 학년 반 이름입니다.");
		System.out.println("한학기 동안 열심히 배워보겠습니다. ");
	}

}
