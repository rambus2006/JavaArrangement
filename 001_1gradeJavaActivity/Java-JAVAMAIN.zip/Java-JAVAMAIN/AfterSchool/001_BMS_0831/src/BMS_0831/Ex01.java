package BMS_0831;

public class Ex01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//정수는 int 형을 많이 쓴다.
		int a = 100;
		short as = 200;
		long lo = 10000;
		char b = 'b';
		
		//실수는 double형을 많이 쓴다.
		double d = 3.14;
		float f =3.14;
		boolean tf = false;
		//String은 클래스 이다. 나머지는 자료형 변수 
		String mirim ="미림여자정보과학고";
		//연결자 (+)
		//마우스를 갖다 대서 아래쪽 맨 오른쪽 버튼을 누르면 java에 대한 설명이 되어 있는 웹사이트로 연결된다. 
		System.out.println("");
		
	}

}
