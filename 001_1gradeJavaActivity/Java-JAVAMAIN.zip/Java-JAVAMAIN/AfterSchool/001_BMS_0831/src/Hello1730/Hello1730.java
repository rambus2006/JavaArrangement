package Hello1730;

public class Hello1730 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 1730;
		System.out.println("헬로"+n);
		System.out.println("저는 방민서입니다. ");
		System.out.println("무엇이 될 것입니다. ");
		System.out.println("저는 한강 야경이 보이는 넓은 집에 사는 부자가 될 것입니다. ");
		
	}

}
