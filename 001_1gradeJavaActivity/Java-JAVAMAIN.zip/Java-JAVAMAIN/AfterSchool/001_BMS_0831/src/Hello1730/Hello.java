package Hello1730;
	/*2022.09.01
	 * 방과후 학교 자바 프로그래밍
	 * 헬로우 프로그램 학번 이름
	 */
public class Hello {
	//method 기능~하기 동사에 해당 됨. function
	public static int sum(int n,int m) {
			return n+ m;
	}
	//
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i =20;
		int s;
		char a;
		
		s=sum(i,10);
		a='?';
		//println도 method이다. 괄호가 있는 얘들은 다 method
		System.out.println(a);
		System.out.println("Hello");
		System.out.println(s);
	}

}
