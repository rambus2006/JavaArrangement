package 수행;

public class Random {

}
