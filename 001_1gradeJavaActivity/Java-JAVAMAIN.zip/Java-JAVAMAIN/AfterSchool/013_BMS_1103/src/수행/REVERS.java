package 수행;

import java.util.Scanner;
public class REVERS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.print("한글로 입력 : ");
		String str=scan.nextLine();
		
		for(int i=str.length();i>=0;i--) {
			System.out.print(str);
		}
	}
	

}
