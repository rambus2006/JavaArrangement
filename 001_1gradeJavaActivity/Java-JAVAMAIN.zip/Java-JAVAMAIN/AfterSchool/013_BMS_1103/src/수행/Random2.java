package 수행;

public class Random2 {
	public static void main(String args[]) {
		
	}
}
