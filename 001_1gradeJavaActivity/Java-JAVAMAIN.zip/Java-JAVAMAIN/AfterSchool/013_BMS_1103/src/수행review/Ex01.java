package 수행review;

import java.util.Scanner;
public class Ex01 {

	public static void main(String[] args) {
	
	}

}
