package 수행review;

import java.util.Scanner;
public class REVERS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("영문자 입력 : ");
		String str=scan.nextLine();			//String 문자 입력받기 
		
		System.out.println("변환된 문자 : ");		
		for(int i= str.length()-1;i>=0;i--) {		//for문, int i에 str의 길이에 -1을 하고, i를 하나씩 빼준다. 
			System.out.print(str.charAt(i));		//
		}
		/*
		 * scan.nextLine() : Enter키를 치기 전까지 쓴 문자열을 모두 리턴한다. 
		 * charAt : String 으로 저장된 문자열 중에서 한 글자만 선택해서 char타입으로 변환해주는 함수,앞부터 0번째에서 시작
		 */
		scan.close();
	}

}
/*
 * import java.util.Scanner;
public class ReverseStr {
	

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("영문자 입력 : ");
		String str = scan.nextLine();
		
		System.out.print("변환된 문자 : ");
		for (int i = str.length()-1; i >= 0; i--) {
			
				System.out.print(str.charAt(i));
				
		}
		
		scan.close();

	}

}

 */
