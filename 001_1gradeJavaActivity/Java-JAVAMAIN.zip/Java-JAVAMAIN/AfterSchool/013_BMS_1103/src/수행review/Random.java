package 수행review;

public class Random {
	public static void getRandom(int[][]random) {
		for(int i=0;i<random.length;i++) {	
			for(int j=0;j<random[i].length;j++) {
				random[i][j]=(int)(Math.random()*10.0)+1;
				System.out.print(random[i][j]+"\t");
			}
			System.out.println();
		}
	}
	public static void main(String args[]) {
		int[][]random=new int[4][4];
		getRandom(random);
	}
	
}
/*
 * random 함수 : 
 * Math클래스 : 수학 함수와 이에 필요한 상수들을 제공하는 클래승다. .Math클래스의 모든 메서드는 static 형으로 정의되어 있어
 * 			  상속이나 오버라이딩할 수 없는 메서드이며,Math클래스는 생성자를 제공하지 않아 객체를 생성할 수 없다. 따라서 객체 생성 
 * 			  없이 클래스 이름으로 멤버변수나 메서드를 접근한다. 
 * Math클래스의 멤버변수는 Math.E와 Math.PI가 있으며 다음과 같이 정의되어 있다. 
 */
/*
 * public class Random {
	
	public static void getRandom(int[][] random) {
		for (int i = 0; i < random.length; i++) {
			
			for (int j = 0; j < random[i].length; j++) {
				
				random[i][j] = (int)(Math.random() * 10.0) + 1;
				System.out.print(random[i][j] + "\t");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		int[][] random = new int[4][4];
		
		getRandom(random);


	}

}

 */
