package clas;
/*
 * 클래스 (오버로딩)
 */
public class Book {
	//1.필드(속성, 특징,명사, 변수)
	String title;	//제목
	String author;	//속성
	//2.생성자
	public Book() {};	//생성자 1번
	//생성자2번
	public Book(String t,String a) {
		this.title=t;
		this.author=a;
	}
		//3.메서드(행동,기능,동사)
	
}
