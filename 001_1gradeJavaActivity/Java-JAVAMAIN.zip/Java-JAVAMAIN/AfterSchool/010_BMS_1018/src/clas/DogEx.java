package clas;

public class DogEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Dog d1=new Dog("백구","시베리아 허스키",3,"검은색");
		d1.barking();
		System.out.println(d1.name+"는"+d1.color+ d1.breed+"입니다."+d1.name+"은 "+d1.age+"살 입니다.");
		Dog d2=new Dog("동동이","골든 리트리버",4,"노란색");
		System.out.println(d2.name+"는"+d2.color+ d2.breed+"입니다."+d2.name+"은 "+d2.age+"살 입니다.");
		d2.hungry();
		Dog d3=new Dog("은은이","시츄",4,"갈색");
		System.out.println(d3.name+"는"+d3.color+ d3.breed+"입니다."+d3.name+"은 "+d3.age+"살 입니다.");
		d3.hungry();
	}

}
