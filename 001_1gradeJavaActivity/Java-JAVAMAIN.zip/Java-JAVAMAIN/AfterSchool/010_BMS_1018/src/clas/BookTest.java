package clas;

public class BookTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book book1=new Book();
		book1.title="어린왕자";
		book1.author="생땍쥐베리";
		Book book2=new Book();
		book2.title="홍길동전";
		book2.author="허균";
		Book book3=new Book("구의 증명","미상");
	}

}
