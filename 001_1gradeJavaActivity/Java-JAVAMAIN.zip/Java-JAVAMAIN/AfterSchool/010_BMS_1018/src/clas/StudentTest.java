package clas;

public class StudentTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student min=new Student();
		min.name="민서";
		min.stuid="1409";
		min.age=17;
		min.phone="010-1234-1234";
		Student yun=new Student("윤서","1410",17,"010-1234-1234");
		
		Student m=new Student();
		m.name="방민서";
		m.stuid="1409";
		m.age=17;
		m.phone="010-3627-2390";
		
	}

}
