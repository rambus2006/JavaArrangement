package clas;

public class Movie {
	String title;
	String grade;
	String dir;
	String year;
	
	public Movie (String t,String g,String d,String y) {
		this.title=t;
		this.grade=g;
		this.dir=d;
		this.year=y;
		
	}
	public void print() {
		System.out.println(title+grade+dir+year);
	}
	
}
