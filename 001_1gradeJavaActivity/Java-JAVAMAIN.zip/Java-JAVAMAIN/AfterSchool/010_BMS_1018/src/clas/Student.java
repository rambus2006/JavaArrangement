package clas;

public class Student {
	//이름과 학번, 나이, 연락처
	String name;
	String stuid;
	int age;
	String phone;
	//생성자
	public Student() {};
	public Student(String name, String stuid, int age,String phone) {
		this.name=name;
		this.stuid=stuid;
		this.age=age;
		this.phone=phone;
		
	}
	
}
