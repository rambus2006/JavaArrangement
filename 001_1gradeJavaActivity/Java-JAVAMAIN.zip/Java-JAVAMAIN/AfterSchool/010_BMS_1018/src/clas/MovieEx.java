package clas;

public class MovieEx {
	public static void main(String args[]) {
		
		Movie m1=new Movie("코난:할로윈의 신부","10점만점의 10점","황홍삼","2022");
		m1.print();
	}
}
