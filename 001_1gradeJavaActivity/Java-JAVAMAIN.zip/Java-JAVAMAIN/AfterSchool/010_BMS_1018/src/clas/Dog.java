package clas;

public class Dog {
	String name;
	String breed;
	int age;
	String color;
	
	public Dog(String n,String b,int a,String c) {
		name=n;
		breed=b;
		age=a;
		color=c;
	}
	public void barking() {
		System.out.println("멍멍짖는다");
	}
	public void hungry() {
		System.out.println("배고파요");
	}
	public void sleeping() {
		System.out.println("Zzzz...");
	}

}

