package BMS_0920;

public class Ex3_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int sum =0;
		
		for(int i=0;i<=10;i++) {
			sum=sum+1;
			System.out.print(i);
		}
		System.out.print("     1~10까지의 합게=" + sum);
		
		int sum2=0;
		int ii=0;
		while(ii<=10) {
			System.out.print(ii);
			sum2=sum2+ii;
			ii++;
			
		}
		System.out.print("    1~10까지의 합게=" + sum2);
	}

}
