package BMS_0920;

import java.util.Scanner;

public class Ex3_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("정수를 입력하고 마지막에 -1을 입력하세요.");
		int n = scan.nextInt();
		int sum=0,count=0;
		while(n!=-1) {
			sum=sum+n;
			count=count+1;
			n=scan.nextInt();
		}
		if(count==0) {
			System.out.println("입력된 수가 없습니다. ");
		}
		else {
			System.out.println("입력된 갯수="+count);
			System.out.println("합계= " +sum + "평균 ="+sum/count);
		}
	}

}
