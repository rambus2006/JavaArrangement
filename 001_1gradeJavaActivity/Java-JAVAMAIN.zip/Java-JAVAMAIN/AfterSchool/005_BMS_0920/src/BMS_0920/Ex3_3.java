package BMS_0920;

public class Ex3_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//짝수의 합
		int sum=0;
		for(int i=1;i<=100;i++) {
			if(i%2==0) {
				sum+=i;
				i++;
			}
			
		}
		System.out.println("100까지의 짝수 정수의 합 : "+sum);
		
		sum=0;
		int i=1;
		while(i<=100) {
			if(i%2==0) {
				sum+=i;
				
			}
			i++;
		}
		System.out.println("100까지의 짝수 정수의 합 : "+sum);
		
		i=1;
		sum=0;
		do{
			if(i%2==0) {
				sum+=i;
			}
			i++;
			
		}while(i<=100);
		System.out.println("100까지의 짝수 정수의 합 : "+sum);
		
		//홀수 
		sum=0;
		for(i=1;i<=100;i++) {
			if(i%2!=0) {
				sum+=i;
				i++;
			}
			
		}
		System.out.println("100까지의 홀=수 정수의 합 : "+sum);
		
		sum=0;
		i=1;
		while(i<=100) {
			if(i%2!=0) {
				sum+=i;
				
			}
			i++;
		}
		System.out.println("100까지의 홀수 정수의 합 : "+sum);
		
		i=1;
		sum=0;
		do{
			if(i%2!=0) {
				sum+=i;
			}
			i++;
			
		}while(i<=100);
		System.out.println("100까지의 홀수 정수의 합 : "+sum);
		
	}

}
