package mirim1011;

import java.util.Scanner;
public class Test01 {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in) ;
			
		int sum =0;
		String names[]= {"국어","영어","수학","미술","체육"};
		int sc[]=new int[5];
		System.out.println("국어,영어,수학,미술, 체육점수를 입력하세요");
		for(int i=0;i<sc.length;i++) {
			
			sc[i]=scan.nextInt();
			sum+=sc[i];
			System.out.print(names+"=");
	
		}
		System.out.println("합계="+sum+"평균="+(double)sum/sc.length);
		
		
	}
}
