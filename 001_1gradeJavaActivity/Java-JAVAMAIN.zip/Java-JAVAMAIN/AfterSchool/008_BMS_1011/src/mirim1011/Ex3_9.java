package mirim1011;

public class Ex3_9 {
	public static void main(String []args) {
		int n[]= {1,2,3,4,5};
		String names[]= {"사과","배","딸기","바나나","포도"};
		double weights[]= {48.2,52.1,54.6,56.1,58,62.8,66.9};
		int sum=0;
		for(int num:n) {
			System.out.print(num+" ");
			sum +=num;
		}
		System.out.println("합계="+sum);
		for(String item:names ) {
			System.out.print(item+" ");
		}
		double hap=0.0;
		for(double person : weights) {
			hap+=person;
			System.out.println("몸무게 평균="+hap/weights.length);
		}
	}
}
