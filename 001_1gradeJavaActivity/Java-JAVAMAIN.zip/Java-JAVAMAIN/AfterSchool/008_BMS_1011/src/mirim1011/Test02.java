package mirim1011;
import java.util.Scanner;
public class Test02 {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
		String subject[]= {"국어,영어,수학,미술,체육"};
		int score[][]=new int[4][5];
		int sum[]=new int[4];
		System.out.println("국어,영어,수학,미술,체육점수를 입력하세요");
		Scanner scan=new Scanner(System.in);
		for(int i=0;i<score.length;i++) {
			for(int j=0;j<score[i].length;j++) {
				score[i][j]=scan.nextInt();
				sum[i]+=score[i][j];
				System.out.print(i+"번 학생"+subject[j]+score[i][j]+" ");
			} 
			System.out.println("합계="+sum[i]+"평균="+sum[i]/score[i].length);
		}
	}

}
