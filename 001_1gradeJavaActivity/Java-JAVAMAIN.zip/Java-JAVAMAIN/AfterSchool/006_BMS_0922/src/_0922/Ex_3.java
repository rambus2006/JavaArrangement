package _0922;

import java.util.Scanner;
public class Ex_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		int sum=0;
		int avg=0;
		System.out.print("갯수를 입력하시오 : ");
		int count=scan.nextInt();
		System.out.print("숫자를 입력하시오 : ");
		for(int i =0;i<=count;i++) {
			int []a=new int [count];
			a[i]=scan.nextInt();
		}
		//평균
		avg=sum/count;
		System.out.println("평균 :"+avg);
		//합계
		System.out.println("합계 : ");
	}

}
