package _0922;

import java.util.Scanner;
public class Ex_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		System.out.print("수를 입력하세요 : ");
		int num=scan.nextInt();
		int evensum=0;
		int oddsum=0;
		for(int i=1;i<=num;i++) {
			if(i%2==0) {
				evensum+=i;
			}
			else{
				oddsum+=i;
			}
		}
		System.out.println("1~"+num+"까지의 짝수의 합 : " + evensum);
		System.out.println("1~"+num+"까지의 홀수의 합 : " + oddsum);
	}

}
