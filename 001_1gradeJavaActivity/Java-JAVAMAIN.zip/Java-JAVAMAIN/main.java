public class main {
 	public static void main( String args[ ] ) {
		System.out .println(Float.SIZE);		//�Ǽ���//
		System.out .println(Short.SIZE);
}
}