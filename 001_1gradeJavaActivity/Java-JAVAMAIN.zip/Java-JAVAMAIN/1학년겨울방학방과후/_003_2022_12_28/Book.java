package _003_2022_12_28;
//생성자 선언 및 활용연습
public class Book {
	//1.변수(필드)
	private String title;
	private String author;
	
	//2.생성자
	public Book() {}
	public Book(String title) {
		this(title,"작자미상");
		//title=t; author="작자미상";
		
	}
	public Book(String title,String author) {
		this.title=title;
		this.author=author;
	}
	//메서드 
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	

}
