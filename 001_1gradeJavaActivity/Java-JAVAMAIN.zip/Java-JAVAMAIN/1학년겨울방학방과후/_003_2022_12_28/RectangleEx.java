package _003_2022_12_28;

import java.util.Scanner;
public class RectangleEx {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		Scanner scan=new Scanner(System.in);
		System.out.println("가로와 세로를 입력하세요");
		System.out.print(">>");
		
		int w=scan.nextInt();
		int h=scan.nextInt();
		Rectangle rect=new Rectangle(w,h); //객체 생성
		
		System.out.println("사각형의 면적은 "+rect.getArea());
		
		scan.close();
	}

}
