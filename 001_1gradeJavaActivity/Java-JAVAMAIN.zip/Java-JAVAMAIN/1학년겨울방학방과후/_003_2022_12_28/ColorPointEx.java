package _003_2022_12_28;

/*상속
 * super()
 * 자식 클래스에서 부모클래스의 생성자를 가져와서 사용할 수 있는 키워드
 */
public class ColorPointEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Point p1=new Point(2,3);
		p1.showPoint();
		
		ColorPoint cp1=new ColorPoint(3,4,"빨강");
		cp1.showColorPoint();
	}

}
