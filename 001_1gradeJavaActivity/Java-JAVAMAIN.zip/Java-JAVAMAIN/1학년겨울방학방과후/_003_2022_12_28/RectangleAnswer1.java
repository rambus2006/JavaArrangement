package _003_2022_12_28;

public class RectangleAnswer1 {
	//1.필드
	private int width;
	private int height;
	//2.생성자
	public RectangleAnswer1() {
	}
	public RectangleAnswer1(int width,int height) {
		this.width=width;
		this.height=height;
	}
	//3.메서드
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	

}
