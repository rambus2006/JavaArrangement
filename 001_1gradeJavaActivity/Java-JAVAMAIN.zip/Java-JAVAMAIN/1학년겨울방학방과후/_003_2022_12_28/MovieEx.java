package _003_2022_12_28;

import java.util.Scanner;
public class MovieEx {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		System.out.println("객체를 생성하시겠습니까?(NO=1/YES=2/프로그램종료=3):");
		int choose=sc.nextInt();

			if(choose==1) {
				Movie m1=new Movie("아바타",5,"제임스키메런");
				System.out.println(m1.print());
				
				Movie m2=new Movie("웬즈데이",4,"팀버튼");
				System.out.println(m2.print());
				
				Movie m3=new Movie("쥬라기공원",5,"스티븐 스필버그");
				System.out.println(m3.print());
				
			}else if(choose==2) {
				Movie m4=new Movie();
				System.out.print("영화제목을 입력하세요 : ");
				String name=sc.next();
				m4.setName(name);
				System.out.print("평점을 입력하세요 : ");
				int grade=sc.nextInt();
				m4.setGrade(grade);
				System.out.print("감독을 입력하세요:");
				String director=sc.next();
				m4.setDirector(director);
				System.out.println(m4.print());
			}
			else if(choose==3)  {
				System.out.println("종료합니다.");

			}
			else {
				System.out.println("수를 잘못입력하셨습니다");
			}
		
		
		
		
		
		
		
	}

}
