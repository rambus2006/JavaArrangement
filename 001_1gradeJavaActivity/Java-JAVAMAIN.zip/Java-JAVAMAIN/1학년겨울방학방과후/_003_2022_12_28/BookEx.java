package _003_2022_12_28;

public class BookEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Book loveStory=new Book("춘향전");
		Book liPrince=new Book("어린왕자","생텍쥐페리");
		System.out.println(liPrince.getTitle()+" "+liPrince.getAuthor());
		System.out.println(loveStory.getTitle()+" "+loveStory.getAuthor());
	}

}
