package _003_2022_12_28;

import java.util.Scanner;
public class DogEx {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog d1=new Dog("꽃님이","골든리트리버",4,"노란색");
		System.out.println(d1.getColor()+d1.getBreed()+"인 "+d1.getName()+"는"+d1.getAge()+"입니다.");
		System.out.println(d1.getName()+"는 "+d1.barking());
		//d1.barking();
		
		Dog d2=new Dog("햇님이","푸들",3,"검은색");
		System.out.println(d2.getColor()+d2.getBreed()+"인 "+d2.getName()+"는 "+d2.getAge());
		System.out.println(d2.getName()+"는 "+d2.hungry());
		
		
		Dog d3=new Dog("달님이","셰퍼드",2,"하얀색");
		System.out.println(d3.getColor()+d3.getBreed()+"인 "+d3.getName()+"는 "+d3.getAge());
		System.out.println(d3.getName()+"는 "+d3.sleeping());
		
		//---------------------------------Scanner로 입력---
		Scanner scan=new Scanner(System.in);
		
		System.out.println("강아지 객체를 생성하시겠습니까?(YES=1/No=2)");
		System.out.println(">>");
		int choose=scan.nextInt();
		if(choose==1) {
			System.out.print("이름을 입력해주세요:");
			String name=scan.next();
			System.out.print("종을 입력해주세요 : ");
			String breed=scan.next();
			System.out.print("나이를 입력해주세요 : ");
			int age=scan.nextInt();
			System.out.print("색을 입력해주세요 : ");
			String color=scan.next();
			System.out.print("행동을 입력해주세요(1번:멍멍짖는다.2번:배고파요.3번:자기) : ");
			int move=scan.nextInt();
			
			Dog d4=new Dog(name,breed,age,color);
			System.out.println(d4.getColor()+d4.getBreed()+"인"+d4.getName()+"는"+d4.getAge()+"살 입니다.");
			switch(move) {
				case 1:
					System.out.println(d4.getName()+"은"+d4.barking());
					break;
				case 2:
					System.out.println(d4.getName()+"은"+d4.hungry());
					break;
				case 3:
					System.out.println(d4.getName()+"은"+d4.sleeping());
					break;
			}	
		}else {
			System.out.println("시스템이 종료되었습니다.");
		}
		
		
	}

}
