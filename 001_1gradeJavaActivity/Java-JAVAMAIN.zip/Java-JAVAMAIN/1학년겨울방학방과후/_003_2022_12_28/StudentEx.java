package _003_2022_12_28;

import java.util.Scanner;
public class StudentEx {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan=new Scanner(System.in);
		System.out.println("이름,학번,나이,전화번호를 입력하세요");
		System.out.print(">>");
		String name=scan.next();
		String stud=scan.next();
		int age=scan.nextInt();
		String phone=scan.next();
		Student s1=new Student(name,stud,age,phone);
		
		System.out.print(s1.getName()+"/"+s1.getStud()+"/"+s1.getAge()+"/"+s1.getPhone());
	}

}
