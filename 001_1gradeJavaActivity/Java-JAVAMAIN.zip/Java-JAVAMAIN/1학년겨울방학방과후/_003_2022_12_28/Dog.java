package _003_2022_12_28;

public class Dog {
	//1.변수선언
	private String name;
	private String breed;
	private int age;
	private String color;
	
	//2.생성자
	public Dog(){}
	public Dog(String name,String breed,int age,String color) {
		this.name=name;
		this.breed=breed;
		this.age=age;
		this.color=color;
	}
	
	//getter setter메서드
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBreed() {
		return breed;
	}
	public void setBreed(String breed) {
		this.breed = breed;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	
	//행동메서드
	public String barking() {
		//void 로 바꿔서 sysout 밖으로 빼는 것도 괜찮지만,Stirng으로 해서 sysout 안에 넣는 것도 가능하다. 
		//System.out.println("멍멍짖는다.");
		return "멍멍짖는다.";
	}
	public String hungry() {
		//System.out.println("배고파요");
		return "배고파요";
	}
	public String sleeping() {
		//System.out.println("ZZzz...");
		return "ZZzz...";
	}
	
	
}
