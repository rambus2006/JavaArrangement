package _003_2022_12_28;

public class Movie {
	//1.변수선언
	private String name;
	private int grade;
	private String director;
	
	//2.생성자
	public Movie() {}
	public Movie(String name,int grade,String director) {
		this.name=name;
		this.grade=grade;
		this.director=director;
	}
	//3.메서드-getter,setter
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	public String getDirector() {
		return director;
	}
	public void setDirector(String director) {
		this.director = director;
	}
	
	//3.메서드
	public String print() {
		return ("영화제목:"+this.name+",평점:"+this.grade+",감독:"+this.director);
	}

}
