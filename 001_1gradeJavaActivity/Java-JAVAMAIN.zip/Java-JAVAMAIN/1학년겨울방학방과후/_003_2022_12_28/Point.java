package _003_2022_12_28;

//상속
//설계도
public class Point {
		//1.변수선언(필드)
		private int x;
		private int y;
		
		//protected int x;		//부모가 자식클래스에게만 변수를 공유함
		//protected int y;
		
		//2.생성자
		Point(){};
		Point(int x,int y){
			this.x=x;
			this.y=y;
			
		}
		//3.메서드
		public void showPoint() {
			System.out.println(x+","+y);
		}
		public int getX() {
			return x;
		}
		public void setX(int x) {
			this.x = x;
		}
		public int getY() {
			return y;
		}
		public void setY(int y) {
			this.y = y;
		}
		
	

}
