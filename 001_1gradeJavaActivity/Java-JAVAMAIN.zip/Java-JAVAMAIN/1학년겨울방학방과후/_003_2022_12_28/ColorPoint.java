package _003_2022_12_28;

public class ColorPoint extends Point{
	//1.필드
	private String color;
	//2.생성자
	ColorPoint(){};
	ColorPoint(int x,int y,String color){	//변수를 몇개 쓸 것인지 생각해보면 됨
		super(x,y);
		/*this.x=x;
		this.y=y;
		this.color=color;
		*/
	};
	//3.메서드 -getter,setter
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	
	public void showColorPoint() {
		System.out.println(super.getX()+","+super.getY()+","+color);
	}
}
