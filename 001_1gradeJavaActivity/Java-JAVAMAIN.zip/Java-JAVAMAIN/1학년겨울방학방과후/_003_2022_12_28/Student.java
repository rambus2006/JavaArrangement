package _003_2022_12_28;

public class Student {
	private String name;
	private String stud;
	private int age;
	private String phone;
	
	public Student() {}
	public Student(String name,String stud,int age,String phone) {
		this.name=name;
		this.stud=stud;
		this.age=age;
		this.phone=phone;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStud() {
		return stud;
	}
	public void setStud(String stud) {
		this.stud = stud;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
}
