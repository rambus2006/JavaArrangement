package _006_2023_01_02.TV;
import java.util.ArrayList;
/*
 * 일반적인 TV를 나타내는 TV클래스를 작성한다. TV에는 제조사,가격,크기등의 정보가 저장되어 있다. V
 * TV클래스를 상속받아서 SmartTV클래스를 작성하여 보자 V
 * SmartTV클래스에는 타입(LED,LCD,OLED등),인터넷 가능, 블루투스 가능 여부 등의 필드가 추가됩니다. V
 * 생성자,접근자, getter,setter를 포함하여서 각각의 클래스를 작성한다. V
 * interface는 TVInterface를 작성하여 보자 V
 * void changeChannel(); void internetPlay(); void internetStop(); V
 * SmartTV클래스는 TVInterface를 구현한다. SmartTV 객체를 2개를 만들고 각 객체의 모든 정보를 출력하는 테스트 클래스를 작성하라 
 * Menu 1: 스마트 TV입력=>scanner사용 
 * 		2: 조건 검색: 제조사 입력해 검색
 *  	3: 전체 조회
 *   	4: 종료
 */
import java.util.Scanner;

import _005_2022_12_30.StudentEx4_ArrayList.Ex04;
public class SmartTVEx {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		ArrayList<SmartTV> smtvList=new ArrayList<SmartTV>();	//ArrayList생성
		
		
		while(true) {
			System.out.println("메뉴를 입력하세요(1번-객체생성/2번-조건검색/3번-전체조회/4번-종료)");
			System.out.print(">>");
			int num=sc.nextInt();
				if(num==1) {
					System.out.print("기종이름을 입력하세요 : ");
					String name=sc.next();
					System.out.print("제조사를 입력하세요(삼성/LG/기타 중 택1) : ");
					String maker=sc.next();
					System.out.print("가격을 입력하세요 : ");
					int price=sc.nextInt();
					System.out.print("종류를 입력하세요(OLED,LED,LCD등) : ");
					String type=sc.next();
					System.out.print("인터넷사용여부를 입력하세요 : ");
					boolean internet=sc.nextBoolean();
					System.out.print("블루투스사용여부를 입력하세요 : ");
					boolean bluetooth=sc.nextBoolean();
					
					SmartTV smt1=new SmartTV(name,maker, price,type,internet,bluetooth);
					System.out.println("리스트에 TV가 등록되었습니다.");
					smtvList.add(smt1);	//ArrayList에 추가 
					
				}else if(num==2) {
					System.out.println("조건을 입력하세요(1번-기종이름/2번-제조사/3번-종류(OLED,LED/LCD))");
					System.out.println(">>");
					int choose=sc.nextInt();
					switch(choose) {
						case 1:
							System.out.print("기종이름를 입력하세요: ");
							String namesc=sc.next();
							for(SmartTV smt:smtvList) {
								if(smt.getName().equals(namesc)) {
									System.out.print(smt);
								}
							}
							break;
						case 2:
							System.out.print("제조사를 입력하세요(삼성/LG/기타) : ");
							String makersc=sc.next();
							for(SmartTV smt:smtvList) {
								if(smt.getMaker().equals(makersc)) {
									System.out.println(smt);
								}
							}
							break;
						case 3:
							System.out.print("smartTV종류를 입력하세요(OLED,LED,LCD): ");
							String typesc=sc.next();
							for(SmartTV smt:smtvList) {
								if(smt.getType().equals(typesc)) {
									System.out.print(smt);
								}
							}
							break;
					}
					
				}else if(num==3) {
					for(SmartTV smt:smtvList) {
							System.out.println(smt);
					}
				}else if(num==4) {
					System.out.println("프로그램을 종료합니다.");
					break;
				}else {
					System.out.println("잘못입력하셨습니다.");
				}
			}
				
		}
		
		
		
	
	}


