package _006_2023_01_02.TV;

/*
 * 일반적인 TV를 나타내는 TV클래스를 작성한다. TV에는 제조사,가격,크기등의 정보가 저장되어 있다. 
 * TV클래스를 상속받아서 SmartTV클래스를 작성하여 보자
 * SmartTV클래스에는 타입(LED,LCD,OLED등),인터넷 가능, 블루투스 가능 여부 등의 필드가 추가됩니다. 
 * 생성자,접근자, getter,setter를 포함하여서 각각의 클래스를 작성한다. 
 * interface는 TVInterface를 작성하여 보자 
 * void changeChannel(); void internetPlay(); void internetStop();
 * SmartTV클래스는 TVInterface를 구현한다. SmartTV 객체를 2개를 만들고 각 객체의 모든 정보를 출력하는 테스트 클래스를 작성하라
 * Menu 1: 스마트 TV입력=>scanner사용
 * 		2: 조건 검색: 제조사 입력해 검색
 *  	3: 전체 조회
 *   	4: 종료
 */
public class TV {
	//필드 생성
	private String name;
	private String maker;
	private int price;
	
	//생성자
	public TV() {}
	public TV(String name,String maker,int price) {
		this.name=name;
		this.maker=maker;
		this.price=price;
	}
	//getter,setter
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMaker() {
		return maker;
	}
	public void setMaker(String maker) {
		this.maker = maker;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	
	
}
