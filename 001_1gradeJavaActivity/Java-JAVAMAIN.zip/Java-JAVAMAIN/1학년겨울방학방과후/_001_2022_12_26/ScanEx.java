package _001_2022_12_26;

import java.util.Scanner;
public class ScanEx{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("이름,도시,나이,체중,독신여부를 빈칸으로 분리하여 입력하세요:");
		String name=sc.next();
		
		String city=sc.next();
		
		int age=sc.nextInt();

		double weight=sc.nextDouble();
		
		boolean single=sc.nextBoolean();
		
		System.out.println(name+city+age+weight+single+"입니다.");
		
	
		
	}

}