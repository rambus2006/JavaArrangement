package _001_2022_12_26;

import java.util.Scanner;
public class _003gradename {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		char grade;
		
		//이름 입력
		System.out.println("이름을 입력하세요:");
		String name=sc.next();
		System.out.println("점수를 입력하세요(0~100):");
		int score=sc.nextInt();
		if(score>=90) {
			grade='A';
		}
		else if(score>=80) {
			grade='B';
		}
		else if(score>=70) {
			grade='C';
		}
		else if(score>=60) {
			grade='D';
		}
		else {
			grade='F';
		}
		System.out.println(name+"의 성적은"+grade+"입니다.");
		
		sc.close();
		
	}

}
