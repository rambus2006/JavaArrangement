package _001_2022_12_26;

import java.util.Scanner;
public class _004gradingswich {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		//입력문
		System.out.println("이름을 입력하세요:");
		String name=sc.next();
		System.out.println("점수를 입력하세요:");
		String grade;
		int score=sc.nextInt();
		
		//switch case문
		switch(score/10) {
			case 10: 
			case 9:
				grade="A학점";
				break;
			case 8:
				grade="B학점";
				break;
			case 7:
				grade="C학점";
				break;
			case 6:
				grade="D학점";
				break;
			default:
				grade="F학점";
		}
		System.out.println(name+"의 점수는"+score+"점 이고,학점은 "+grade+"입니다.");
		sc.close();
	}

}
