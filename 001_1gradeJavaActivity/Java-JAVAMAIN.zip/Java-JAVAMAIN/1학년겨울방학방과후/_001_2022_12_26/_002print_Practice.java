package _001_2022_12_26;

import java.util.Scanner;
public class _002print_Practice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//입력
		Scanner scan=new Scanner(System.in);
		System.out.println("학번,이름,전공을 빈칸으로 분리하여 입력하세요:");
		String classof=scan.next();
		String name=scan.next();
		String major=scan.next();
		
		System.out.println(name+"의 학번은"+classof+"이고,전공은"+major+"입니다.");
		
	}

}
