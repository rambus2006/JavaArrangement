package _001_2022_12_26;

public class Hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//대문자로 시작하면 상수,클래스 
		//소문자로 시작하면 변수 
		
		/*
		 * 1. 필드(fields)소문자
		 * 2. 생성자(Constructors) 클래스 이름 동일 대문자
		 * 3. 메서드(methods) 소문자 ,() 가 있음
		 * 잘모르겠으면 for exam이나 네이버 찾아보기 
		 * 
		 * {자바데이터 타입}
		 * <기본>
		 * boolean - 1bit ,true,false
		 * char	-문자 1개만
		 * byte 
		 * short
		 * int -정수
		 * long
		 * float
		 * double-실수 
		 * <레퍼런스타입>
		 * 1개이며 용도는 3가지이다. 
		 * [용도]
		 * -배열에 대한 레퍼런스
		 * -클래스에 대한 레퍼런스
		 * -인터페이스에 대한 레퍼런스 
		 */
		System.out.println("안녕하세요");
		System.out.println("1409방민서");
		System.out.println("내 자바 인생이 점점 꼬여가고 있다...조졌어...쓰벌...");
		System.out.println("모르는 거 다물어보고, 사이드 프로젝트나 완성해 보자 ");
		String sign="2022년 12월 26일 ";
		System.out.println("이게 맞나"+sign);
		
		
	}

}
