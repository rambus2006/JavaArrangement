package _001_2022_12_26;

public class print_Practice2 {

}
