package _001_2022_12_26;

import java.util.Scanner;
public class _006Ex6 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		// TODO Auto-generated method stub
		System.out.println("이름,키,몸무게를 빈칸으로 분리하여 입력하시오 : ");
		
		//변수 선언
		String name=sc.next();
		double height=sc.nextDouble();
		double weight=sc.nextDouble();
		
		double BMI=(weight/(height*height));
		String BMIprint;
		
		//if 문
		if(BMI>=30) {
			BMIprint="고도비만";
		}
		else if(BMI>=25) {
			BMIprint="비만";
		}
		else if(BMI>=23.98) {
			BMIprint="과체중";
		}
		else if(BMI>=17.96) {
			BMIprint="정상";
		}
		else {
			BMIprint="저체중";
		}
		System.out.println(name+"은 키"+height+"cm,몸무게"+weight+"kg BMI지수"+BMI+"으로"+BMIprint+"입니다.");
	}

}
