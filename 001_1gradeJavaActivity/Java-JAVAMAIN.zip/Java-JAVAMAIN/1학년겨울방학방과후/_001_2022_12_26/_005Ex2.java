package _001_2022_12_26;

import java.util.Scanner;
public class _005Ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		//if문
		System.out.println("월을 입력하세요 : ");
		int month=sc.nextInt();
		
		String weather;
		
		if(month>11) {
			weather="겨울";
		}
		else if(month>8) {
			weather="가을";
		}
		else if(month>5) {
			weather="여름";
		}
		else if(month>2) {
			weather="봄";
		}
		else{
			weather="겨울";
		}
		System.out.println(month+"월은"+weather+"입니다.(if문)");
		
		//case문
		switch(month) {
			case 1: case 2: case 12:
				weather="겨울";
				break;
			case 11: case10: case9:
				weather="가을";
				break;
			case 8: case 7: case 6:
				weather="여름";
				break;
			case 3: case 4: case5:
				weather="봄";
				break;
				
			default:
				break;
		}
		System.out.println(month+"월은"+weather+"입니다.(case문)");
		
		
		
		
		
		
		
	}

}
