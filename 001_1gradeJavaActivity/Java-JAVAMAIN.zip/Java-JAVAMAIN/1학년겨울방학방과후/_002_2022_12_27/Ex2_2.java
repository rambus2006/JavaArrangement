package _002_2022_12_27;

public class Ex2_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		for(int i=0;i<=500;i+=5) {
				sum=i+500;
				System.out.print(i);
				if(i<=499) //1~500까지는 + 출력
					System.out.print("+");
				else {//i가 10 인 경우 
					System.out.print("=");	//= 출력하고 
					System.out.print(sum);	//덧셈결과 출력 
				}
		}
	}

}
