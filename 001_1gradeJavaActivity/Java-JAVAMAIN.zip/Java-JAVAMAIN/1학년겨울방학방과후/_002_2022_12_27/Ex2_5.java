package _002_2022_12_27;

import java.util.Scanner;
public class Ex2_5 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("exit 또는 \"그만\"을 입력하면 종료합니다. ");
		while(true) {		//while문 무한 반복문
			System.out.print(">>");
			String text=sc.nextLine();			//String 입력(nextLine)
			//else if 써도 됨
			if(text.equals("exit")||text.equals("그만"))		//"exit"이나 "그만"이 입력되면 반복 종료
				break;	//while문을 벗어남
		}
		System.out.println("종료합니다.");
	}

}
