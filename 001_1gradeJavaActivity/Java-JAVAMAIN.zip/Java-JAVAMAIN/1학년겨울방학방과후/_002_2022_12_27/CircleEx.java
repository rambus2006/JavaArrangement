package _002_2022_12_27;

public class CircleEx {
	public static void main(String[] args) {
			Circle pizza=new Circle();		//변수와 똑같은 개념이지만 객체를 생성한다. 
			pizza.setName("불고기 피자");
			//pizza.name="불고기피자" -getter,setter없을 때 (private없을 때)
			pizza.setRadius(10);
			//pizza.radius=10;	-getter,setter없을 때(private없을 때)
			double area=pizza.getArea()	;			//괄호가 있으니 메서드,double 값으로 가져온다. 
			System.out.println(pizza.getName()+"의"+pizza.getRadius()+"반지름,면적은"+area+"입니다.");
			
			//객체2
			Circle donut=new Circle();	//뒤의 Circle은 생성자
			donut.setName("초콜릿도넛");
			//donut.name="초콜릿도넛";
			donut.setRadius(2);
			//donut.radius=2;
			area=donut.getArea();
			System.out.println(donut.getName()+"의"+donut.getRadius()+"반지름,면적은"+donut.getArea()+"입니다.");
			//System.out.println(donut.name+"의"+donut.radius+"반지름,면적은"+area+"입니다.");

			/*
			 * Circle pizza;		//변수 pizza생성,안에는 null값이 있음
			 * pizza=new Circle();	//pizza 에 Circle(name,radius) 넣어서 new로 객체 생성
			 * 
			 */
			/*
			//객체3 생성
			Circle soccerball=new Circle();	//1번 생성자 사용
			soccerball.name="축구공";
			soccerball.radius=8;
			area=soccerball.getArea();
			System.out.println(soccerball.name+"의"+soccerball.radius+"반지름,면적은"+area+"입니다.");
			
			//객체4 생성
			Circle baseball=new Circle(4,"야구공");	//2번 생성자 사용
			System.out.println(baseball.name+"의"+baseball.radius+"반지름,면적은"+baseball.getArea()+"입니다.");
			
			//객체 5 생성
			Circle mirror=new Circle(3,"손거울");
			System.out.println(mirror.name+"의"+mirror.radius+"반지름,면적"+mirror.getArea()+"입니다.");
			//-------------------이렇게 하면 캡슐화가 되지 않음-----------------------------------------------------
			*/
	}
}
