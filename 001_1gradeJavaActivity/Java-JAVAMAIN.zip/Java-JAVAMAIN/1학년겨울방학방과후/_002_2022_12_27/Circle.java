package _002_2022_12_27;

public class Circle {
		//1필드
		private int radius;
		private String name;
		
		//2.생성자 
		//1번 생성자
		public Circle() {
		}
		//2번생성자
		Circle(int radius2,String name2){
			this.radius=radius2;		//이름을 보통 같게 설정하는데 이를 구분하기 위해 this.를 붙인다. 
			this.name=name2;
		}
		//3.메서드
		public int getRadius() {
			return radius;
		}
		public void setRadius(int radius) {
			this.radius=radius;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name=name;
		}
		public double getArea() {
			return 3.14*radius*radius;
		}
}
