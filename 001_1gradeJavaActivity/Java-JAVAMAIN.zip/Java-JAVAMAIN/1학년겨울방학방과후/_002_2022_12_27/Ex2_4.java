package _002_2022_12_27;

public class Ex2_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=2;i<12;i++) {	//2단에서 11단
			for(int j=1;j<10;j++) {		//각 단의 구구셈 출력
				System.out.print(i+"*"+j+"="+i*j);	//구구셈출력
				System.out.println("\t");			//하나씩 탭으로 띄기
			}
			System.out.println();		//한 단이 끝나면 다음줄로 커서 이동
		}
	}

}
