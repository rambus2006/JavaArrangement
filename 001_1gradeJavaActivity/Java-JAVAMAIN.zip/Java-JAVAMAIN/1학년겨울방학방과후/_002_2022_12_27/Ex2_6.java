package _002_2022_12_27;
//양수 5개를 입력받아 가장 큰 수를 구하고, 합계와 평균을 구하는 코드
import java.util.Scanner;
public class Ex2_6 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in) ;
			int intArray[]=new int[5];	//배열생성
			int max=0;//현재 가장 큰 수 
			int sum=0;
			double average=0;
			System.out.println("양수 5개를 입력하세요");
			
			//가장 큰 수를 찾아내기
			for(int i=0;i<5;i++) {
				intArray[i]=sc.nextInt();//입력받은 상수를 배열에 저장
				
				if(intArray[i]>max);	//intArray[i]가 현재 가장 큰 수 보다 크면 
					max=intArray[i];	//intArray[i]를 max로 변경
				sum=sum+intArray[i];	
			}
			System.out.println("가장 큰 수는 "+max+"입니다.");
			average=(double)(sum/5);
			
			sc.close();
			for(int i=0;i<5;i++) {
				System.out.println("입력한 수는 "+intArray[i]+"입니다.");
			}
			System.out.println("입력한 수의 평균은"+average+"이고,");
			System.out.println("입력한 수의 합계는"+sum+"입니다.");
				
			
	}

}
