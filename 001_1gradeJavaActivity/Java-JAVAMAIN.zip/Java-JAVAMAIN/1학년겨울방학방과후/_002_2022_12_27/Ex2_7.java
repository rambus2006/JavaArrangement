package _002_2022_12_27;
//for-each문
/* 
 * 괄호가 없으면 필드
 * 괄호가 있으면 메서드 
 * [for-each문]
 * 배열이나 나열(enumeration)의 각 원소를 순차적으로 접근하는데 유용한 for문
 * 형식 : for(변수타입(변수):(배열이나 나열))
 * 예제 1
 * int[]num={1,2,3,4,5};
 * int sum=0;
 * for(int k:num)
 * 		sum+=k;
 * System.out.print("합은"+sum);
 * 값은 15
 */
public class Ex2_7 {
	public static void main(String[] args) {
		int[]num= {1,2,3,4,5};
		String names[]= {"사과","배","바나나","체리","딸기","포도"};
		
		int sum=0;
		//아래 for-each 문에서는 k는 num[0],num[1]...num[4]로 반복
		for(int k:num) {
			System.out.print(k+" ");	//반복되는 k값 출력
			sum+=k;		
		}
		System.out.printf("\n합은"+sum+"\n");
		
		//아래 for-each 에서는 s는 names[0],names[1]...,names[5]로 반복
		for(String s:names)
			System.out.printf(s+" ");
		System.out.println();
	}

}
