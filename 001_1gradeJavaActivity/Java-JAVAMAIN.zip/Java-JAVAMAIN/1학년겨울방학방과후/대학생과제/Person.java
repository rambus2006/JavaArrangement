package _006_2023_01_02.대학생과제;

public class Person{
	//필드 이름,이메일,전공 
	 private String name;
	 private String email;
	 
	 //생성자
	 public Person() {}
	 public Person(String name,String email) {
		 this.name=name;
		 this.email=email;
	 }
	 //getter
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", email=" + email + "]";
	}
	
}
