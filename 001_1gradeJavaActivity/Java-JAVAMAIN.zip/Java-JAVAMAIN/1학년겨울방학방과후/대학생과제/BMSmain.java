package _006_2023_01_02.대학생과제;

import java.util.ArrayList;
import java.util.Scanner;

import _006_2023_01_02.Phone.SmartPhone;
public class BMSmain extends Student {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		// TODO Auto-generated method stub
		//본인 이름, 이메일, 학번, 전공, 국어점수,체육점수
		//만들어야 하는 것 :  학과별 학생 명단, 과목별 학생 명단
		//ArrayList<SmartPhone> smList=new ArrayList<SmartPhone>();
		
		ArrayList<Student> stList=new ArrayList<Student>();
		while(true) {
			System.out.println("메뉴를 입력하세요(1번-학생정보입력/2번-학과별학생명단/3번-과목별학생명단)");
			System.out.print(">>");
			int num=sc.nextInt();
			
			if(num==1) {
				System.out.print("이름을 입력하세요 : ");
				String name=sc.next();
				System.out.print("이메일을 입력하세요 : ");
				String email=sc.next();
				System.out.print("학번을 입력하세요 : ");
				String stuid=sc.next();
				System.out.print("학과를 입력하세요 : ");
				int majorcode=sc.nextInt();
				System.out.print("국어 점수를 입력하세요 : ");
				int korscore=sc.nextInt();
				Student.setKorscore(korscore);
				System.out.print("체육 점수를 입력하세요 : ");
				int pescore =sc.nextInt();
				Student.setPescore(pescore);
				
				
				stList.add(new Student(name,email,stuid,majorcode,korscore,pescore));
				
			}
			if(num==2) {
				System.out.println("=====학과별 학생 명단=====");
				System.out.println("|이름|국어|등급|체육|등급");
				for(int i=0;i<stList.size();i++) {
					if(stList.get(i).getMajorcode()==Define.sw) {
						System.out.println("-----소프트웨어과-----");
						System.out.println(stList.get(i).getName()+"|"+stList.get(i).getKorscore()+"|"+stList.get(i).getGrade(i)+"|"+stList.get(i).getPescore()+"|"+stList.get(i).getPEGrade(i));
					}
					if(stList.get(i).getMajorcode()==Define.web) {
						System.out.println("-----웹솔루션과-----");
						System.out.println(stList.get(i).getName()+"|"+stList.get(i).getKorscore()+"|"+stList.get(i).getGrade(i)+"|"+stList.get(i).getPescore()+"|"+stList.get(i).getPEGrade(i));
					}
					if(stList.get(i).getMajorcode()==Define.design) {
						System.out.println("-----디자인과-----");
						System.out.println(stList.get(i).getName()+"|"+stList.get(i).getKorscore()+"|"+stList.get(i).getGrade(i)+"|"+stList.get(i).getPescore()+"|"+stList.get(i).getPEGrade(i));
					}
						
				}
					
			}
			if(num==3) {
				System.out.println("=====과목별 학생 명단=====");
				System.out.println("|이름|국어|등급");
				System.out.println("-----국어 과목 성적-----");
				for(int i=0;i<stList.size();i++) {
					if(Define.sw==stList.get(i).getMajorcode()) {
						String swprint="소프트웨어과";
						System.out.println(stList.get(i).getName()+"|"+stList.get(i).getKorscore()+"|"+stList.get(i).getGrade(i)+"|"+swprint);	
					}
					if(Define.web==stList.get(i).getMajorcode()) {
						String webprint="웹솔루션과";
						System.out.println(stList.get(i).getName()+"|"+stList.get(i).getKorscore()+"|"+stList.get(i).getGrade(i)+"|"+webprint);	
					}
					if(Define.design==stList.get(i).getMajorcode()) {
						String designprint="디자인과";
						System.out.println(stList.get(i).getName()+"|"+stList.get(i).getKorscore()+"|"+stList.get(i).getGrade(i)+"|"+designprint);	
					}
				}
				System.out.println("-----체육 과목 성적-----");
				for(int i=0;i<stList.size();i++) {
					if(Define.sw==stList.get(i).getMajorcode()) {
						String swprint2="소프트웨어과";
						System.out.println(stList.get(i).getName()+"|"+stList.get(i).getPescore()+"|"+stList.get(i).getPEGrade(i)+"|"+swprint2);	
					}else if(Define.web==stList.get(i).getMajorcode()) {
						String webprint2="소프트웨어과";
						System.out.println(stList.get(i).getName()+"|"+stList.get(i).getPescore()+"|"+stList.get(i).getPEGrade(i)+"|"+webprint2);	
					}else if(Define.design==stList.get(i).getMajorcode()) {
						String designprint2="소프트웨어과";
						System.out.println(stList.get(i).getName()+"|"+stList.get(i).getPescore()+"|"+stList.get(i).getPEGrade(i)+"|"+designprint2);	
					}
				}
			}
				
		}
		
			
			
	}	
}


