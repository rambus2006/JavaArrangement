package _006_2023_01_02.대학생과제;

public class Student extends Person implements GradeVal{
	//1.학번 , 학과코드 , 국어점수, 체육점수 필드
	private String stuid;	//학번
	private int majorcode;	//학과 코드
	private int korscore;	//국어점수
	private int pescore;	//체육점수
	
	//생성자
	public Student(){}
	public Student(String name,String email,String stuid,int majorcode,int korscore,int pescore) {
		super(name,email);
		this.stuid=stuid;
		this.korscore=korscore;
		this.pescore=pescore;
		this.majorcode=majorcode;
	}
	
	
	
	
	//메소드
	@Override
	public String getGrade(int kor) {
		if(korscore>=90) {
			return "A";
		}else if(korscore>=80) {
			return"B";
		}else if(korscore>=70) {
			return "C";
		}else if(korscore>=60) {
			return "D";
		}else {
			return "F";
		}
			
	}
	@Override
	public String getPEGrade(int pe) {
		if(pescore>=60) {
			return "P";
		}else {
			return "F";
		}
	}
	//gettter,setter
	public String getStuid() {
		return stuid;
	}
	public void setStuid(String stuid) {
		this.stuid = stuid;
	}
	public int getMajorcode() {
		return majorcode;
	}
	public void setMajorcode(int majorcode) {
		this.majorcode = majorcode;
	}
	public int getKorscore() {
		return korscore;
	}
	public static void setKorscore(int korscore) {
		korscore = korscore;
	}
	public int getPescore() {
		return pescore;
	}
	public static void setPescore(int pescore) {
		pescore = pescore;
	}
	@Override
	public String toString() {
		return "Student ["+"name="+getName()+ "email="+getEmail()+"stuid=" + stuid + ", majorcode=" + majorcode + ", korscore=" + korscore + ", pescore="
				+ pescore + "]";
	}
	
	
	
	
	
}
