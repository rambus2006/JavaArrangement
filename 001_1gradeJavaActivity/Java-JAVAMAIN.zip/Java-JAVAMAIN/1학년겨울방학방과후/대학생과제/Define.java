package _006_2023_01_02.대학생과제;
//상수정의
public class Define {
	public final static int sw=100;
	public final static int web=200;
	public final static int design=300;
}

