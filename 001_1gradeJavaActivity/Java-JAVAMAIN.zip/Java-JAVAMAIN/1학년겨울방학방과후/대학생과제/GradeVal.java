package _006_2023_01_02.대학생과제;

public interface GradeVal {
	String getGrade(int kor);		//국어 성적의 등급을 구하는 메서드 (A,B,C,D...)
	String getPEGrade(int pe);	//체육 성적을 구하는 메서드(true,false)
}
