package _008_2023_01_04.주소록검색;

public interface AddrInterface {
	public abstract void addrscan() ;
	public abstract void addrsearch();
	public abstract void addrOverallCheck();
	public abstract void addrmodify();
	public abstract void addrdelete();

}
