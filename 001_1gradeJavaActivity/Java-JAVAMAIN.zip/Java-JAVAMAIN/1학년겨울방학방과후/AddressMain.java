package _008_2023_01_04.주소록다시;

import java.util.Scanner;

import _008_2023_01_04.주소록검색.Addr;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class AddressMain {
	static List<Addr> addrList=new ArrayList<>();	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		while(true) {
			System.out.println("--------------------");
			System.out.println("1.주소록 입력 ");
			System.out.println("2.주소록 검색 ");
			System.out.println("3.주소록 조회 ");
			System.out.println("4.주소록 수정 ");
			System.out.println("5.주소록 삭제 ");
			System.out.println("0.종료");
			System.out.println("--------------------");
			
			System.out.println("메뉴를 입력하세요");
			System.out.println(">>");
			int num=sc.nextInt();
			if(num==1) {
				addscan();
			}
			else if(num==2) {
				addrsearch();
			}
			else if(num==3) {
					addrOverallCheck();
			}
			else if(num==4) {
					addrmodify();
			}
			else if(num==5) {
					addrdelete();
			}
			else if(num==0) {
					System.out.println("시스템을 종료합니다.");
					break;	
			}else {
				System.out.println("잘못입력하셨습니다.");
			}
			
		}
	}//main끝
	protected static void addscan() {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("-1.주소록 입력----------");
		System.out.print("이름을 입력하세요 : ");
		String name=sc.next();
		System.out.print("전화번호를 입력하세요 : ");
		String phone=sc.next();
		System.out.print("회사를 입력하세요 : ");
		String company=sc.next();
		LocalDateTime date=LocalDateTime.now();	//날짜 입력
		System.out.println("입력되었습니다.");
		
		addrList.add(new Addr(name,phone,company,date));
	}
	protected static void addrsearch() {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("-2.주소록 검색----------");
		System.out.print("이름을 입력하세요 : ");
		String name=sc.next();
		for(int i= 0;i<addrList.size();i++) {
			if(addrList.get(i).getName().equals(name)) {
				//정보 출력
				System.out.println(addrList.get(i).getName()+" "+addrList.get(i).getPhone()+" "+addrList.get(i).getCompany()+" "+addrList.get(i).getDate());
			}
		}
	}
	//3. 주소록 조회
	protected static void addrOverallCheck() {
			for(int i= 0;i<addrList.size();i++) {
					//전체 정보 출력
					System.out.println(addrList.get(i).toString());
				}
	}
	//4. 주소록 수정
	protected static void addrmodify() {
			Scanner sc=new Scanner(System.in);
			System.out.println("-4.주소록 수정---------------");
			System.out.print("수정할 사람을 검색하세요 : ");
			String namemodify=sc.next();
			//이름 검색
			for(int i= 0;i<addrList.size();i++) {
				if(addrList.get(i).getName().equals(namemodify)) {
					//정보 출력
					System.out.println(addrList.get(i).toString());
					//정보 수정하기 
					System.out.println("-------정보수정하기--------");
					System.out.print("이름을 입력하세요 : ");
					String newname=sc.next();
					System.out.print("전화번호를 입력하세요 : ");
					String newphone=sc.next();
					System.out.print("회사를 입력하세요 : ");
					String newcompany=sc.next();
					LocalDateTime date=LocalDateTime.now();	//날짜 입력
					
					//리스트에서 수정
					addrList.get(i).setName(newname);
					addrList.get(i).setPhone(newphone);
					addrList.get(i).setCompany(newcompany);
					addrList.get(i).setDate(date);
				}
			}
		}
		//5. 주소록 삭제 
		protected static void addrdelete() {
				Scanner sc=new Scanner(System.in);
			System.out.print("삭제할 사람을 입력하세요 : ");
			String namedelete=sc.next();
			//이름 검색
			System.out.print("정말삭제하시겠습니까>(y/n) : ");
			String yn=sc.next();
			if(!yn.equalsIgnoreCase("y")){
				System.out.println("삭제를 취소합니다.");
		
			}
			int i=0;
			for(i= 0;i<addrList.size();i++) {
				if(addrList.get(i).getName().equals(namedelete)) {
					//정보 출력
					System.out.println(addrList.get(i).toString());
					addrList.remove(i);
					System.out.println("삭제되었습니다.");
				}
			}
			
			
	}
}