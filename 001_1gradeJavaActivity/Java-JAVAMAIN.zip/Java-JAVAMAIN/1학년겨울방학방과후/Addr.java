package _008_2023_01_04.주소록검색;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Addr {
	//필드
	private String name;
	private String phone;
	private String company;
	private LocalDateTime date;
	
	static List<Addr> addrList=new ArrayList<>();		//리스트 생성
	
	//생성자 
	public Addr() {}
	public Addr(String name,String phone,String company,LocalDateTime date) {
		this.name=name;
		this.phone=phone;
		this.company=company;
		this.date=date;
	}
	
	//getter,setter
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime date) {
		this.date = date;
	}
	
	@Override
	public String toString() {
		return "주소록 [이름 : " + name + ", 전화번호 : " + phone + ", 회사 : " + company + ",날짜와 시간 : " + date + "]";
	}
	
	//1.주소록 입력
	protected static void addrscan()  {
			Scanner sc=new Scanner(System.in);
			
			System.out.println("-1.주소록 입력----------");
			System.out.print("이름을 입력하세요 : ");
			String name=sc.next();
			System.out.print("전화번호를 입력하세요 : ");
			String phone=sc.next();
			System.out.print("회사를 입력하세요 : ");
			String company=sc.next();
			LocalDateTime date=LocalDateTime.now();	//날짜 입력
			System.out.println("입력되었습니다.");
			
			addrList.add(new Addr(name,phone,company,date));
			
	}//addrscan끝
	//2. 주소록 검색
	protected static void addrsearch() {
			Scanner sc=new Scanner(System.in);
			
			System.out.println("-2.주소록 검색----------");
			System.out.print("이름을 입력하세요 : ");
			String name=sc.next();
			for(int i= 0;i<addrList.size();i++) {
				if(addrList.get(i).getName().equals(name)) {
					//정보 출력
					System.out.println(addrList.get(i).getName()+" "+addrList.get(i).getPhone()+" "+addrList.get(i).getCompany()+" "+addrList.get(i).getDate());
				}
			}
	}
	//3. 주소록 조회
	protected static void addrOverallCheck() {
		for(int i= 0;i<addrList.size();i++) {
				//전체 정보 출력
				System.out.println(addrList.get(i).toString());
			}
	}
	//4. 주소록 수정
	protected static void addrmodify() {
		Scanner sc=new Scanner(System.in);
		System.out.println("-4.주소록 수정---------------");
		System.out.print("수정할 사람을 검색하세요 : ");
		String namemodify=sc.next();
		//이름 검색
		for(int i= 0;i<addrList.size();i++) {
			if(addrList.get(i).getName().equals(namemodify)) {
				//정보 출력
				System.out.println(addrList.get(i).toString());
				//정보 수정하기 
				System.out.println("-------정보수정하기--------");
				System.out.print("이름을 입력하세요 : ");
				String newname=sc.next();
				System.out.print("전화번호를 입력하세요 : ");
				String newphone=sc.next();
				System.out.print("회사를 입력하세요 : ");
				String newcompany=sc.next();
				LocalDateTime date=LocalDateTime.now();	//날짜 입력
				
				//리스트에서 수정
				addrList.get(i).setName(newname);
				addrList.get(i).setPhone(newphone);
				addrList.get(i).setCompany(newcompany);
				addrList.get(i).setDate(date);
			}
		}
		//정보수정
		
	}
	//5. 주소록 삭제 
	protected static void addrdelete() {
		Scanner sc=new Scanner(System.in);
		System.out.print("삭제할 사람을 입력하세요 : ");
		String namedelete=sc.next();
		//이름 검색
		System.out.print("정말삭제하시겠습니까>(y/n) : ");
		String yn=sc.next();
		if(!yn.equalsIgnoreCase("y")){
			System.out.println("삭제를 취소합니다.");
	
		}
		int i=0;
		for(i= 0;i<addrList.size();i++) {
			if(addrList.get(i).getName().equals(namedelete)) {
				//정보 출력
				System.out.println(addrList.get(i).toString());
				addrList.remove(i);
				System.out.println("삭제되었습니다.");
			}
		}
		
		
	}
	
	

}//class Addr끝
