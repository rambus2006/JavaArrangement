package _008_2023_01_04.주소록검색;

import java.util.Scanner;

import _007_2023_01_03.성적조회.MemberLogin;

import java.util.List;
import java.util.ArrayList;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class AddrMain extends Addr {


	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		//루프
		while(true) {
			System.out.println("--------------------");
			System.out.println("1. 주소록 입력");
			System.out.println("2. 주소록 검색");
			System.out.println("3. 주소록 조회");
			System.out.println("4. 주소록 수정");
			System.out.println("5. 주소록 삭제");
			System.out.println("0. 종료");
			System.out.println("--------------------");
			System.out.print("메뉴를 입력하세요 : ");
			int num=sc.nextInt();
			if(num==1) {
					addrscan();
			} 
			else if(num==2) {
					addrsearch();
			}
			else if(num==3) {
					addrOverallCheck();
			}
			else if(num==4) {
					addrmodify();
			}
			else if(num==5) {
					addrdelete();
			}
			else if(num==0) {
					System.out.println("시스템을 종료합니다.");
					break;	
			}
			else {
				System.out.println("잘못된 입력입니다. 다시입력하세요.");
			}		
		}
	}//main끝
	
	
}//class 끝

