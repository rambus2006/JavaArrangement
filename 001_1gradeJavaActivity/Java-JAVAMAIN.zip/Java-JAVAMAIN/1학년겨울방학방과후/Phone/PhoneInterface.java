package _006_2023_01_02.Phone;

public interface PhoneInterface {
	//void 앞에 public abstract가 자동으로 붙는다. (JVM이 붙여준다. )
	//추상메서드는 이것을 상속받는 곳에서 자식클래스를 구현해주어야 한다.
	void sendCall();
	void receiveCall();
	void sendSMS();
	void mp3play();
	void mp3Stop();
}
