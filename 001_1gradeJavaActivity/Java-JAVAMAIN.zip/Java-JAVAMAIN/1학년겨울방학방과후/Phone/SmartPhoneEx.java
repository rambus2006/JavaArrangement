package _006_2023_01_02.Phone;

import java.util.ArrayList;

import _005_2022_12_30.StudentArrayList.Student;

public class SmartPhoneEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SmartPhone sp1=new SmartPhone("갤럭시s24","삼성",100000000,"안드로이드",256,true);
		SmartPhone sp2=new SmartPhone("갤럭시s22","삼성",700000,"안드로이드",256,true);
		SmartPhone sp3=new SmartPhone("레드미노트11프로","샤오미",25000000,"안드로이드",128,true);
		SmartPhone sp4=new SmartPhone("아이폰14프로","애플",16000000,"IOS",128,true);
		SmartPhone sp5=new SmartPhone("아이폰13","애플",12500000,"IOS",128,true);
		
		ArrayList<SmartPhone> smList=new ArrayList<SmartPhone>();
		smList.add(sp1);
		smList.add(sp2);
		smList.add(sp3);
		smList.add(sp4);
		smList.add(sp5);
		smList.add(new SmartPhone("갤럭시s20","삼성",50000,"안드로이드",128,true));
		//전체 스마트폰 출력
		for(SmartPhone smPhone:smList) {
			System.out.println(smPhone);
		}
		System.out.println("=========================================================");
		
		//안드로이드 폰만 출력하시오(방법1)
		for(int i=0;i<smList.size();i++) {
			if(smList.get(i).getOs().equals("안드로이드")) {
				System.out.println(smList.get(i));
			}
		}
		System.out.println("--------------------------------------------------------------");
		//안드로이드 폰만 출력하시오(방법2)
		for(SmartPhone smPhone:smList) {
			if(smPhone.getOs().equals("안드로이드")) {
				System.out.println(smPhone);
			}
		}
		
		System.out.println("=============================================================");
		//삼성폰만 출력하시오(방법1)
		for(int i=0;i<smList.size();i++) {
			if(smList.get(i).getMaker().equals("삼성")) {
				System.out.println(smList.get(i));
			}
		}
		System.out.println("-------------------------------------------------------------");
		//삼성폰만 출력하시오(방법2)
		for(SmartPhone smPhone:smList) {
			if(smPhone.getMaker().equals("삼성")) {
				System.out.println(smPhone);
			}
		}
		
		System.out.println("=========================================");
		//가격이 100만원에서 150만원 사이의 스마트폰의 제품명 가격을 출력하시오
		for(int i=0;i<smList.size();i++) {
			if(smList.get(i).getPrice()>=1000000&&smList.get(i).getPrice()<=1500000) {
				System.out.println(smList.get(i).getName()+","+smList.get(i).getPrice());
			}
		}
	}

}
