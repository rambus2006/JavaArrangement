package _006_2023_01_02.Phone;

public class SmartPhone extends Phone implements PhoneInterface{
	//1.필드
	private String os;
	private int memory;
	private boolean bluetooth;
	
	//속아파...
	public SmartPhone(){};//기본 생성자 
	public SmartPhone(String name, String maker,int price, String os,int memory,boolean bluetooth) {
		super(name,maker,price);
		this.os=os;
		this.memory=memory;
		this.bluetooth =bluetooth;
		
		
	}
	public String getOs() {
		return os;
	}
	public void setOs(String os) {
		this.os = os;
	}
	public int getMemory() {
		return memory;
	}
	public void setMemory(int memory) {
		this.memory = memory;
	}
	public boolean isBluetooth() {
		return bluetooth;
	}
	public void setBluetooth(boolean bluetooth) {
		this.bluetooth = bluetooth;
	}
	
	//메서드 구현
	@Override
	public void sendCall() {
		// TODO Auto-generated method stub
		System.out.println("전화를 겁니다.");
		
	}
	@Override
	public void receiveCall() {
		// TODO Auto-generated method stub
		System.out.println("전화를 받습니다.");
		
	}
	@Override
	public void sendSMS() {
		// TODO Auto-generated method stub
		System.out.println("메세지를 보냅니다.");
		
	}
	@Override
	public void mp3play() {
		// TODO Auto-generated method stub
		System.out.println("음악을 시작합니다.");
		
	}
	@Override
	public void mp3Stop() {
		// TODO Auto-generated method stub
		System.out.println("음악을 정지합니다.");
	}
	@Override
	public String toString() {
		return "SmartPhone [os=" + os + ", memory=" + memory + ", bluetooth=" + bluetooth + ", 제품명=" + getName()
				+ ", 제작사=" + getMaker() + ", 가격=" + getPrice() + "]";
	}
	
	
	
}
