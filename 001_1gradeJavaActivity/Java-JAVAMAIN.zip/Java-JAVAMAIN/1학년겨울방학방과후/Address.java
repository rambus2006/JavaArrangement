package _008_2023_01_04.주소록다시;

public class Address {
	private String name;
	private String phone;
	private String email;
	private String company;
	
	public Address() {}
	public Address(String name,String phone,String email,String company) {
		this.name=name;
		this.phone=phone;
		this.email=email;
		this.company=company;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	
	
}
