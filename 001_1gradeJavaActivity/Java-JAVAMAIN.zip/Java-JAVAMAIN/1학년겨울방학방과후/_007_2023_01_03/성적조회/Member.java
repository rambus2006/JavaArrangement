package _007_2023_01_03.성적조회;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class Member {
	List<MemberLogin>member=new ArrayList<>();
	Scanner sc=new Scanner(System.in);
	
	public Member() {
		member.add(new MemberLogin("admin","admin","admin"));
	}
	public void menusystem() {
		System.out.println("[1]로그인 [2]회원가입 [3]전체회원 [0] 종료");
		int num=sc.nextInt();
		while((num!=0) {
			switch(num) {
				case 1:
					teacherLogin();
					break;
				case 2:
					teacherJoin();
				case 3:
					teacherList();
			}
		}
	}
	
	private void teacherLogin() {
		while(true) {
			System.out.println("ID : ");
			String id=sc.next();
			System.out.println("Password : ");
			String pw=sc.next();
			MemberLogin member=findId(id);
			//StudentHandler stuHdl=new StudentHandler();
			if(member==null) {
				System.out.println("입력하신 아이디가 일치하지 않습니다. ");
				System.out.println("다시 입력해주세요");
			}else if(member.getPw().equals(pw)) {
				System.out.println("학생정보관리시스템에 접속하였습니다.");
				//stuHdl.studentSystem();
				break;
			}else {
				System.out.println("입력하신 패스워트가 일치하지 않습니다.");
				System.out.println("다시 입력하시오.");
			}
		}
	}
	//menu2회원가입
	private void teacherJoin() {
		System.out.println("ID : ");
		String id=sc.next();
		System.out.println("PW : ");
		String pw=sc.next();
		System.out.println("Password 확인 : ");
		String pw2=sc.next();
		System.out.println("Name : ");
		String name=sc.next();
		
		if(findId(id)) {
			System.out.println("중복된 아이디입니다.");
		}else if(pw.equals(pw2)) {
			member.add(new MemberLogin(id,pw,name));
			System.out.println("회원가입이 완료되었습니다.");
		}else {
			System.out.println("비밀번호를 다시 입력하시오");
		}
	}
	public MemberLogin findId(String id) {
		for(MemberLogin memberLogin:member) {
			if(memberLogin.getId().equals(id)) {
				return memberLogin;
			}
		}
		return null;
	}

	
	public void teacherList() {
		System.out.println("[관리자목록]");
		for(MemberLogin memLog:member) {
			System.out.println(memLog);
		}
	}

}
