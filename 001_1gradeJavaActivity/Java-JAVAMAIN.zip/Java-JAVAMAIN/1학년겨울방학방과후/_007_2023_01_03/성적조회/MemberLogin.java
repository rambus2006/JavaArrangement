package _007_2023_01_03.성적조회;
/*
 *#CRUD를 이용한 고등학교 성적 조회 프로그램
 * ##구현된 기능
 * 1. 선생님 로그인으로 학생 성적 입력 프로그램에 접속합니다. 
 * 	-필드: id,password,name
 *  -생성자
 *  -메서드 id가 리스트에 있는지 확인/id와 비번이 맞는지 확인 / id가 password와 같지 않은지 확인 /name이 리스트에 있는지 확인 
 * 2.국어, 영어, 수학 3개의 성적을 입력받을 수 있습니다. 
 * 3. 총합과 평균을 자동 산출 합니다. 
 * 4. 학년을 가리지 않고 총합 기준으로 1등과 꼴찌를 산출합니다. 
 * 
 * ##개선점
 * 로그아웃 기능
 */
import java.util.Scanner;
public class MemberLogin {
	private String id;
	private String pw;
	private String name;
	
	public MemberLogin() {}
	public MemberLogin(String id,String pw,String name) {
		this.id=id;
		this.pw=pw;
		this.name=name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Teacher [id=" + id + ", pw=" + pw + ", name=" + name + "]";
	}
	public void add() {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("ID : ");
		String id=sc.next();
		System.out.println("Password : ");
		String pw=sc.next();
		System.out.println("Name : ");
		String name=sc.next();
		
		MemberLogin t = new MemberLogin(id,pw,name);
		//Teacher tea1=new Teacher(id,pw,name);
		//Teacher tea2=new Teacher(sc.next(),sc.next(),sc.next());
	}
	
	
	
}
