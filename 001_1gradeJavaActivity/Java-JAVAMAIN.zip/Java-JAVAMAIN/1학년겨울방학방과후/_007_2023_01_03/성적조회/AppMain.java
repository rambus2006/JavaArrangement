package _007_2023_01_03.성적조회;

import java.util.Scanner;
public class AppMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Member member=new Member();
		loop:
			while(true) {
				System.out.println("[고등학교 성적관리시스템 메인]");
				System.out.printf("[1]선생님로그인[0];
			}
	}

}
