import java.util.*;

class Solution {
     public int___ solution(int[] scores) {
        


        return rank;
    }
    public static void main(String[] args) {
        Solution sol = new Solution();
        int[] scores = {20, 60, 98, 59};
        
        int[] ret = sol.solution(scores);
        System.out.println("����" + Arrays.toString(scores)) 
        System.out.println("����" + Arrays.toString(_______)) 
    }
}