package _01Class_inheritance;

/*public class Point {
    private int x,y;
    public void set(int x,int y){
        this.x=x; this.y=y;
    }
    public void showPoint(){
        System.out.println("("+x+","+y+")");
    }
}
*/