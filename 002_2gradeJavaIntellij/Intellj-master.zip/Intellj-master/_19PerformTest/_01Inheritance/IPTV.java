package _19PerformTest._01Inheritance;

public class IPTV extends ColorTV{
    public IPTV(int size, int color) {
        super(size, color);
    }

    public static void main(String args[]){
    }
}
