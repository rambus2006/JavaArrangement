package _19PerformTest._03Interface;

public interface Animal {
    public static final String name = "동물";

    public abstract void move();
    public abstract void eat();
    public abstract void bark();
}
