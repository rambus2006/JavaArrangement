package _00HouseHoldLedgerPJ.Gui;
import java.awt.*;
/*
* 프로젝트 소개 : 간단한 가계부
* 프로젝트 요소 :
*  o 들어온돈, 나간돈, 나머지 돈(입금,출금,계좌상태)
*  - DB와 연동해서 프로그램을 껐다 켜도 데이터가 남아있다.
*  - 코멘트를 쓸 수 있게 한다.
*  - 돈이 나간날과 들어온 날을 달력에 색으로 표시해 달별로 볼 수 있다.
*  o 로그인 기능을 구현
*  */

//main
public class HouseholdLedger {
    public static void main(String[] args) {

    }
}


