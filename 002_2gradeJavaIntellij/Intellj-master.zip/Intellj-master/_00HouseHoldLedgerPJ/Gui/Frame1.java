package _00HouseHoldLedgerPJ.Gui;
/*
import _00HouseHoldLedger.User;

import javax.swing.*;

public class Frame1 extends User{

    public static void main(String[] args) {
        JFrame f= new JFrame();
        f.setTitle("가계부");
        f.setBounds(100,100,1000,600);
        f.setVisible(true);

        User u1=new User();
        JTextArea tf1=new JTextArea();
        JPanel panel1 = new JPanel();
        panel1.add(tf1.add(u1.UserMain()));

        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }


}
*/