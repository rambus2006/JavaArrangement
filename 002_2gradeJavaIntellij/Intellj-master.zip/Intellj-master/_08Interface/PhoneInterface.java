package _08Interface;
/*
public interface PhoneInterface { //인터페이스 선언
    public static final int TIMEOUT=10000; //상수 필드 public static final
    public abstract void sendCall(); //추상 메소드(public abstract생략 가능)
    public abstract void receiveCall(); //추상 메소드(public abstract생략 가능)
    public default void printLogo(){ //default 매소드(public 생략 가능)
        System.out.println("**Phone**");
    }; //디폴트 메소드
}
*/