////package _24ArrayList문제;
//
//import java.lang.reflect.Array;
//import java.util.ArrayList;
//import java.util.Collection;
//import java.util.Collections;
//import java.util.Scanner;
//
//import static sun.net.www.http.KeepAliveCache.result;
//
//public class ArrayListQ6 {
//    static ArrayList<Integer> randomSeats(int total){
//        ArrayList<Integer> arr = new ArrayList<>();
//        Scanner sc = new Scanner(System.in);
//        int num = sc.nextInt();
//        for(int i=1;i<=num;i++) arr.add(i);
//        arr.Shuffle(arr);
//        return arr;
//    }
//    static ArrayList<Integer> randomSeats2(int total, int[]layout){
//        ArrayList<Integer> arr = new ArrayList<>();
//        for(int i=1;i<=total.i++) result.add(i);
//        Collections.shuffle(students);
//
//        ArrayList<ArrayList<Integer>> result = new ArrayList<>();
//        for(int count:layout){
//            seats.add(students.get(idx));
//            idx++;
//        }
//        result.add(seats);
//    }
//
//
//}
