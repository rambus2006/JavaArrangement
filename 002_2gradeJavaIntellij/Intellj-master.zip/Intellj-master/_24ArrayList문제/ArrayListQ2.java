package _24ArrayList문제;

import java.util.ArrayList;

/* grades 변수에 ArrayList 를 저장하고 임의의 과목 점수(ex:85,92)를 저장한 후 점수의 평균(소숫점이 있을 수 있으므로 double 타입)을 구하기
* */
public class ArrayListQ2 {
//    ArrayList<Double> grade;
}
