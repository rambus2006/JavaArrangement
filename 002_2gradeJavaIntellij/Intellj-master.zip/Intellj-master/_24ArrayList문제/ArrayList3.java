package _24ArrayList문제;

import java.util.ArrayList;
import java.util.Scanner;

/*
* colors변수에 색상 문자열을 저장할 ArrayList르 저장하고 Scanner를 통해서 3개의 색상 정보(ex."red","blue")를 입력받아 저장하고
* 색상값을 모두 출력하기 */
public class ArrayList3 {
//    //문자열을 저장하는 ArrayList
//    ArrayList<String> colors = new ArrayList<>();
//    Scanner sc = new Scanner(System.in);
//    for(int i=0;i<3;i++){
//        String color = sc.nextLine();
//        color.add(colors);
//    }
//    for(String color:colors)
//        System.out.println(colors);
}
