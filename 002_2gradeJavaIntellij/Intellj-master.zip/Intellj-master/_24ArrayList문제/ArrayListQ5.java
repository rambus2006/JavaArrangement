//package _24ArrayList문제;
//
//import java.util.ArrayList;
//
///*5)두 리스트를 합쳐주는 merge 메서드
//* ArrayList<Integer> merge(ArrayList<Integer> list1,ArrayList<INteger> list2){
//* }*/
//public class ArrayListQ5 {
////    static <T>ArrayList<T> merge(ArrayList<T> list1, ArrayList<T> list2){
////        ArrayList<Integer> result = new ArrayList<>();
////        for(T i: list1) result.add(i);
////        for(T i: list2) result.add(i);
////        return result;
//    }
//
//}
//
