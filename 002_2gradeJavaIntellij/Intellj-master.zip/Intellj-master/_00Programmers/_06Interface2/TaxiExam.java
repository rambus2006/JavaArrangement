package _00Programmers._06Interface2;

public class TaxiExam{
    public static void main(String []args){
        Taxi taxi = new Taxi();
        taxi.BASE_FARE = 2500;
    }
}