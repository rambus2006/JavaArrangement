package _00Programmers._06Interface2;

public interface Meter{

    public abstract void start();
    public abstract int stop(int distance);
}