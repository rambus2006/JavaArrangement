package _00Programmers._04Overriding2;

public class BusExam {
    public static void main(String[] args) {
        Bus bus = new Bus();
        bus.run();
    }
}