package _00Programmers._05ClassCast;

public class Suv extends Car{
}
