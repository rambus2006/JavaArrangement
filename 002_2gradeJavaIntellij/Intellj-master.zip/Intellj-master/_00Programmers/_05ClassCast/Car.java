package _00Programmers._05ClassCast;

public class Car{
    public int gas;
}