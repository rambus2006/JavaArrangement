package _00Programmers._05ClassCast;

public class Bus extends Car{
}
