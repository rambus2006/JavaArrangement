package _00Programmers._05ClassCast;

public class Truck extends Car{
}
