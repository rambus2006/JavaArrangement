package _00Programmers._01AccessModifier2;

public class CarExam{
    public static void main(String[]args){
        Car car = new Car();
        car.run();
        car.stop();
    }
}