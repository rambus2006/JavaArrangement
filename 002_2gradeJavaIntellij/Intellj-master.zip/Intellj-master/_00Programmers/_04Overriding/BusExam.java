package _00Programmers._04Overriding;

//다음은 실행을 위한 코드입니다. 수정하지 마세요.
class BusExam {
    public static void main(String [] args) {
        Bus bus = new Bus();
        bus.run();
    }
}