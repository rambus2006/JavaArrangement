package _00Programmers._04Overriding;

public class Car {
    public void run() {
        System.out.println("차가 달립니다.");
    }

    public void stop() {
        System.out.println("차가 멈춥니다.");
    }

    public void horn() {
        System.out.println("경적을 울립니다.");
    }
}