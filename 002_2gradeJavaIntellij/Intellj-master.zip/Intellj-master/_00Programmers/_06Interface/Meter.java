package _00Programmers._06Interface;

public interface Meter {
    public abstract void start();
    public abstract int stop(int distance);
}