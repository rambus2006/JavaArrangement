package _00Programmers._01AccessModifier;

public class Car {
    public String name;
    public int number;

    public Car(String name, int number) {
        this.name = name;
        this.number = number;
    }
}