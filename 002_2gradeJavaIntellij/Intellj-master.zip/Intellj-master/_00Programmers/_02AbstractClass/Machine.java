package _00Programmers._02AbstractClass;

public abstract class Machine {
    public abstract void turnOn();
    public abstract void turnOff();
}