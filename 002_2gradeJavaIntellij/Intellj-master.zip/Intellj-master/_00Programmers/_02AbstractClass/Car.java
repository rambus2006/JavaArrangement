package _00Programmers._02AbstractClass;

class Car extends Machine {
    // Machine 클래스를 상속받고, 추상 메소드를 구현하세요.
    @Override
    public void turnOn(){

    }
    public void turnOff(){

    }

}